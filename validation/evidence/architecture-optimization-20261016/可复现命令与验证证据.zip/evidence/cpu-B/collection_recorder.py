import json, os
from pathlib import Path
def pytest_collection_finish(session):
    rows=[{'nodeid':x.nodeid,'location':list(x.location),'path':str(x.fspath)} for x in session.items]
    Path(os.environ['ASTRA_COLLECTION_OUTPUT']).write_text(json.dumps(rows,indent=2)+'\n')
