import ast, json, re
from pathlib import Path
ROOT=Path('/home/lss/arc3696-work/astra-architecture-20261016/B')
OUT=ROOT.parent/'evidence/cpu-B'
OUT.mkdir(parents=True,exist_ok=True)
CMD=Path('/home/lss/arc3696-work/evidence/arc3696-20261016/wall-uniform-work-20261016T061401Z/tests-accepted-command.json')
commands=json.loads(CMD.read_text())
all_py=list((ROOT/'validation').rglob('*.py'))
by_name={}
for p in all_py:by_name.setdefault(p.stem,[]).append(p)
queue=[ROOT/x for g in commands['groups'] for x in g['argv'] if x.endswith('.py')]
queue+=list(ROOT.glob('conftest.py'))
queue+=[p for p in (ROOT/'validation').rglob('conftest.py') if p.parent==ROOT/'validation' or any(p.parent in x.parents for x in queue)]
seen=set();records=[]
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    text=p.read_text()
    try:tree=ast.parse(text)
    except SyntaxError:continue
    for node in ast.walk(tree):
        if isinstance(node,(ast.Import,ast.ImportFrom)):
            names=[node.module] if isinstance(node,ast.ImportFrom) else [x.name for x in node.names]
            for name in names:
                if not name:continue
                rel=ROOT/Path(*name.split('.')).with_suffix('.py')
                if rel.is_file():queue.append(rel)
                elif '.' not in name:queue+=by_name.get(name,[])
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id in ('subprocess','os'):
            records.append({'file':str(p.relative_to(ROOT)), 'line':node.lineno, 'call':ast.get_source_segment(text,node)})
    for i,line in enumerate(text.splitlines(),1):
        if re.search(r'\bnvcc\b|\bnvidia-smi\b|compute-sanitizer|UGKWP_.*GPU_TEST|cuda[A-Z]\w*\(',line):
            records.append({'file':str(p.relative_to(ROOT)), 'line':i, 'cuda_token_line':line})
result={'command_json':str(CMD),'selected_test_files':sum(g['files'] for g in commands['groups']),
        'transitive_local_python_files':sorted(str(x.relative_to(ROOT)) for x in seen),'launch_and_cuda_records':records}
(OUT/'preflight-static-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
