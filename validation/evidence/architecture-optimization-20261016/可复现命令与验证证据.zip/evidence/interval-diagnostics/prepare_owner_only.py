"""Build the unchanged existing ownerTests against the C-seed diagnostic copy.

Only the test main is narrowed; production and all four owner controls remain
unchanged. This does not enable wall profiles or run the old failure matrix.
"""
import difflib,hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
source=root/'source-C-seed';out=root/'owner-C-seed'
tool=pathlib.Path('/home/lss/arc3696-work/astra-architecture-20261016/C-seed/validation/tools/tests/fixtures/chemistry_trial/prepare_chemistry_trial.py')
generate=[sys.executable,str(tool),str(source),str(out),'--generate-only','--nvcc','/usr/local/cuda/bin/nvcc','--arch','sm_89']
subprocess.run(generate,check=True)
original=(out/'chemistry_trial.cu').read_text();index=original.index('\nint main(')
modified=original[:index]+r'''
int main(){setvbuf(stdout,nullptr,_IONBF,0);
    chemistryTrialTest::ownerTests();chemistryTrialTest::cleanup();
    std::puts("PASS real CUDA owner-only controls complete");return 0;
}
'''
(out/'owner_only.cu').write_text(modified)
(out/'owner-only.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),modified.splitlines(True),fromfile='chemistry_trial.cu',tofile='owner_only.cu')))
command=json.loads((out/'command.json').read_text());command=[str(out/'owner_only.cu') if x==str(out/'chemistry_trial.cu') else str(out/'owner_only') if x==str(out/'chemistry_trial') else x for x in command]
(out/'owner-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'build.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
(out/'build.exit').write_text(str(result.returncode)+'\n')
if result.returncode:raise SystemExit(result.returncode)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}
(out/'build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(out/'owner_only')
