"""Summarize exact observer records. -1 means a predicate was not evaluated."""
import argparse,json,pathlib
p=argparse.ArgumentParser();p.add_argument('log',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);args=p.parse_args()
rows=[]
for line in args.log.read_text().splitlines():
 if 'UGKP_INTERVAL_DIAG ' in line:rows.append(json.loads(line.split('UGKP_INTERVAL_DIAG ',1)[1]))
begins=[r for r in rows if r['event']=='begin'];ends=[r for r in rows if r['event']=='end'];trials=[r for r in rows if r['event']=='trial'];accepted=[r for r in rows if r['event']=='accepted'];rollbacks=[r for r in rows if r['event']=='rollback']
assert len(begins)==len(ends)>0
assert sum(r['trials'] for r in ends)==len(trials)
assert sum(r['accepted_substeps'] for r in ends)==len(accepted)
assert sum(r['trial_rollbacks']+r['interval_rollbacks'] for r in ends)==len(rollbacks)
summary={'log':str(args.log),'predicate_minus_one':'not evaluated in the original control flow','intervals':len(ends),'trials':len(trials),'accepted_substeps':len(accepted),'failed_trials':sum(r['failed_trials'] for r in ends),'trial_rollbacks':sum(r['trial_rollbacks'] for r in ends),'interval_rollbacks':sum(r['interval_rollbacks'] for r in ends),'interval_results':[r['result'] for r in ends],'accepted_dt_hex':float.hex(sum(float.fromhex(r['accepted_dt']) for r in ends)),'records':rows}
args.output.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2))
