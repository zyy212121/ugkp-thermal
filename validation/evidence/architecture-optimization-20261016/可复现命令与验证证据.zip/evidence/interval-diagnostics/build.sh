#!/usr/bin/env bash
set -euo pipefail
source_root=${1:?diagnostic source snapshot path required}
output=${2:?isolated output path required}
mkdir -p "$output"
private="$source_root/applications/gasUGKP/private_backend"
gpu="$source_root/applications/gasUGKP/gpu"
cuda_home=${CUDA_HOME:-/usr/local/cuda}
nvcc=("$cuda_home/bin/nvcc" -std=c++17 -DUGKWP_GAS_SPECIES=2 -O3 --fmad=true -arch=sm_89 -Xcompiler -fPIC -I"$gpu" -I"$source_root/common" -c "$private/GpuResidentStrict.cu" -o "$output/GpuResidentStrict.o")
link=(c++ -std=c++17 -O3 -I"$gpu" -I"$source_root/common" "$private/GpuBackendServer.C" "$output/GpuResidentStrict.o" -L"$cuda_home/lib64" -Wl,-rpath,"$cuda_home/lib64" -lcudart -o "$output/gasUGKPCudaBackend")
printf '%q ' "${nvcc[@]}" > "$output/build.command"
printf '\n' >> "$output/build.command"
printf '%q ' "${link[@]}" >> "$output/build.command"
printf '\n' >> "$output/build.command"
"$cuda_home/bin/nvcc" --version > "$output/toolchain.txt"
set +e
"${nvcc[@]}" > "$output/build.log" 2>&1
code=$?
if ((code==0)); then "${link[@]}" >> "$output/build.log" 2>&1;code=$?;fi
set -e
printf '%d\n' "$code" > "$output/build.exit"
if ((code)); then tail -n 60 "$output/build.log";exit "$code";fi
sha256sum "$output/gasUGKPCudaBackend" > "$output/binary.sha256"
cat "$output/binary.sha256"
