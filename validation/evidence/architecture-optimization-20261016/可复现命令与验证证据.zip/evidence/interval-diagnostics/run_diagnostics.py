"""Run isolated host-instrumented backends on the original frozen 12-step inputs."""
import argparse,json,pathlib,subprocess,sys
root=pathlib.Path('/home/lss/arc3696-work/astra-architecture-20261016')
here=pathlib.Path(__file__).resolve().parent
original_runner=pathlib.Path('/mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work/run_short_benchmark.py')
compare_runner=original_runner.with_name('compare_run_outputs.py')
text=original_runner.read_text()
if "'C-seed'" not in text:
 text=text.replace("'A-nofmad','B-nofmad'","'A-nofmad','B-nofmad','C-seed'")
control_runner=here/'run_control_benchmark.py';control_runner.write_text(text)
old="backend=root/'bin'/a.label/'gasUGKPCudaBackend'"
assert text.count(old)==1
text=text.replace(old,"backend=root/'evidence/interval-diagnostics'/('bin-'+a.label)/'gasUGKPCudaBackend'")
text=text.replace("'benchmark_only':True","'benchmark_only':True,'host_instrumented_diagnostic':True,'C_designation':'C-cache'")
runner=here/'run_diagnostic_benchmark.py';runner.write_text(text)
p=argparse.ArgumentParser();p.add_argument('--labels',nargs='+',default=['A','B','C']);args=p.parse_args()
for label in args.labels:
 for name,short in [('arc-M0p55-current','arc'),('flatplate-fixed-96x48','small')]:
  run_id=f'diag-{short}-12-{label}'
  reference=f'perf-{short}-1-{label}'
  if label=='C-seed':
   reference=f'diag-control-{short}-12-{label}'
   control=[sys.executable,str(control_runner),label,name,reference,'--steps','12','--timeout','240']
   with (here/(reference+'.driver.log')).open('w') as log:control_result=subprocess.run(control,stdout=log,stderr=subprocess.STDOUT)
   print(reference,'exit',control_result.returncode,flush=True)
   if control_result.returncode:raise SystemExit(control_result.returncode)
  command=[sys.executable,str(runner),label,name,run_id,'--steps','12','--timeout','240']
  with (here/(run_id+'.driver.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  print(run_id,'exit',result.returncode,flush=True)
  if result.returncode:raise SystemExit(result.returncode)
  compare=[sys.executable,str(compare_runner),reference,run_id]
  subprocess.run(compare,check=True)
