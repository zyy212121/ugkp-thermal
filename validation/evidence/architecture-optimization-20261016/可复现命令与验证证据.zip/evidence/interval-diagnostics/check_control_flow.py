"""Verify diagnostic rewriting preserves owner calls/conditions using host stubs.

This checks only instrumentation call order, not GPU rollback correctness.
"""
from pathlib import Path
import subprocess
from prepare import HELPER,OWNER
root=Path(__file__).resolve().parent
original=(root/'source-A/original-owner.cuh').read_text().replace('int advanceGasRequestedInterval\n','int advanceGasRequestedIntervalOriginal\n')
prefix=r'''
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
namespace GasHostPolicy {using Time=double;}
template<class Time> struct GasRequestedIntervalControls{Time minimumSubstep=1e-14;int maximumAttempts=10000;};
struct State{std::vector<std::string> events;std::vector<int> results;int current=0,beginResult=0,commitResult=0;bool canRetry=true,canTerminal=false;};
struct Policy{
 static int beginInterval(State* s){s->events.push_back("begin");return s->beginResult;}
 static void rollbackInterval(State* s){s->events.push_back("rollbackInterval");}
 static int commitInterval(State* s){s->events.push_back("commit");return s->commitResult;}
 static bool retryable(State* s){s->events.push_back("retryable");return s->canRetry;}
 static bool continueTerminal(State* s){s->events.push_back("continueTerminal");return s->canTerminal;}
};
template<class P,class S> auto gasTrialCanContinueTerminal(S* s,int)->decltype(P::continueTerminal(s)){return P::continueTerminal(s);}
template<class P,class S> int advanceGasTrial(S* s,double dt,double stamp,bool refine){
 std::ostringstream out;out<<"trial "<<std::hexfloat<<dt<<' '<<stamp<<' '<<refine;s->events.push_back(out.str());
 const int i=s->current++;if(i>100)std::abort();return i<int(s->results.size())?s->results[i]:0;
}
'''
suffix=r'''
int main(){
 for(int kind=0;kind<13;++kind){State originalState;GasRequestedIntervalControls<double> c;double dt=1,stamp=2;
  if(kind==1)c.maximumAttempts=0;
  if(kind==2)originalState.beginResult=1;
  if(kind==3)originalState.results={1};
  if(kind==4)originalState.results={1,1};
  if(kind==5){originalState.results={1};originalState.canRetry=false;originalState.canTerminal=true;}
  if(kind==6){originalState.results={1};originalState.canRetry=false;}
  if(kind==7){originalState.results={1};c.maximumAttempts=0;}
  if(kind==8){originalState.results={1,1};c.maximumAttempts=1;}
  if(kind==9){originalState.results={1,1};c.minimumSubstep=.75;}
  if(kind==10)originalState.commitResult=1;
  if(kind==11){originalState.results={1,1};originalState.canRetry=false;originalState.canTerminal=true;}
  if(kind==12)dt=1e-30;
  State diagnosticState=originalState;
  const int a=advanceGasRequestedIntervalOriginal<Policy>(&originalState,dt,stamp,c);
  const int b=advanceGasRequestedInterval<Policy>(&diagnosticState,dt,stamp,c);
  if(a!=b||originalState.events!=diagnosticState.events){std::cerr<<"Mismatch scenario "<<kind<<'\n';return 1;}
 }
 std::cout<<"PASS 13 diagnostic instrumentation control-flow scenarios: identical policy calls, order, trial dt/time/refining and return values\n";
}
'''
cpp=root/'control_flow_selftest.cpp';exe=root/'control_flow_selftest';cpp.write_text(prefix+HELPER+original+OWNER+suffix)
command=['g++','-std=c++17','-O2',str(cpp),'-o',str(exe)]
subprocess.run(command,check=True)
with (root/'control-flow-selftest.stdout').open('w') as out,(root/'control-flow-selftest.stderr').open('w') as err:
 result=subprocess.run([str(exe)],stdout=out,stderr=err)
print((root/'control-flow-selftest.stdout').read_text(),end='')
raise SystemExit(result.returncode)
