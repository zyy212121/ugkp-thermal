
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
namespace GasHostPolicy {using Time=double;}
template<class Time> struct GasRequestedIntervalControls{Time minimumSubstep=1e-14;int maximumAttempts=10000;};
struct State{std::vector<std::string> events;std::vector<int> results;int current=0,beginResult=0,commitResult=0;bool canRetry=true,canTerminal=false;};
struct Policy{
 static int beginInterval(State* s){s->events.push_back("begin");return s->beginResult;}
 static void rollbackInterval(State* s){s->events.push_back("rollbackInterval");}
 static int commitInterval(State* s){s->events.push_back("commit");return s->commitResult;}
 static bool retryable(State* s){s->events.push_back("retryable");return s->canRetry;}
 static bool continueTerminal(State* s){s->events.push_back("continueTerminal");return s->canTerminal;}
};
template<class P,class S> auto gasTrialCanContinueTerminal(S* s,int)->decltype(P::continueTerminal(s)){return P::continueTerminal(s);}
template<class P,class S> int advanceGasTrial(S* s,double dt,double stamp,bool refine){
 std::ostringstream out;out<<"trial "<<std::hexfloat<<dt<<' '<<stamp<<' '<<refine;s->events.push_back(out.str());
 const int i=s->current++;if(i>100)std::abort();return i<int(s->results.size())?s->results[i]:0;
}

// Diagnostic-only host observer. No device reads, CUDA calls, or policy probes.
struct UgkpIntervalDiagnostic;
static thread_local UgkpIntervalDiagnostic* ugkpIntervalDiagnosticCurrent=nullptr;
static thread_local unsigned long long ugkpIntervalDiagnosticSerial=0;
struct UgkpIntervalDiagnostic {
    UgkpIntervalDiagnostic* previous;
    unsigned long long serial;
    int trials=0,accepted=0,failed=0,trialRollbacks=0,intervalRollbacks=0,returnCode=1;
    double acceptedDt=0,trialDt=0,trialElapsed=0;
    bool trialRefining=false;
    int controlAttempts=0;
    UgkpIntervalDiagnostic(double requested,double stamp,double minimum,int maximum)
      :previous(ugkpIntervalDiagnosticCurrent),serial(++ugkpIntervalDiagnosticSerial){
        ugkpIntervalDiagnosticCurrent=this;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"begin\",\"interval\":%llu,\"requested_dt\":\"%a\",\"simulation_time\":\"%a\",\"minimum_substep\":\"%a\",\"maximum_attempts\":%d}\n",serial,requested,stamp,minimum,maximum);
    }
    void start(double dt,double elapsed,bool refining,int attempts){
        ++trials;trialDt=dt;trialElapsed=elapsed;trialRefining=refining;controlAttempts=attempts;
    }
    void result(int rc,int retryable,int terminal){
        if(rc)++failed;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"trial\",\"interval\":%llu,\"trial\":%d,\"dt\":\"%a\",\"elapsed\":\"%a\",\"refining\":%d,\"control_attempts\":%d,\"result\":%d,\"retryable\":%d,\"terminal\":%d}\n",serial,trials,trialDt,trialElapsed,int(trialRefining),controlAttempts,rc,retryable,terminal);
    }
    void accept(double dt,double elapsed){
        ++accepted;acceptedDt+=dt;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"accepted\",\"interval\":%llu,\"trial\":%d,\"dt\":\"%a\",\"elapsed_after\":\"%a\"}\n",serial,trials,dt,elapsed);
    }
    void rollback(bool interval){
        if(interval)++intervalRollbacks;else ++trialRollbacks;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"rollback\",\"interval\":%llu,\"trial\":%d,\"scope\":\"%s\"}\n",serial,trials,interval?"interval":"trial");
    }
    int finish(int rc){returnCode=rc;return rc;}
    ~UgkpIntervalDiagnostic(){
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"end\",\"interval\":%llu,\"trials\":%d,\"accepted_substeps\":%d,\"failed_trials\":%d,\"trial_rollbacks\":%d,\"interval_rollbacks\":%d,\"accepted_dt\":\"%a\",\"result\":%d}\n",serial,trials,accepted,failed,trialRollbacks,intervalRollbacks,acceptedDt,returnCode);
        std::fflush(stderr);ugkpIntervalDiagnosticCurrent=previous;
    }
};
inline void ugkpDiagnosticTrialRollback(){
    if(ugkpIntervalDiagnosticCurrent)ugkpIntervalDiagnosticCurrent->rollback(false);
}

template<class TrialPolicy, class GasHostState>
int advanceGasRequestedIntervalOriginal
(
    GasHostState* s,
    const GasHostPolicy::Time requestedDt,
    const GasHostPolicy::Time simulationTime,
    const GasRequestedIntervalControls<GasHostPolicy::Time>& controls
)
{
    using Time = GasHostPolicy::Time;
    if (TrialPolicy::beginInterval(s) != 0)
    { TrialPolicy::rollbackInterval(s); return 1; }
    Time elapsed=Time(0),substep=requestedDt;
    int attempts=0;
    bool refining=requestedDt>Time(0) && controls.minimumSubstep>Time(0)
        && controls.maximumAttempts>0 && simulationTime+requestedDt!=simulationTime;
    if(!refining)
    {
        if(advanceGasTrial<TrialPolicy>(s,requestedDt,simulationTime,false)!=0)
        {TrialPolicy::rollbackInterval(s);return 1;}
    }
    else while(elapsed<requestedDt)
    {
        const Time remaining=requestedDt-elapsed;
        if(substep>remaining)substep=remaining;
        if(refining && (++attempts>controls.maximumAttempts || elapsed+substep==elapsed
            || !(substep>Time(0))))
        {refining=false;substep=remaining;}
        if(advanceGasTrial<TrialPolicy>(s,substep,simulationTime+elapsed,refining)==0)
        {
            elapsed+=substep;
            if(elapsed<requestedDt)substep*=Time(2);
        }
        else
        {
            if(!TrialPolicy::retryable(s))
            {
                if(refining && gasTrialCanContinueTerminal<TrialPolicy>(s,0))
                {refining=false;substep=remaining;continue;}
                TrialPolicy::rollbackInterval(s);return 1;
            }
            if(!refining)
            {TrialPolicy::rollbackInterval(s);return 1;}
            substep*=Time(.5);
            if(substep<controls.minimumSubstep)
            {refining=false;substep=remaining;}
        }
    }
    if(TrialPolicy::commitInterval(s)!=0)
    {TrialPolicy::rollbackInterval(s);return 1;}
    return 0;
}

template<class TrialPolicy, class GasHostState>
int advanceGasRequestedInterval
(
    GasHostState* s,
    const GasHostPolicy::Time requestedDt,
    const GasHostPolicy::Time simulationTime,
    const GasRequestedIntervalControls<GasHostPolicy::Time>& controls
)
{
    using Time = GasHostPolicy::Time;
    UgkpIntervalDiagnostic diag(requestedDt,simulationTime,controls.minimumSubstep,controls.maximumAttempts);
    if (TrialPolicy::beginInterval(s) != 0)
    { TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1); }
    Time elapsed=Time(0),substep=requestedDt;
    int attempts=0;
    bool refining=requestedDt>Time(0) && controls.minimumSubstep>Time(0)
        && controls.maximumAttempts>0 && simulationTime+requestedDt!=simulationTime;
    if(!refining)
    {
        diag.start(requestedDt,elapsed,false,attempts);
        const int result=advanceGasTrial<TrialPolicy>(s,requestedDt,simulationTime,false);
        diag.result(result,-1,-1);
        if(result!=0)
        {TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);}
        diag.accept(requestedDt,requestedDt);
    }
    else while(elapsed<requestedDt)
    {
        const Time remaining=requestedDt-elapsed;
        if(substep>remaining)substep=remaining;
        if(refining && (++attempts>controls.maximumAttempts || elapsed+substep==elapsed
            || !(substep>Time(0))))
        {refining=false;substep=remaining;}
        diag.start(substep,elapsed,refining,attempts);
        const int result=advanceGasTrial<TrialPolicy>(s,substep,simulationTime+elapsed,refining);
        if(result==0)
        {
            diag.result(result,-1,-1);
            elapsed+=substep;
            diag.accept(substep,elapsed);
            if(elapsed<requestedDt)substep*=Time(2);
        }
        else
        {
            const bool retryable=TrialPolicy::retryable(s);
            if(!retryable)
            {
                const bool terminal=refining && gasTrialCanContinueTerminal<TrialPolicy>(s,0);
                diag.result(result,0,refining?int(terminal):-1);
                if(terminal)
                {refining=false;substep=remaining;continue;}
                TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);
            }
            diag.result(result,1,-1);
            if(!refining)
            {TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);}
            substep*=Time(.5);
            if(substep<controls.minimumSubstep)
            {refining=false;substep=remaining;}
        }
    }
    if(TrialPolicy::commitInterval(s)!=0)
    {TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);}
    return diag.finish(0);
}

int main(){
 for(int kind=0;kind<13;++kind){State originalState;GasRequestedIntervalControls<double> c;double dt=1,stamp=2;
  if(kind==1)c.maximumAttempts=0;
  if(kind==2)originalState.beginResult=1;
  if(kind==3)originalState.results={1};
  if(kind==4)originalState.results={1,1};
  if(kind==5){originalState.results={1};originalState.canRetry=false;originalState.canTerminal=true;}
  if(kind==6){originalState.results={1};originalState.canRetry=false;}
  if(kind==7){originalState.results={1};c.maximumAttempts=0;}
  if(kind==8){originalState.results={1,1};c.maximumAttempts=1;}
  if(kind==9){originalState.results={1,1};c.minimumSubstep=.75;}
  if(kind==10)originalState.commitResult=1;
  if(kind==11){originalState.results={1,1};originalState.canRetry=false;originalState.canTerminal=true;}
  if(kind==12)dt=1e-30;
  State diagnosticState=originalState;
  const int a=advanceGasRequestedIntervalOriginal<Policy>(&originalState,dt,stamp,c);
  const int b=advanceGasRequestedInterval<Policy>(&diagnosticState,dt,stamp,c);
  if(a!=b||originalState.events!=diagnosticState.events){std::cerr<<"Mismatch scenario "<<kind<<'\n';return 1;}
 }
 std::cout<<"PASS 13 diagnostic instrumentation control-flow scenarios: identical policy calls, order, trial dt/time/refining and return values\n";
}
