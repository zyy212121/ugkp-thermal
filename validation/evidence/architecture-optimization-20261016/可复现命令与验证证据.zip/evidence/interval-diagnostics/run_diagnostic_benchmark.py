import argparse, pathlib, subprocess, os, json, hashlib, time, shutil, signal, datetime
p=argparse.ArgumentParser()
p.add_argument('label',choices=['A','B','C','B-seed','C-seed','A-nofmad','B-nofmad'])
p.add_argument('case')
p.add_argument('run_id')
p.add_argument('--steps',type=int,default=3)
p.add_argument('--timeout',type=int,default=240)
p.add_argument('--profile',choices=['none','nsys','ncu'],default='none')
a=p.parse_args()
root=pathlib.Path('/home/lss/arc3696-work/astra-architecture-20261016')
source=root/'inputs'/a.case
out=root/'evidence/runs'/a.run_id
out.mkdir(parents=True,exist_ok=False)
case=out/'case'
shutil.copytree(source,case,symlinks=False)
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
inputs={str(f.relative_to(case)):sha(f) for f in sorted(case.rglob('*')) if f.is_file() and f.relative_to(case).parts[0] in ['0','constant','system']}
(out/'inputs.sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
backend=root/'evidence/interval-diagnostics'/('bin-'+a.label)/'gasUGKPCudaBackend'
frontend=root/'bin/harness/gasUGKPBenchmark'
cmd=[str(frontend),'-case',str(case)]
if a.profile=='nsys':
    cmd=['/usr/local/cuda-13.1/bin/nsys','profile','--trace=cuda,nvtx,osrt','--sample=none','--cpuctxsw=none','--wait=all','--force-overwrite=false','-o',str(out/'profile')]+cmd
elif a.profile=='ncu':
    cmd=['/usr/local/cuda-13.1/bin/ncu','--target-processes','all','--kernel-name-base','demangled','--kernel-name','regex:.*evaluateGasBoundaryLayer.*','--launch-count','1','--section','LaunchStats','--section','Occupancy','--section','SpeedOfLight','--section','MemoryWorkloadAnalysis','--section','WarpStateStats','--export',str(out/'profile')]+cmd
extra={'GAS_UGKP_CUDA_BACKEND':str(backend),'ARC_BENCH_MAX_STEPS':str(a.steps),'ARC_BENCH_CSV':str(out/'steps.csv')}
record={'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'env':extra,'backend_sha256':sha(backend),'frontend_sha256':sha(frontend),'input_source':str(source),'profile':a.profile,'benchmark_only':True,'host_instrumented_diagnostic':True,'C_designation':'C-cache','expected_steps':a.steps}
query=['/usr/lib/wsl/lib/nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv']
busy=subprocess.run(query,capture_output=True,text=True)
(out/'gpu-before.txt').write_text(busy.stdout+busy.stderr)
# This guard is only in the isolated benchmark driver, never solver code.
if busy.returncode or len([x for x in busy.stdout.splitlines() if x.strip()])>1:
    raise RuntimeError('Another compute task is active; inspect gpu-before.txt before running this isolated test')
telemetry=out/'gpu-telemetry.csv'
with telemetry.open('w') as tele, (out/'solver.log').open('w') as log:
    monitor=subprocess.Popen(['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=timestamp,power.draw,utilization.gpu,utilization.memory,temperature.gpu,clocks.sm,clocks.mem,memory.used','--format=csv','-lms','200'],stdout=tele,stderr=subprocess.STDOUT)
    started=time.monotonic()
    record['launch_monotonic_seconds']=started
    record['launch_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    child=subprocess.Popen(cmd,env={**os.environ,**extra},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        record['return_code']=child.wait(timeout=a.timeout)
    except subprocess.TimeoutExpired:
        record['timed_out']=True
        os.killpg(child.pid,signal.SIGTERM)
        try: child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait()
        record['return_code']=child.returncode
    finally:
        record['process_wall_seconds']=time.monotonic()-started
        monitor.terminate();monitor.wait(timeout=10)
text=(out/'solver.log').read_text(errors='replace')
record['complete_marker']=f'ARC_BENCHMARK_ONLY_PREFIX_COMPLETE steps={a.steps}' in text
import re
for field,marker in [('initialization_seconds','BENCH_INIT_SECONDS'),('final_output_seconds','BENCH_OUTPUT_SECONDS')]:
    found=re.search(marker+r'=([^\s]+)',text)
    if found:record[field]=float(found.group(1))
record['utc_end']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print('\n'.join(text.splitlines()[-12:]))
if record['return_code'] or not record['complete_marker']:raise SystemExit(1)
