"""Create isolated diagnostic source copies; never edit a production checkout."""
import argparse,difflib,hashlib,json,pathlib,shutil,subprocess

HELPER=r'''
// Diagnostic-only host observer. No device reads, CUDA calls, or policy probes.
struct UgkpIntervalDiagnostic;
static thread_local UgkpIntervalDiagnostic* ugkpIntervalDiagnosticCurrent=nullptr;
static thread_local unsigned long long ugkpIntervalDiagnosticSerial=0;
struct UgkpIntervalDiagnostic {
    UgkpIntervalDiagnostic* previous;
    unsigned long long serial;
    int trials=0,accepted=0,failed=0,trialRollbacks=0,intervalRollbacks=0,returnCode=1;
    double acceptedDt=0,trialDt=0,trialElapsed=0;
    bool trialRefining=false;
    int controlAttempts=0;
    UgkpIntervalDiagnostic(double requested,double stamp,double minimum,int maximum)
      :previous(ugkpIntervalDiagnosticCurrent),serial(++ugkpIntervalDiagnosticSerial){
        ugkpIntervalDiagnosticCurrent=this;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"begin\",\"interval\":%llu,\"requested_dt\":\"%a\",\"simulation_time\":\"%a\",\"minimum_substep\":\"%a\",\"maximum_attempts\":%d}\n",serial,requested,stamp,minimum,maximum);
    }
    void start(double dt,double elapsed,bool refining,int attempts){
        ++trials;trialDt=dt;trialElapsed=elapsed;trialRefining=refining;controlAttempts=attempts;
    }
    void result(int rc,int retryable,int terminal){
        if(rc)++failed;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"trial\",\"interval\":%llu,\"trial\":%d,\"dt\":\"%a\",\"elapsed\":\"%a\",\"refining\":%d,\"control_attempts\":%d,\"result\":%d,\"retryable\":%d,\"terminal\":%d}\n",serial,trials,trialDt,trialElapsed,int(trialRefining),controlAttempts,rc,retryable,terminal);
    }
    void accept(double dt,double elapsed){
        ++accepted;acceptedDt+=dt;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"accepted\",\"interval\":%llu,\"trial\":%d,\"dt\":\"%a\",\"elapsed_after\":\"%a\"}\n",serial,trials,dt,elapsed);
    }
    void rollback(bool interval){
        if(interval)++intervalRollbacks;else ++trialRollbacks;
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"rollback\",\"interval\":%llu,\"trial\":%d,\"scope\":\"%s\"}\n",serial,trials,interval?"interval":"trial");
    }
    int finish(int rc){returnCode=rc;return rc;}
    ~UgkpIntervalDiagnostic(){
        std::fprintf(stderr,"UGKP_INTERVAL_DIAG {\"event\":\"end\",\"interval\":%llu,\"trials\":%d,\"accepted_substeps\":%d,\"failed_trials\":%d,\"trial_rollbacks\":%d,\"interval_rollbacks\":%d,\"accepted_dt\":\"%a\",\"result\":%d}\n",serial,trials,accepted,failed,trialRollbacks,intervalRollbacks,acceptedDt,returnCode);
        std::fflush(stderr);ugkpIntervalDiagnosticCurrent=previous;
    }
};
inline void ugkpDiagnosticTrialRollback(){
    if(ugkpIntervalDiagnosticCurrent)ugkpIntervalDiagnosticCurrent->rollback(false);
}

'''

OWNER=r'''
template<class TrialPolicy, class GasHostState>
int advanceGasRequestedInterval
(
    GasHostState* s,
    const GasHostPolicy::Time requestedDt,
    const GasHostPolicy::Time simulationTime,
    const GasRequestedIntervalControls<GasHostPolicy::Time>& controls
)
{
    using Time = GasHostPolicy::Time;
    UgkpIntervalDiagnostic diag(requestedDt,simulationTime,controls.minimumSubstep,controls.maximumAttempts);
    if (TrialPolicy::beginInterval(s) != 0)
    { TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1); }
    Time elapsed=Time(0),substep=requestedDt;
    int attempts=0;
    bool refining=requestedDt>Time(0) && controls.minimumSubstep>Time(0)
        && controls.maximumAttempts>0 && simulationTime+requestedDt!=simulationTime;
    if(!refining)
    {
        diag.start(requestedDt,elapsed,false,attempts);
        const int result=advanceGasTrial<TrialPolicy>(s,requestedDt,simulationTime,false);
        diag.result(result,-1,-1);
        if(result!=0)
        {TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);}
        diag.accept(requestedDt,requestedDt);
    }
    else while(elapsed<requestedDt)
    {
        const Time remaining=requestedDt-elapsed;
        if(substep>remaining)substep=remaining;
        if(refining && (++attempts>controls.maximumAttempts || elapsed+substep==elapsed
            || !(substep>Time(0))))
        {refining=false;substep=remaining;}
        diag.start(substep,elapsed,refining,attempts);
        const int result=advanceGasTrial<TrialPolicy>(s,substep,simulationTime+elapsed,refining);
        if(result==0)
        {
            diag.result(result,-1,-1);
            elapsed+=substep;
            diag.accept(substep,elapsed);
            if(elapsed<requestedDt)substep*=Time(2);
        }
        else
        {
            const bool retryable=TrialPolicy::retryable(s);
            if(!retryable)
            {
                const bool terminal=refining && gasTrialCanContinueTerminal<TrialPolicy>(s,0);
                diag.result(result,0,refining?int(terminal):-1);
                if(terminal)
                {refining=false;substep=remaining;continue;}
                TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);
            }
            diag.result(result,1,-1);
            if(!refining)
            {TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);}
            substep*=Time(.5);
            if(substep<controls.minimumSubstep)
            {refining=false;substep=remaining;}
        }
    }
    if(TrialPolicy::commitInterval(s)!=0)
    {TrialPolicy::rollbackInterval(s);diag.rollback(true);return diag.finish(1);}
    return diag.finish(0);
}
'''

def instrument(text):
    marker='template<class TrialPolicy, class GasHostState>\nint advanceGasTrial\n'
    assert text.count(marker)==1
    owner='template<class TrialPolicy, class GasHostState>\nint advanceGasRequestedInterval\n'
    assert text.count(owner)==1
    original_owner=text[text.index(owner):]
    assert original_owner.rstrip().endswith('return 0;\n}')
    text=text[:text.index(owner)]+OWNER.lstrip()
    assert text.count('TrialPolicy::rollback(s); return 1;')==2
    text=text.replace('TrialPolicy::rollback(s); return 1;','TrialPolicy::rollback(s);ugkpDiagnosticTrialRollback(); return 1;')
    text=text.replace(marker,HELPER+marker)
    return text,original_owner

def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=pathlib.Path);p.add_argument('destination',type=pathlib.Path)
    args=p.parse_args();source=args.source.resolve();dest=args.destination.resolve()
    if dest.exists():raise SystemExit('Destination already exists; use a new diagnostic snapshot path: '+str(dest))
    dest.mkdir(parents=True)
    paths=['common','applications/gasUGKP/gpu','applications/gasUGKP/private_backend']
    for part in paths:
        shutil.copytree(source/part,dest/part,ignore=shutil.ignore_patterns('build','build_logs','*.a','*.o','*.dep'))
    header=pathlib.Path('common/GpuGasAdvance.cuh');original=(dest/header).read_text();changed,owner=instrument(original)
    (dest/header).write_text(changed)
    (dest/'host-instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='a/'+str(header),tofile='b/'+str(header))))
    (dest/'original-owner.cuh').write_text(owner)
    (dest/'instrumented-owner.cuh').write_text(OWNER)
    (dest/'diagnostic-helper.cuh').write_text(HELPER)
    inputs={str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in paths for p in (dest/folder).rglob('*') if p.is_file()}
    source_inputs={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in inputs}
    changed_paths=[name for name in inputs if inputs[name]!=source_inputs[name]]
    assert changed_paths==[str(header)],changed_paths
    report={'source':str(source),'diagnostic_copy':str(dest),'source_head':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'changed_paths':changed_paths,'source_hashes':source_inputs,'diagnostic_hashes':inputs,'original_header_sha256':hashlib.sha256(original.encode()).hexdigest(),'diagnostic_header_sha256':hashlib.sha256(changed.encode()).hexdigest()}
    (dest/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
    print(dest)
if __name__=='__main__':main()
