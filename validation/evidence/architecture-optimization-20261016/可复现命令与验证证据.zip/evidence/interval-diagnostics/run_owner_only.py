"""Execute C-seed's real owner controls after exclusive GPU scheduling."""
import datetime,hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path(__file__).resolve().parent;out=root/'owner-C-seed';exe=out/'owner_only'
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (out/'run.stdout').open('w') as stdout,(out/'run.stderr').open('w') as stderr:
 result=subprocess.run([str(exe)],stdout=stdout,stderr=stderr)
record={'argv':[str(exe)],'started_utc':start,'elapsed_seconds':time.monotonic()-t,'exit_code':result.returncode,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'designation':'C-seed; original ownerTests only'}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
if result.returncode:raise SystemExit(result.returncode)
text=(out/'run.stdout').read_text();markers=['PASS requested owner accepted trace','PASS terminal owner completion','PASS original successful requested interval','PASS original direct chemistry success']
for marker in markers:assert sum(line.startswith(marker) for line in text.splitlines())==1,marker
assert text.splitlines().count('PASS real CUDA owner-only controls complete')==1
trace=re.findall(r'OWNER_TRACE begins=(\d+) commits=(\d+) rollbacks=(\d+) stepLimits=(\d+) terminal=(\d+)',text)
assert len(trace)==1
summary={'validated_original_controls':4,'owner_trace':dict(zip(['begins','commits','rollbacks','stepLimits','terminal'],map(int,trace[0]))),'accepted_duration_count':len(re.findall(r'^OWNER_ACCEPT ',text,re.M)),'complete':True,'not_covered':'enabled boundary-layer wall/profile rollback and the 16-case failure matrix'}
(out/'run-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
