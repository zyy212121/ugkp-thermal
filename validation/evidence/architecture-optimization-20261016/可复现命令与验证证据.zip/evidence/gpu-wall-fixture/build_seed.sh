#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd)
source_root=${1:?source checkout required}
name=${2:?A/B/C identifier required}
team=${3:?0 scalar or 1 team required}
fmad=${4:-true}
mkdir -p "$here/bin" "$here/logs"
nvcc_path=${NVCC:-/usr/local/cuda/bin/nvcc}
command=("$nvcc_path" -std=c++17 -O3 --fmad="$fmad" -lineinfo -arch=sm_89 -Xptxas=-v -DWALL_TEAM="$team" -I "$source_root" -I "$source_root/common" "$here/seed_probe.cu" -o "$here/bin/$name")
printf '%q ' "${command[@]}" > "$here/logs/build-$name.command"
printf '\n' >> "$here/logs/build-$name.command"
"$nvcc_path" --version > "$here/logs/build-$name.toolchain"
set +e
"${command[@]}" > "$here/logs/build-$name.log" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$here/logs/build-$name.exit"
if ((result)); then tail -n 60 "$here/logs/build-$name.log"; exit "$result"; fi
sha256sum "$here/bin/$name" > "$here/logs/build-$name.sha256"
git -C "$source_root" rev-parse HEAD > "$here/logs/build-$name.head"
sha256sum "$here/seed_probe.cu" "$source_root/common/gasWall/ReactingWallLayer.H" "$source_root/common/gasTransport/GasBoundaryLayerModelState.H" > "$here/logs/build-$name.inputs.sha256"
cat "$here/logs/build-$name.sha256"
