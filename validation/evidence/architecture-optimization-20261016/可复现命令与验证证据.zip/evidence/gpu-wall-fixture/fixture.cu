#include <cuda_runtime.h>
#include "common/gasTransport/GasBoundaryLayerModelState.H"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <new>
#include <string>
using namespace ugkwp;
using namespace ugkwp::gaswall;

// Numerical inputs are transcribed from test_wall_model.py BASE and
// test_wall_team_equivalence.py run(mode). Ns=10 cases retain the exact-zero
// creation test's physical data; the capacity is a production capacity bucket.
template<int N> struct Model {
 SpeciesThermoData<double> sp[N]; double coef[3*N]{};
 double elements[N]{},basis[N]{};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,N> in;
 Model(){
  for(int s=0;s<N;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;
   sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;
   if constexpr(N==2){sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
   coef[3*s]=1000;elements[s]=1;in.model.diffusivity[s]=1e-5;}
  basis[0]=-1;basis[N-1]=1;
  auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=3*N;
  t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
  rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;
  re[0].species=0;re[0].coefficient=1;pr[0].species=N-1;pr[0].coefficient=1;
  auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;
  m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;
  m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
  in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
  in.matching.temperature=500;in.matching.velocity[0]=10;
  in.matching.massFraction[0]=.7;in.matching.massFraction[N-1]=.3;
  in.model.viscosity=2e-5;in.model.conductivity=.04;
 }
};

template<int N> void configure(Model<N>& m,WallModelConfig<double>& c,int mode){
 c.nodes=mode==4?40:24;c.enableSst=mode!=0;c.maxIterations=mode==2?1:60;
 m.in.model.mode=mode==3?GasMode::MixtureChemistry:GasMode::MixtureFrozen;
 m.in.matching.k=.5;m.in.matching.omega=200;m.in.integrateOwnerKSource=false;
 if(mode==5)m.in.matching.massFraction[N-1]=0,m.in.matching.massFraction[0]=1;
 if(mode==6)m.in.matching.temperature=std::numeric_limits<double>::quiet_NaN();
 if(mode>=7&&mode<=9){unsigned seed=4321;const int selected=mode==7?11:(mode==8?29:150);
  for(int index=0;index<=selected;++index){auto random=[&](){seed=1664525*seed+1013904223;return double(seed)/4294967296.;};
   const double L=std::pow(10.,-4+3*random()),Tw=250+800*random(),Te=300+1500*random(),u=std::pow(10.,-1+4*random());
   const double k=std::pow(10.,-10+12*random()),omega=std::pow(10.,-2+7*random()),mass=std::pow(10.,-8+8*random());
   const bool sst=index%2==0;double formation=0,rate=2;if(!sst){formation=1e5+3e5*random();rate=std::pow(10.,3*random());}
   if(index==selected){m.in.matchingDistance=L;m.in.ownerDistance=.4*L;m.in.temperature=Tw;
    m.in.matching.temperature=Te;m.in.matching.velocity[0]=u;m.in.matching.k=k;m.in.matching.omega=omega;
    m.in.massFlux[0]=.7*mass;m.in.massFlux[N-1]=.3*mass;c.nodes=16;c.maxIterations=80;c.enableSst=sst;
    if(!sst){m.in.model.mode=GasMode::MixtureChemistry;m.coef[2]=formation;m.rx[0].highRate.preExponential=rate;
     m.in.model.diffusivity[0]=1e-4;m.in.model.diffusivity[N-1]=3e-4;}}
  }
 }
 if(mode==10){c.nodes=65;c.enableSst=false;}
 if(mode==11)c.model=BoundaryLayerModel::ConstantTransport;
 if(mode==12)c.model=static_cast<BoundaryLayerModel>(99);
 if(mode==13||mode==14){
  c=WallModelConfig<double>{};c.nodes=mode==13?24:32;c.maxIterations=mode==13?60:100;
  m.in.temperature=m.in.matching.temperature=500;m.in.matching.velocity[0]=0;m.in.matching.k=0;m.in.matching.omega=0;
  for(int s=0;s<N;++s){m.in.matching.massFraction[s]=s==0?1:0;m.in.model.diffusivity[s]=1e-4;}
  m.rx[0].highRate.preExponential=mode==13?2:400;m.in.model.mode=GasMode::MixtureChemistry;
 }
}

template<int N,int Capacity> struct Record {
 bool success=false;WallOutput<double,N> out;WallStatus status;
 double state[Capacity][N+4]{},y[Capacity]{},profile[Capacity*(7+N)]{};
};

// This test harness uses the actual production workspace entrypoint and team,
// with the same worker-to-slot stepping as the production kernels. It omits
// GasState preparation/publication and is not a whole-solver validation.
template<bool Capture,int N,int Capacity>
__global__ void workspaceKernel(Model<N>* inputs,WallModelConfig<double> config,
 WallWorkspace<double,N,Capacity>* work,Record<N,Capacity>* records,int slots,int workers){
#if WALL_TEAM
 const int worker=blockIdx.x;
 if(worker>=workers)return;
 const ugkwp::gaswall::detail::CudaWallTeam team{};
#else
 const int worker=blockIdx.x*blockDim.x+threadIdx.x;
 if(worker>=workers)return;
#endif
 for(int slot=worker;slot<slots;slot+=workers){
  auto& r=records[slot];auto& w=work[worker];
#if WALL_TEAM
  bool ok=evaluateGasBoundaryLayerWorkspace<Capture>(inputs[slot].in,config,w,r.out,r.status,r.profile,team);
  if(team.leader()){
#else
  bool ok=evaluateGasBoundaryLayerWorkspace<Capture>(inputs[slot].in,config,w,r.out,r.status,r.profile);
  {
#endif
   r.success=ok;
   for(int node=0;node<config.nodes;++node){r.y[node]=w.y[node];
    for(int col=0;col<N+4;++col)r.state[node][col]=w.state[node][col];}
  }
#if WALL_TEAM
  team.sync();
#endif
 }
}

static void check(cudaError_t e,const char* call){if(e!=cudaSuccess){std::fprintf(stderr,"%s: %s\n",call,cudaGetErrorString(e));std::exit(2);}}
#define CUDA(call) check((call),#call)
template<class T> T* managed(int n){T* p=nullptr;CUDA(cudaMallocManaged(&p,sizeof(T)*n));for(int i=0;i<n;++i)new(p+i) T;return p;}
static void bits(const char* label,double value){std::uint64_t u;std::memcpy(&u,&value,sizeof(u));std::printf("%s=%016llx\n",label,(unsigned long long)u);}
static void integer(const char* label,int value){std::printf("%s=%d\n",label,value);}
template<int N,int Capacity> void dump(const Record<N,Capacity>& r,int nodes,bool capture){
 integer("success",r.success);integer("status.code",int(r.status.code));integer("status.node",r.status.node);
 integer("status.iteration",r.status.iteration);bits("status.residual",r.status.residual);
 const auto& o=r.out;
 bits("out.traceTemperature",o.traceTemperature);bits("out.traceDensity",o.traceDensity);
 bits("out.conductiveHeatFlux",o.conductiveHeatFlux);bits("out.integratedKSource",o.integratedKSource);
 bits("out.ownerOmega",o.ownerOmega);bits("out.wallKFlux",o.wallKFlux);
 integer("out.chemistryMismatchAvailable",o.chemistryMismatchAvailable);integer("out.iterations",o.iterations);bits("out.residual",o.residual);
 for(int d=0;d<3;++d){bits("out.traceVelocity",o.traceVelocity[d]);bits("out.traction",o.traction[d]);}
 for(int s=0;s<N;++s){bits("out.traceMassFraction",o.traceMassFraction[s]);bits("out.wallSpeciesFlux",o.wallSpeciesFlux[s]);
  bits("out.matchingSpeciesFlux",o.matchingSpeciesFlux[s]);bits("out.reactionIntegral",o.reactionIntegral[s]);
  bits("out.chemistryMismatch",o.chemistryMismatch[s]);bits("out.speciesBalanceResidual",o.speciesBalanceResidual[s]);}
 for(int node=0;node<nodes;++node){bits("workspace.y",r.y[node]);for(int col=0;col<N+4;++col)bits("workspace.state",r.state[node][col]);}
 if(capture)for(int i=0;i<nodes*(7+N);++i)bits("profile",r.profile[i]);
}

template<bool Capture,int N,int Capacity> void run(int mode,int slots,int workers,int repeats){
 auto* inputs=managed<Model<N>>(slots);auto* work=managed<WallWorkspace<double,N,Capacity>>(workers);
 auto* records=managed<Record<N,Capacity>>(slots);WallModelConfig<double> config;
 for(int slot=0;slot<slots;++slot){configure(inputs[slot],config,mode);
  // Use the original fixture unchanged for slot 0 and three distinct physical
  // wall temperatures for subsequent slots to make reuse bugs observable.
  if(slot)inputs[slot].in.temperature+=double(slot%3)*0.125;
  for(auto& value:records[slot].profile)value=-987654.25;
 }
 for(int repeat=0;repeat<repeats;++repeat){
#if WALL_TEAM
  workspaceKernel<Capture,N,Capacity><<<workers,32>>>(inputs,config,work,records,slots,workers);
#else
  workspaceKernel<Capture,N,Capacity><<<(workers+31)/32,32>>>(inputs,config,work,records,slots,workers);
#endif
  CUDA(cudaGetLastError());CUDA(cudaDeviceSynchronize());
  for(int slot=0;slot<slots;++slot){std::printf("CASE mode=%d ns=%d nodes=%d capacity=%d capture=%d slots=%d workers=%d repeat=%d slot=%d\n",
   mode,N,config.nodes,Capacity,int(Capture),slots,workers,repeat,slot);dump(records[slot],config.nodes,Capture);std::puts("END");}
 }
 CUDA(cudaFree(records));CUDA(cudaFree(work));CUDA(cudaFree(inputs));
}
template<bool Capture> void dispatch(int mode,int slots,int workers,int repeats){
 if(mode==13)run<Capture,10,24>(mode,slots,workers,repeats);
 else if(mode==14)run<Capture,10,48>(mode,slots,workers,repeats);
 else if(mode==4)run<Capture,2,48>(mode,slots,workers,repeats);
 else if(mode==10)run<Capture,2,128>(mode,slots,workers,repeats);
 else run<Capture,2,24>(mode,slots,workers,repeats);
}
int main(int argc,char** argv){
 // Positional args: mode (-1 means all), capture (-1 means both), slots,
 // workers, repeats. Capture is compile-time at the production call site.
 int mode=argc>1?std::atoi(argv[1]):-1,capture=argc>2?std::atoi(argv[2]):-1;
 int slots=argc>3?std::atoi(argv[3]):5,workers=argc>4?std::atoi(argv[4]):2,repeats=argc>5?std::atoi(argv[5]):2;
 if(mode < -1 || mode>14 || capture < -1 || capture>1 || slots<1 || workers<1 || repeats<1)return 64;
 CUDA(cudaSetDevice(0));CUDA(cudaDeviceSetLimit(cudaLimitStackSize,32768));
 for(int m=0;m<=14;++m)if(mode<0||m==mode){if(capture!=1)dispatch<false>(m,slots,workers,repeats);if(capture!=0)dispatch<true>(m,slots,workers,repeats);}
 return 0;
}
