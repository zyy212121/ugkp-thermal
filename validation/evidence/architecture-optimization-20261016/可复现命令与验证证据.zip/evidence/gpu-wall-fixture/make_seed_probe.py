"""Derive input/dump utilities from fixture; probe the real production seed only."""
from pathlib import Path
here=Path(__file__).resolve().parent
s=(here/'fixture.cu').read_text()
prefix=s[:s.index('// This test harness')]
helpers=s[s.index('static void check'):s.index('template<bool Capture,int N,int Capacity> void run')]
kernel=r'''
__global__ void seedProbe(Model<2>* input,WallModelConfig<double> c,
 WallWorkspace<double,2,24>* work,Record<2,24>* record){
#if WALL_TEAM
 const ugkwp::gaswall::detail::CudaWallTeam team{};
 const int rank=team.rank(),width=team.size();
#else
 if(threadIdx.x)return;
 const int rank=0,width=1;
#endif
 auto& in=input->in;auto& w=*work;
 ugkwp::gaswall::detail::LayerContext<double,2> ctx;
 const bool context=ugkwp::gaswall::detail::makeContext(in,c,ctx);
 if(!context)return;
 // Identical initialization from production evaluateReactingWallLayerImpl.
 for(int i=rank;i<c.nodes;i+=width){const double eta=double(i)/double(c.nodes-1),f=::pow(eta,c.stretch);
  w.y[i]=in.matchingDistance*f;w.state[i][0]=f*ctx.edgeU[0];w.state[i][1]=f*ctx.edgeU[1];
  w.state[i][2]=f*(in.matching.temperature-in.temperature);
  for(int j=0;j<1;++j)w.state[i][3+j]=in.matching.massFraction[ctx.independent[j]];
  w.state[i][4]=::sqrt(in.matching.k)*f;w.state[i][5]=f/::sqrt(in.matching.omega);
  for(int j=0;j<6;++j)w.trial[i][j]=w.state[i][j];
 }
#if WALL_TEAM
 team.sync();
 const bool result=ugkwp::gaswall::detail::seedSstLayer(in,c,ctx,w,team);
#else
 const bool result=ugkwp::gaswall::detail::seedSstLayer(in,c,ctx,w);
#endif
 if(rank==0){record->success=result;
  for(int i=0;i<c.nodes;++i){record->y[i]=w.y[i];for(int j=0;j<6;++j)record->state[i][j]=w.state[i][j];}
 }
}
int main(){
 CUDA(cudaSetDevice(0));CUDA(cudaDeviceSetLimit(cudaLimitStackSize,32768));
 auto* model=managed<Model<2>>(1);auto* work=managed<WallWorkspace<double,2,24>>(1);auto* r=managed<Record<2,24>>(1);
 WallModelConfig<double> c;configure(*model,c,1);
 seedProbe<<<1,32>>>(model,c,work,r);CUDA(cudaGetLastError());CUDA(cudaDeviceSynchronize());
 std::puts("CASE mode=1 ns=2 nodes=24 capacity=24 capture=0 slots=1 workers=1 repeat=0 slot=0 stage=seed");dump(*r,24,false);std::puts("END");
 CUDA(cudaFree(r));CUDA(cudaFree(work));CUDA(cudaFree(model));
}
'''
(here/'seed_probe.cu').write_text(prefix+helpers+kernel)
