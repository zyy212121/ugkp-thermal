#!/usr/bin/env python3
"""Sequential GPU validation runner. Run only after reserving the GPU."""
import argparse,datetime,hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
logs=root/'logs'
def execute(label,cmd):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    with (logs/(label+'.out')).open('w') as out,(logs/(label+'.stderr')).open('w') as err:
        p=subprocess.run(cmd,stdout=out,stderr=err,cwd=root)
    result={'command':cmd,'cwd':str(root),'started_utc':started,'elapsed_seconds':time.monotonic()-t,'exit_code':p.returncode}
    (logs/(label+'.run.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(label,p.returncode,flush=True)
    return p.returncode
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--versions',nargs='+',default=['A','B'])
    parser.add_argument('--sanitizers',nargs='*',default=[]);args=parser.parse_args();logs.mkdir(exist_ok=True)
    subprocess.run(['nvidia-smi','-q'],stdout=(logs/'gpu-before.txt').open('w'),check=True)
    failed=False
    for version in args.versions:
        executable=str(root/'bin'/version)
        code=execute(version,[executable,'-1','-1','5','2','2']);failed|=bool(code)
        # More workers than slots exercises CTA-wide no-work paths.
        code=execute(version+'-extra-workers',[executable,'0','-1','3','8','1']);failed|=bool(code)
    for version in args.versions[1:]:
        for suffix in ['', '-extra-workers']:
            label=args.versions[0]+'-'+version+suffix+'-comparison'
            failed|=bool(execute(label,[sys.executable,str(root/'compare.py'),str(logs/(args.versions[0]+suffix+'.out')),str(logs/(version+suffix+'.out'))]))
    for version in args.sanitizers:
        for tool in ['memcheck','racecheck','synccheck']:
            label=version+'-'+tool
            failed|=bool(execute(label,['/usr/local/cuda/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86','--log-file',str(logs/(label+'.log')),str(root/'bin'/version),'-1','-1','5','2','1']))
    subprocess.run(['nvidia-smi','-q'],stdout=(logs/'gpu-after.txt').open('w'),check=True)
    manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.name!='manifest.json'}
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return int(failed)
if __name__=='__main__':sys.exit(main())
