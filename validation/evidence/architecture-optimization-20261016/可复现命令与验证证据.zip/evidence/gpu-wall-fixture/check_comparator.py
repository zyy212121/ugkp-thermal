"""A changed physical bit or integer must be reported as a mismatch."""
from compare import compare,capture_check
base={'CASE mode=0 capture=0':['success=1','out.residual=0000000000000000']}
assert not compare(base,base)
one_bit={'CASE mode=0 capture=0':['success=1','out.residual=0000000000000001']}
assert compare(base,one_bit)
wrong_status={'CASE mode=0 capture=0':['success=0','out.residual=0000000000000000']}
assert compare(base,wrong_status)
assert compare(base,{})
onoff=dict(base);onoff['CASE mode=0 capture=1']=base['CASE mode=0 capture=0']+['profile=8000000000000000']
assert not capture_check(onoff)
onoff['CASE mode=0 capture=1']=['success=1','out.residual=0000000000000001','profile=8000000000000000']
assert capture_check(onoff)
print('comparator: exact bit, integer, missing case, and capture physics sensitivity passed')
