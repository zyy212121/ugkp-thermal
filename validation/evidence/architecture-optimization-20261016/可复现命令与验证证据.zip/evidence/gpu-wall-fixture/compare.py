#!/usr/bin/env python3
"""Compare only explicitly serialized initialized scalars, never struct bytes."""
import argparse,json,pathlib,sys
def read(path):
    cases={}; key=None; rows=[]
    for line in pathlib.Path(path).read_text().splitlines():
        if line.startswith('CASE '):
            if key is not None: raise ValueError('unterminated case')
            key=line;rows=[]
        elif line=='END':
            if key is None or key in cases:raise ValueError('invalid/duplicate case')
            cases[key]=rows;key=None
        elif key is not None:rows.append(line)
        else:raise ValueError('unexpected output: '+line)
    if key is not None or not cases:raise ValueError('empty/incomplete output')
    return cases
def compare(a,b):
    failures=[]
    if a.keys()!=b.keys():failures.append({'case_keys':{'missing':list(a.keys()-b.keys()),'extra':list(b.keys()-a.keys())}})
    for key in a.keys() & b.keys():
        if a[key]!=b[key]:
            rows=[{'row':i,'expected':x,'actual':y} for i,(x,y) in enumerate(zip(a[key],b[key])) if x!=y]
            failures.append({'case':key,'expected_rows':len(a[key]),'actual_rows':len(b[key]),'differences':rows[:20], 'differing_common_rows':len(rows)})
    return failures
def capture_check(cases):
    pair={}
    for key,rows in cases.items():
        fields=dict(x.split('=') for x in key[5:].split())
        cap=fields.pop('capture');newkey=tuple(sorted(fields.items()))
        pair.setdefault(newkey,{})[cap]=[r for r in rows if not r.startswith('profile=')]
    return [str(key) for key,values in pair.items() if set(values)=={'0','1'} and values['0']!=values['1']]
def main():
    p=argparse.ArgumentParser();p.add_argument('expected');p.add_argument('actual');args=p.parse_args()
    a,b=read(args.expected),read(args.actual);failures=compare(a,b);capture={'expected':capture_check(a),'actual':capture_check(b)}
    status_counts={}
    for rows in b.values():
        code=next(r.split('=')[1] for r in rows if r.startswith('status.code='));status_counts[code]=status_counts.get(code,0)+1
    report={'comparison':'explicit IEEE754 FP64 bit patterns and integer fields','expected_cases':len(a),'actual_cases':len(b),'status_counts':status_counts,'bitwise_equal':not failures,'capture_changes_physics':capture,'failures':failures}
    print(json.dumps(report,indent=2));return int(bool(failures or any(capture.values())))
if __name__=='__main__':sys.exit(main())
