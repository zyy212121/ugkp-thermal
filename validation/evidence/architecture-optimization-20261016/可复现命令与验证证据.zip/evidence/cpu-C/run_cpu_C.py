import concurrent.futures, hashlib, json, os, re, subprocess, time
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path('/home/lss/arc3696-work/astra-architecture-20261016/C')
OUT=ROOT.parent/'evidence/cpu-C'
OLD=Path('/home/lss/arc3696-work/evidence/arc3696-20261016/wall-uniform-work-20261016T061401Z')
OUT.mkdir(parents=True,exist_ok=True)
spec=json.loads((OLD/'tests-accepted-command.json').read_text())
historical_manifest=json.loads((OLD/'accepted-source-manifest.json').read_text())
source_paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
manifest={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in source_paths if p and (ROOT/p).is_file()}
def now():return datetime.now(timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in manifest}
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
os.nice(10)
env=dict(os.environ,**spec['env'],PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTEST_ADDOPTS',None)
save(OUT/'source-before.json',hashes())
review={
 'utc':now(), 'scope':'Same 94 selected test files, imported helpers and conftest hooks as CPU-B; B-to-C changes are the production cache header plus two separately executed new test files.',
 'gpu_launching_items_in_selected_set':[],
 'notes':[
   'All selected functional probes compile with g++ and run host executables; CUDA APIs appearing in their source strings are host mocks/adapters.',
   'test_t10_particle_authority imports only cache_path_fixture from excluded test_full_heat_advance; this pure source-string helper does not invoke native CUDA compile/run tests.',
   'pytest_sessionstart invokes first_round_history/continuation_history prepare.py, which only check/import offline Git objects; no solver/GPU launch.',
   'No additional exclusions beyond the six historical exclusions are needed.'],
 'historical_excluded_files':spec['excluded_gpu_or_mixed_tool_tests'],
 'execution_env_overrides':{**spec['env'],'PYTHONDONTWRITEBYTECODE':'1'},
 'execution_changes':'nice +10; no pytest cache; external basetemp/JUnit; clear ambient PYTEST_ADDOPTS to retain recorded collection.'}
save(OUT/'cpu-scope-review.json',review)
commands=[]
for i,g in enumerate(spec['groups']):
    common=g['argv']+['-p','no:cacheprovider']
    collect=common+['--collect-only']
    with (OUT/f'group{i}-collect.log').open('w') as f:
        rc=subprocess.run(collect,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    (OUT/f'group{i}-collect.exit-code').write_text(str(rc)+'\n')
    nodes=[x for x in (OUT/f'group{i}-collect.log').read_text().splitlines() if (x.startswith('validation/') or x.startswith('::')) and '::' in x]
    (OUT/f'group{i}-collected-nodeids.txt').write_text('\n'.join(nodes)+'\n')
    commands.append({'group':i,'original_argv':g['argv'],'collection_argv':collect,'collection_exit':rc,
                     'collected_count':len(nodes),'argv':common+['--basetemp',str(OUT/f'tmp-group{i}'),'--junitxml',str(OUT/f'group{i}.xml')]})
    print(json.dumps({'group':i,'collection_exit':rc,'collected_count':len(nodes)}),flush=True)
save(OUT/'commands.json',{'cwd':str(ROOT),'env_overrides':review['execution_env_overrides'],'concurrency':2,'groups':commands,'excluded':spec['excluded_gpu_or_mixed_tool_tests']})
if any(x['collection_exit'] for x in commands):raise SystemExit('Collection failed; inspect logs, no test groups launched')
def run(g):
    i=g['group'];start=time.monotonic();started=now()
    print(json.dumps({'group':i,'started_utc':started}),flush=True)
    with (OUT/f'group{i}.log').open('w') as f:
        rc=subprocess.run(g['argv'],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    (OUT/f'group{i}.exit-code').write_text(str(rc)+'\n')
    lines=(OUT/f'group{i}.log').read_text().splitlines()
    tail=next((x for x in reversed(lines) if re.search(r'\b\d+ (passed|failed|error)',x)),None)
    row={'group':i,'exit_code':rc,'started_utc':started,'finished_utc':now(),'wall_seconds':time.monotonic()-start,'summary_line':tail,'collected_count':g['collected_count']}
    save(OUT/f'group{i}-result.json',row)
    print(json.dumps(row),flush=True)
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,commands))
after=hashes();save(OUT/'source-after.json',after)
before=json.loads((OUT/'source-before.json').read_text())
summary={'finished_utc':now(),'source_root':str(ROOT),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'results':results,'source_changes':[p for p in manifest if before[p]!=after[p]],
         'source_changes_from_historical_B':[p for p in historical_manifest if after[p]!=historical_manifest[p]],
         'source_files_added_over_historical_B':sorted(set(manifest)-set(historical_manifest)),
         'excluded':spec['excluded_gpu_or_mixed_tool_tests'],'gpu_targets_executed':[]}
save(OUT/'summary.json',summary)
print(json.dumps({'summary':str(OUT/'summary.json'),'results':results,'source_changes':summary['source_changes']}),flush=True)
