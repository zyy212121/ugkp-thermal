import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path
OUT=Path('/home/lss/arc3696-work/astra-architecture-20261016/evidence/cpu-C')
OLD=Path('/home/lss/arc3696-work/evidence/arc3696-20261016/wall-uniform-work-20261016T061401Z')
oracle=json.loads((OLD/'exact-particle-baseline-manifest.json').read_text())
oracle_root=OLD/'exact-particle-baseline-ab900f54'
diff=[p for p,h in oracle['files'].items() if hashlib.sha256((oracle_root/p).read_bytes()).hexdigest()!=h]
record={'root':str(oracle_root),'commit':oracle['commit'],'files_checked':len(oracle['files']),'mismatches':diff}
(OUT/'baseline-oracle-check.json').write_text(json.dumps(record,indent=2)+'\n')
summary=json.loads((OUT/'summary.json').read_text())
commands=json.loads((OUT/'commands.json').read_text())
counts=[]
for i in range(4):
    items=json.loads((OUT/f'group{i}-collected-items.json').read_text())
    root=ET.parse(OUT/f'group{i}.xml').getroot()
    suites=root.findall('testsuite') if root.tag!='testsuite' else [root]
    n={key:sum(int(x.attrib.get(key,0)) for x in suites) for key in ('tests','errors','failures','skipped')}
    n['passed']=n['tests']-n['errors']-n['failures']-n['skipped']
    n['group']=i
    assert n['tests']==len(items),(i,n,len(items))
    counts.append(n)
    commands['groups'][i]['collected_count']=len(items)
    summary['results'][i]['collected_count']=len(items)
    result=json.loads((OUT/f'group{i}-result.json').read_text())
    result['collected_count']=len(items)
    (OUT/f'group{i}-result.json').write_text(json.dumps(result,indent=2)+'\n')
summary['junit_counts']=counts
cpp14=[]
for i in range(4):
    items=json.loads((OUT/f'group{i}-collected-items.json').read_text())
    cases=list(ET.parse(OUT/f'group{i}.xml').getroot().iter('testcase'))
    for item in items:
        name=item['location'][2]
        selected=('test_wall_entrypoint_compatibility.py' in item['path']
                  or 'test_seed_system_team.py' in item['path']
                  or ('test_wall_local_efficiency.py' in item['path'] and name.endswith('[14]')))
        if selected:
            matched=[x for x in cases if x.attrib.get('name')==name]
            cpp14.append({'group':i,'source_file':item['path'],'test':name,
                          'junit_matched':len(matched),
                          'passed':bool(matched) and all(not any(x.tag in ('error','failure','skipped') for x in tc) for tc in matched)})
summary['existing_cpp14_fixture_tests']=cpp14
summary['totals']={k:sum(x[k] for x in counts) for k in ('tests','errors','failures','skipped','passed')}
summary['collection_record_note']='Groups 1 and 2 pytest text nodeids omit filename prefix. Initial launcher count parser was corrected using separately saved collection hook item records, verified against JUnit totals. No tests were rerun for this correction.'
summary['baseline_oracle_check']=record
summary['tool_versions']=[]
for argv in (['python3','--version'],['python3','-m','pytest','--version'],['g++','--version']):
    proc=subprocess.run(argv,capture_output=True,text=True)
    summary['tool_versions'].append({'argv':argv,'exit_code':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr})
summary['evidence_finalized_utc']=datetime.now(timezone.utc).isoformat()
(OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ('run_cpu_C.py','collection_recorder.py','capture_C_collection_details.py','finalize_C_cpu_records.py'):
    shutil.copyfile(Path(__file__).parent/name,OUT/name)
print(json.dumps({'summary':str(OUT/'summary.json'),'totals':summary['totals'],'source_changes':summary['source_changes'],'oracle_check':record},indent=2))
