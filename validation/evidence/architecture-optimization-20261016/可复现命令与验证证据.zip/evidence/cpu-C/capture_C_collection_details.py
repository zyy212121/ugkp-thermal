import json,os,subprocess
from pathlib import Path
ROOT=Path('/home/lss/arc3696-work/astra-architecture-20261016/C')
OUT=ROOT.parent/'evidence/cpu-C'
OLD=Path('/home/lss/arc3696-work/evidence/arc3696-20261016/wall-uniform-work-20261016T061401Z')
spec=json.loads((OLD/'tests-accepted-command.json').read_text())
records=[]
for i,g in enumerate(spec['groups']):
    env=dict(os.environ,**spec['env'],PYTHONDONTWRITEBYTECODE='1',
             PYTHONPATH=str(Path(__file__).resolve().parent),ASTRA_COLLECTION_OUTPUT=str(OUT/f'group{i}-collected-items.json'))
    env.pop('PYTEST_ADDOPTS',None)
    argv=g['argv']+['-p','no:cacheprovider','-p','collection_recorder','--collect-only']
    with (OUT/f'group{i}-collection-detail.log').open('w') as f:
        rc=subprocess.run(argv,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    items=json.loads((OUT/f'group{i}-collected-items.json').read_text()) if rc==0 else []
    (OUT/f'group{i}-collected-nodeids.txt').write_text('\n'.join(x['nodeid'] for x in items)+'\n')
    records.append({'group':i,'argv':argv,'exit_code':rc,'count':len(items),'items_json':str(OUT/f'group{i}-collected-items.json')})
(OUT/'collection-details.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
