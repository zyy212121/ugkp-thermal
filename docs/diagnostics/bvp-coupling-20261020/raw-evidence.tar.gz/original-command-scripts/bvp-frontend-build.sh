#!/usr/bin/env bash
source /opt/openfoam10/etc/bashrc
set -eo pipefail
task_base=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/bvp-coupling-fix-20261020
export FOAM_USER_APPBIN="$task_base/bin"
export FOAM_USER_LIBBIN="$task_base/lib"
export TMPDIR="$task_base/tmp"
cd /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018/applications/gasUGKP
UGKWP_CUDA_EXE_INC='-DUGKWP_USE_CUDA -DUGKWP_GAS_SPECIES=2' wmake
