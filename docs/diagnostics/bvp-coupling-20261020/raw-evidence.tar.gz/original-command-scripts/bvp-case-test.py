from pathlib import Path
import json,hashlib,re,shutil,subprocess,time,sys,os
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018')
x=r.parent/'bvp-coupling-fix-20261020';o=Path('/mnt/d/tempt/ugkp-bvp-coupling-fix-20261020')
model=sys.argv[1];end=float(sys.argv[2]);assert .02305<end<=.02805
source=r.parent/'flux-continuation-20261020'/(model+'-HLLC');dest=x/(model+'-'+os.getenv('BVP_CASE_TAG','final'))
if not dest.exists():
    dest.mkdir();tp=min((p for p in source.iterdir()if p.is_dir()and re.fullmatch(r'[0-9.eE+-]+',p.name)),key=lambda p:abs(float(p.name)-.02305));assert abs(float(tp.name)-.02305)<1e-12
    for directory in ['0','constant','system',tp.name]:shutil.copytree(source/directory,dest/directory,symlinks=False)
    hashes={str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest()for p in dest.rglob('*')if p.is_file()}
    (o/(model+'-initial-manifest.json')).write_text(json.dumps({'copied_from':str(source),'restart_time':tp.name,'case':str(dest),'hashes':hashes},indent=2))
ctl=dest/'system/controlDict';s=ctl.read_text()
for key,value in [('endTime',format(end,'.12g')),('writeInterval',format(end,'.12g')),('logInterval','50')]:s=re.sub(r'\b'+key+r'\s+[^;]+;',key+' '+value+';',s)
ctl.write_text(s)
cmd=['bash','/mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work/bvp-run-case.sh',str(dest)]
tag=model+'-'+os.getenv('BVP_CASE_TAG','final')+'-'+format(end,'.8f')+'-'+time.strftime('%H%M%S');start=time.time()
events=[]
with (o/(tag+'.log')).open('w')as f:
 p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 for line in p.stdout:
  f.write(line);f.flush()
  m=re.search(r'UGKP_REPRO step=(\d+) time=([\deE.+-]+) dt=([\deE.+-]+)',line)
  if m:events.append({'step':int(m[1]),'time':float(m[2]),'dt':float(m[3]),'wall':time.time()})
 rc=p.wait()
blocks=[(b['wall']-a['wall'])/(b['step']-a['step'])for a,b in zip(events[1:],events[2:])]
bins=Path(os.getenv('BVP_BINARY_DIR',str(x/'bin')))
(o/(tag+'-command.json')).write_text(json.dumps({'command':cmd,'exit':rc,'seconds':time.time()-start,'restart':.02305,'end':end,'events':events,'seconds_per_step_blocks':blocks,'binaries':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in bins.iterdir()}},indent=2))
print(tag,'EXIT',rc,'seconds',time.time()-start,flush=True);raise SystemExit(rc)
