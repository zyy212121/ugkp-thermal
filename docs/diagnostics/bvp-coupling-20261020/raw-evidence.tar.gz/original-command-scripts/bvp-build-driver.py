from pathlib import Path
import subprocess,json,time,hashlib,sys
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018')
o=Path('/mnt/d/tempt/ugkp-bvp-coupling-fix-20261020')
cmd=['bash','/mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work/bvp-build.sh']
if len(sys.argv)>1 and sys.argv[1]=='frontend':cmd[1]=cmd[1].replace('bvp-build.sh','bvp-frontend-build.sh')
sources={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for directory in ['common','applications/gasUGKP']for p in (r/directory).rglob('*')if p.is_file()and p.suffix in ['.H','.cuh','.cu','.C','.inc']}
stamp=time.strftime('%Y%m%dT%H%M%S');start=time.time()
with (o/(stamp+'-full-build.log')).open('w')as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
manifest={'command':cmd,'exit':rc,'seconds':time.time()-start,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'source_hashes':sources}
for p in (r.parent/'bvp-coupling-fix-20261020/bin').glob('*'):manifest.setdefault('products',{})[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(o/(stamp+'-full-build.json')).write_text(json.dumps(manifest,indent=2));print(rc,stamp,flush=True)
raise SystemExit(rc)
