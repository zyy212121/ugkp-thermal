from pathlib import Path
import subprocess,json,time
x=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/bvp-coupling-fix-20261020');o=Path('/mnt/d/tempt/ugkp-bvp-coupling-fix-20261020')
for mode in ['plain','memcheck','racecheck','synccheck']:
 cmd=[str(x/'wall-volume-pool-gpu')]if mode=='plain'else['/usr/local/cuda-13.1/bin/compute-sanitizer','--tool',mode,'--error-exitcode','99',str(x/'wall-volume-pool-gpu')]
 t=time.time();q=subprocess.run(cmd,capture_output=True,text=True)
 (o/('gpu-interface-'+mode+'.log')).write_text(q.stdout+q.stderr)
 (o/('gpu-interface-'+mode+'.json')).write_text(json.dumps({'command':cmd,'exit':q.returncode,'seconds':time.time()-t},indent=2))
 print(mode,q.returncode,time.time()-t,flush=True)
 assert q.returncode==0,q.stdout+q.stderr

