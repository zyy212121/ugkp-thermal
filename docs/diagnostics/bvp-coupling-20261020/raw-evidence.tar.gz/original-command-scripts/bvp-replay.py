from pathlib import Path
import csv,hashlib,json,subprocess,time
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018')
X=R.parent/'bvp-coupling-fix-20261020';O=Path('/mnt/d/tempt/ugkp-bvp-coupling-fix-20261020')
P=Path('/mnt/d/tempt/ugkp-flux-continuation-20261020');previous=R.parent/'flux-continuation-20261020'
dest=O/'phase1-resistance-energy';dest.mkdir(exist_ok=True)
source=X/'phase1-replay.cpp';source.write_text((previous/'bvp-node-refinement.cpp').read_text())
exe=X/'phase1-replay';cmd=['g++','-std=c++17','-O2','-I'+str(R),str(source),'-o',str(exe)]
q=subprocess.run(cmd,capture_output=True,text=True);(dest/'build.log').write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
records=[];commands=[]
for label,name in [('of10','bvp-node-of10-input.csv'),('of10-matched','bvp-matching-of10-matched-input.csv'),('continuation','bvp-node-latest-input.csv')]:
    rows=[r for r in csv.DictReader((P/name).open())if int(r['owner'])in [90,7684,7782,7864,23080]]
    inp=dest/(label+'-input.csv')
    with inp.open('w')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
    for variant,binary in [('before',previous/'bvp-node-refinement'),('after',exe)]:
        for n in [24,48,128]:
            out=dest/f'{label}-{variant}-N{n}.csv';command=[str(binary),str(inp),str(out),str(n)];t=time.perf_counter()
            q=subprocess.run(command,capture_output=True,text=True);elapsed=time.perf_counter()-t
            (dest/f'{label}-{variant}-N{n}.log').write_text(q.stdout+q.stderr);commands.append({'command':command,'exit':q.returncode,'wall_seconds':elapsed});assert q.returncode==0,q.stderr
            values=list(csv.DictReader(out.open()));assert all(int(r['ok'])==1 and int(r['fatal'])==0 for r in values)
            records.extend({'input':label,'variant':variant,'nodes':n,**row}for row in values)
            r=next(r for r in values if r['owner']=='7782');print(label,variant,n,r['tauX'],r['qIntoGas'],r['ownerOmega'],r['residual'],r['iterations'],flush=True)
(dest/'summary.json').write_text(json.dumps({'commands':commands,'rows':records,'source_hashes':{f:hashlib.sha256((R/f).read_bytes()).hexdigest()for f in ['common/gasWall/ReactingWallLayer.H','common/gasWall/WallLayerMath.H']}},indent=2))
