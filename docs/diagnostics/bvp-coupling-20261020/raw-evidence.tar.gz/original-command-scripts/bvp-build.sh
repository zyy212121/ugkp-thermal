#!/usr/bin/env bash
source /opt/openfoam10/etc/bashrc
set -eo pipefail
task_base=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/bvp-coupling-fix-20261020
source_path=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018
export FOAM_USER_APPBIN="$task_base/bin"
export FOAM_USER_LIBBIN="$task_base/lib"
export CUDA_HOME=/usr/local/cuda-13.1
export UGKWP_CUDA_ARCH=sm_89
export UGKWP_GAS_SPECIES=2
export GAS_UGKP_FMAD=1
export UGKWP_CUDA_LOG_PHASE=bvp_volume_coupling_20261020
export CUDA_CACHE_PATH="$task_base/cuda-cache"
export TMPDIR="$task_base/tmp"
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
cd "$source_path"
bash tool/gasUGKP/build_private_backend.sh
