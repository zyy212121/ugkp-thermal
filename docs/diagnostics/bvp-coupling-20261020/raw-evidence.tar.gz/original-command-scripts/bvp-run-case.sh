#!/usr/bin/env bash
source /opt/openfoam10/etc/bashrc
set -eo pipefail
task_base=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/bvp-coupling-fix-20261020
export FOAM_USER_APPBIN="${BVP_BINARY_DIR:-$task_base/bin}"
export FOAM_USER_LIBBIN="$task_base/lib"
export GAS_UGKP_CUDA_BACKEND="$FOAM_USER_APPBIN/gasUGKPCudaBackend"
export CUDA_CACHE_PATH="$task_base/cuda-cache"
export TMPDIR="$task_base/tmp"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN:/usr/local/cuda-13.1/lib64:${FOAM_EXT_LIBBIN:-}:/usr/lib/x86_64-linux-gnu/openmpi/lib"
exec "$FOAM_USER_APPBIN/gasUGKP" -case "$1"
