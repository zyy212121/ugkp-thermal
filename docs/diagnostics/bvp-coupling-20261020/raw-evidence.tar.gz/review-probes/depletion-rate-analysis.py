from pathlib import Path
import re,numpy as np
x=Path("/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/bvp-coupling-fix-20261020/boundaryLayer-final/0.023060000000000001")
b=x.parent.parent.parent/"flux-fix-20261020/fixed-replay/baseline-018";vol=np.fromfile(b/"V.bin",dtype="<f8")
def f(name):
 a=(x/name).read_bytes();m=re.search(rb"internalField\s+nonuniform\s+List<scalar>\s+(\d+)\s*\(",a);return np.frombuffer(a,dtype="<f8",count=int(m[1]),offset=m.end())
rho=f("rho");k=f("k");area=(.37/96)*.001
for own,F in [(0,-141.16645694612828),(2,-148.43253978071624),(3,-144.03154409354562)]:
 c=own+96;rate=F*area/(rho[c]*vol[c]);print(own,c,"volume",vol[c],"rho",rho[c],"k",k[c],"F_A",F*area,"dkdt_flux",rate,"depletion_us",-k[c]/rate*1e6)
