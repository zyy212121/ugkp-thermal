
#include "common/gasWall/WallModel.H"
#include "common/gasWall/WallGeometryBuilder.H"
#include "common/gasTransport/GasBoundaryLayerState.H"
#include <map>
#include <algorithm>
#include <iomanip>
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}
using V=std::array<double,3>;
V add(V a,V b){return {a[0]+b[0],a[1]+b[1],a[2]+b[2]};}
V sub(V a,V b){return {a[0]-b[0],a[1]-b[1],a[2]-b[2]};}
V mul(V a,double b){return {a[0]*b,a[1]*b,a[2]*b};}
double dot(V a,V b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
V cross(V a,V b){return {a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}
struct MeshBuilder {
 WallGeometryMesh<double> m;
 std::map<std::vector<int>,int> seen;
 MeshBuilder(){m.faceOffsets.push_back(0);}
 int point(V p){for(int i=0;i<int(m.points.size());++i)if(m.points[i]==p)return i;m.points.push_back(p);return int(m.points.size())-1;}
 void cell(const std::vector<std::vector<V>>& faces,V centre,double volume){
  int c=int(m.cellCentres.size());m.cellCentres.push_back(centre);m.volumes.push_back(volume);
  for(auto f:faces){
   if(dot(cross(sub(f[1],f[0]),sub(f[2],f[0])),sub(f[0],centre))<0)std::reverse(f.begin(),f.end());
   std::vector<int> ids;for(auto p:f)ids.push_back(point(p));auto key=ids;std::sort(key.begin(),key.end());
   auto old=seen.find(key);if(old!=seen.end()){assert(m.neighbour[old->second]<0);m.neighbour[old->second]=c;continue;}
   int idx=int(m.owner.size());seen[key]=idx;m.owner.push_back(c);m.neighbour.push_back(-1);m.physicalWall.push_back(0);
   m.facePoints.insert(m.facePoints.end(),ids.begin(),ids.end());m.faceOffsets.push_back(int(m.facePoints.size()));
  }
 }
};
WallGeometryMesh<double> cubes(int count=3,double skew=0){
 MeshBuilder b;
 for(int k=0;k<count;++k){
  V a={skew*k,0,double(k)},bb={1+skew*k,0,double(k)},c={1+skew*k,1,double(k)},d={skew*k,1,double(k)};
  V e={skew*(k+1),0,double(k+1)},f={1+skew*(k+1),0,double(k+1)},g={1+skew*(k+1),1,double(k+1)},h={skew*(k+1),1,double(k+1)};
  b.cell({{a,bb,c,d},{e,f,g,h},{a,bb,f,e},{bb,c,g,f},{c,d,h,g},{d,a,e,h}}, {0.5+skew*(k+.5),.5,k+.5},1);
 }
 b.m.physicalWall[0]=1;return b.m;
}
WallGeometryMesh<double> tetra(){
 MeshBuilder b;V a={0,0,0},bb={2,0,0},c={0,2,0},d={.2,.3,1};
 b.cell({{a,bb,c},{a,bb,d},{bb,c,d},{c,a,d}}, {.55,.575,.25},2./3.);
 V e=add(bb,{0,0,3}),f=add(c,{0,0,3}),g=add(d,{0,0,3});
 b.cell({{bb,c,d},{e,f,g},{bb,c,f,e},{c,d,g,f},{d,bb,e,g}}, {2.2/3,2.3/3,11./6},4.5);
 b.m.physicalWall[0]=1;return b.m;
}
int main(){Model m;auto mesh=cubes(5);for(auto&p:mesh.points)for(auto&v:p)v*=.001;for(auto&p:mesh.cellCentres)for(auto&v:p)v*=.001;for(auto&v:mesh.volumes)v*=1e-9;
WallGeometryDescriptor<double>d;WallStatus st;WallGeometryOptions<double> opt;opt.profileNodes=128;opt.reconstructMatching=true;assert(buildWallGeometry(mesh,0,d,st,opt));m.in.quadrature=d.quadrature();m.in.matchingDistance=d.matchingDistance;m.in.ownerDistance=d.ownerDistance;m.in.matching.velocity[0]=30;m.in.matching.k=.5;m.in.matching.omega=2000;m.in.volumeSstClosure=true;
WallModelConfig<double> c;c.nodes=128;c.enableSst=true;WallWorkspace<double,2,128>s;WallOutput<double,2>o;assert(evaluateWallModel(m.in,c,s,o,st));GasBoundaryLayerSstClosure<double> f;f.kFluxCount=o.kFluxCount;f.kFluxHeight=o.kFluxHeight;f.kDiffusiveFlux=o.kDiffusiveFlux;
assert(o.kFluxCount==129);for(int j=0;j<o.kFluxCount;++j){assert(std::isfinite(o.kFluxHeight[j]));assert(std::isfinite(o.kDiffusiveFlux[j]));assert(std::isfinite(o.omegaDiffusiveFlux[j]));}std::cout<<std::setprecision(17)<<"L="<<d.matchingDistance<<" last="<<o.kFluxHeight[o.kFluxCount-1]<<" src="<<o.integratedKSource<<" divF="<<1e-6*(boundaryLayerKDiffusion(f,.001)-o.wallKFlux)<<" residual="<<o.residual<<" audit="<<o.ownerKBalanceResidual<<std::endl;
detail::LayerContext<double,2>ctx;detail::makeContext(m.in,c,ctx);detail::LayerPoint<double,2>edge;detail::evaluatePoint(m.in,c,ctx,s.state,s.y,127,edge);std::cout<<"missing last half source="<<1e-6*.5*(s.y[127]-s.y[126])*edge.sourceK<<std::endl;
}
