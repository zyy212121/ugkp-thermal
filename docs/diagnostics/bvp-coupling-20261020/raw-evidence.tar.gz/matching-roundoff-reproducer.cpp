
#include "common/gasWall/WallModel.H"
#include "common/gasTransport/GasWallMatching.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

int main(){

    Model m;struct S:GasStateView<double,double,SstCoefficientsT<double>>{GasSpeciesState<double,2> gasSpecies;};
    S s;s.nCells=2;s.gasSpecies.thermo=m.in.model.thermo;
    double species[4]={.5,1,.5,0},mx[2]={0,10},zero[2]{},e[2],t[2]={300,300},rk[2]={1,1},rw[2]={100,100};
    double cv=1000-universalGasConstant<double>()/.028;for(int i=0;i<2;++i)e[i]=cv*300+.5*mx[i]*mx[i];
    s.rhoUx=mx;s.rhoUy=zero;s.rhoUz=zero;s.rhoE=e;s.Tgas=t;s.rhoK=rk;s.rhoOmega=rw;s.gasSpecies.rho=species;
    int cells[2]={0,1};double weights[2]={-1,2};WallMatchingState<double,2> result;double p;
    assert(recoverWallMatching(s,cells,weights,2,true,result,p));
    assert(near(result.massFraction[0],1));assert(result.massFraction[1]>=0&&result.massFraction[1]<1e-14);assert(near(result.velocity[0],10));
    // Pure energy overshoot is scaled analytically, without evaluating failed EOS trials.
    species[0]=species[1]=1;species[2]=species[3]=0;mx[1]=1e4;e[1]=cv*300+.5*mx[1]*mx[1];
    assert(recoverWallMatching(s,cells,weights,2,true,result,p));assert(result.temperature>0);assert(result.velocity[0]<2e4);
    // A finite quadratic omega overshoot reaches a strict positive-domain
    // boundary. Do not publish a rounded zero/negative omega to the BVP.
    rw[0]=12345.6789;rw[1]=.123456*rw[0];
    assert(recoverWallMatching(s,cells,weights,2,true,result,p));assert(result.omega>0);

    
}
