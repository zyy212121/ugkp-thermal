source /mnt/d/tempt/ugkp-pr19-math-fixes-20261018/main-baseline-build/env.sh
cd /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-main-baseline-20261018
bash -x tool/gasUGKP/build_private_backend.sh
