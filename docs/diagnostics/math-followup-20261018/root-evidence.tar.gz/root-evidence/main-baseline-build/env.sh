#!/bin/bash
source /opt/openfoam10/etc/bashrc
set -eo pipefail
ROOT=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-main-baseline-20261018
export FOAM_USER_APPBIN="$ROOT/.review-install/bin"
export FOAM_USER_LIBBIN="$ROOT/.review-install/lib"
export CUDA_HOME=/usr/local/cuda-13.1
export NVCC="$CUDA_HOME/bin/nvcc"
export PATH="$FOAM_USER_APPBIN:$FOAM_APPBIN:$CUDA_HOME/bin:/usr/bin:/bin:$WM_PROJECT_DIR/wmake"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN/dummy:$CUDA_HOME/lib64"
export CUDA_CACHE_PATH="$ROOT/.review-cache/cuda"
export XDG_CACHE_HOME="$ROOT/.review-cache"
export TMPDIR="/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-main-baseline-20261018/.review-tmp"
export CHMT_CUDA_ARCH=sm_89 UGKWP_CUDA_ARCH=sm_89 UGKWP_GAS_SPECIES=2
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
cd "$ROOT"
export PYTHONPATH="$ROOT/validation/tests/gas_transport:$ROOT/validation/tests/gas_wall:$ROOT"
