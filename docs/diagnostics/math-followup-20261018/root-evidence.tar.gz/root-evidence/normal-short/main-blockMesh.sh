source /mnt/d/tempt/ugkp-pr19-math-fixes-20261018/main-baseline-build/env.sh
cd /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/.review-runs/math-normal-short/main
blockMesh
