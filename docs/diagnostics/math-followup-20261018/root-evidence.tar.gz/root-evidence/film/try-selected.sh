source /opt/openfoam10/etc/bashrc
set -eo pipefail
export FOAM_USER_APPBIN=/tmp/ugkp-film-consistency-kaws0x3g/bin FOAM_USER_LIBBIN=/tmp/ugkp-film-consistency-kaws0x3g/lib CUDA_CACHE_PATH=/tmp/ugkp-film-consistency-kaws0x3g/cache/cuda TMPDIR=/tmp/ugkp-film-consistency-kaws0x3g/tmp XDG_CACHE_HOME=/tmp/ugkp-film-consistency-kaws0x3g/cache
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN:$FOAM_LIBBIN/dummy"
/tmp/ugkp-film-consistency-kaws0x3g/probe -case /tmp/ugkp-film-consistency-kaws0x3g/case -step .001 -phaseCase selected
