source /mnt/d/tempt/ugkp-pr19-math-fixes-20261018/env-final.sh
bash -x applications/CHMT/Allwmake
