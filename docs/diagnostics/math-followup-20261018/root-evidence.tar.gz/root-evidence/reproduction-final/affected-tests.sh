source /opt/openfoam10/etc/bashrc
set -eo pipefail
export FOAM_USER_APPBIN="$REVIEW_OUTPUT/install/bin"
export FOAM_USER_LIBBIN="$REVIEW_OUTPUT/install/lib"
export CUDA_HOME=/usr/local/cuda-13.1
export NVCC="$CUDA_HOME/bin/nvcc"
export PATH="$FOAM_USER_APPBIN:$FOAM_APPBIN:$CUDA_HOME/bin:/usr/bin:/bin:$WM_PROJECT_DIR/wmake"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN/dummy:$CUDA_HOME/lib64"
export CUDA_CACHE_PATH="$REVIEW_OUTPUT/cache/cuda" XDG_CACHE_HOME="$REVIEW_OUTPUT/cache" TMPDIR="$REVIEW_OUTPUT/tmp"
export UGKWP_GAS_SPECIES=2 CHMT_CUDA_ARCH=sm_89 UGKWP_CUDA_ARCH=sm_89
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
export PYTHONPATH="$REVIEW_SOURCE/validation/tests/gas_transport:$REVIEW_SOURCE/validation/tests/gas_wall:$REVIEW_SOURCE"
cd "$REVIEW_SOURCE"

python3 -m pytest -q validation/tests/chemistry/test_stage_mathematical_controls.py validation/tests/gas_wall/test_wall_feasible_derivatives.py validation/tests/gas_wall/test_wall_jacobian_scale.py validation/tests/test_chmt_math_globalization.py validation/tests/test_chmt_ablation_diagnostics.py validation/tests/test_chmt_conduction_energy_goal.py validation/tests/test_host_audit_reduction.py validation/tests/test_chmt_film_single_pass.py validation/tests/test_chmt_phase_composition_diagnostic.py validation/tests/test_geometry_globalization.py validation/tests/test_geometry_single_pass_diagnostics.py validation/tests/test_chmt_film_geometry_coupling.py validation/tests/test_chmt_material_domain_diagnostics.py validation/tests/test_chmt_audit_overflow_followup.py validation/tests/test_chmt_surface_diagnostic_catalogue.py validation/tests/test_interface_composition.py validation/tests/test_composition_independent_review.py validation/tests/test_diagnostics_core.py validation/tests/test_surface_preflight_provenance.py --basetemp /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/.review-runs/final-reproduction/pytest-temp --junitxml /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/.review-runs/final-reproduction/results.xml
