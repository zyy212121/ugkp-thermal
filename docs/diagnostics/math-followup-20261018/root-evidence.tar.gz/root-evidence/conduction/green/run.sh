source /opt/openfoam10/etc/bashrc
set -eo pipefail
export FOAM_USER_APPBIN=/tmp/ugkp-conduction-goal-v7e_ggvz/bin FOAM_USER_LIBBIN=/tmp/ugkp-conduction-goal-v7e_ggvz/lib CUDA_CACHE_PATH=/tmp/ugkp-conduction-goal-v7e_ggvz/cuda-cache XDG_CACHE_HOME=/tmp/ugkp-conduction-goal-v7e_ggvz/cache TMPDIR=/tmp/ugkp-conduction-goal-v7e_ggvz/tmp
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
export PATH="$FOAM_USER_APPBIN:$FOAM_APPBIN:/usr/bin:/bin"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI"
g++ -std=c++17 -O1 -ffp-contract=off -DNoRepository -DWM_DP -DWM_LABEL_SIZE=32 -ffunction-sections -fdata-sections -I/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/applications/CHMT -I/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/common -I$WM_PROJECT_DIR/src/OpenFOAM/lnInclude -I$WM_PROJECT_DIR/src/finiteVolume/lnInclude -I$WM_PROJECT_DIR/src/meshTools/lnInclude -I$WM_PROJECT_DIR/src/OSspecific/POSIX/lnInclude /tmp/ugkp-conduction-goal-v7e_ggvz/probe.C /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/applications/CHMT/mesh/Geometry.C -Wl,--gc-sections -L$FOAM_LIBBIN -lfiniteVolume -lmeshTools -lOpenFOAM -L$FOAM_LIBBIN/$FOAM_MPI -lPstream -o /tmp/ugkp-conduction-goal-v7e_ggvz/probe
/tmp/ugkp-conduction-goal-v7e_ggvz/probe -case /tmp/ugkp-conduction-goal-v7e_ggvz/case
