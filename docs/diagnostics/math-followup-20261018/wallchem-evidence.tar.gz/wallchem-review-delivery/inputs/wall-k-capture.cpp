#include <cstdio>
int probe_case=-1,probe_iteration=-1,probe_block=-1;
bool probe_trace(){return probe_case==94||probe_case==162||probe_case==242||probe_case==352||probe_case==482||probe_case==488||probe_case==706||probe_case==726||probe_case==886;}
double probe_l[128][6][6]{},probe_d[128][6][6]{},probe_u[128][6][6]{},probe_fd[128][6]{};
inline int probe_line_calls=0,probe_line_reject=0,probe_line_invalid=0,probe_jac_calls=0,probe_jac_invalid=0,probe_jac_retry=0,probe_seed_failed=0,probe_seed_restored=0;

#include "inputs/sst_restart004_capture.H"
#include <iostream>
#include <iomanip>
int main(){CapturedSstWall m;ugkp::diagnostics::DeviceContext d{};m.input.diagnostics=&d;m.input.model.thermo.diagnostics=&d;ugkwp::gaswall::WallWorkspace<double,2,128>w;ugkwp::gaswall::WallOutput<double,2>o;ugkwp::gaswall::WallStatus s;bool ok=ugkwp::gaswall::evaluateReactingWallLayer(m.input,m.config,w,o,s);std::cout<<std::setprecision(17)<<ok<<" "<<d.fatalClaim<<" "<<d.firstFatal.sourceSiteId<<" "<<o.iterations<<" "<<o.residual<<" "<<o.conductiveHeatFlux<<"\n";}