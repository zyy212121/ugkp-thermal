int probe_iterations=0,probe_states=0,probe_evals=0,probe_jacs=0,probe_halvings=0;

#include "common/chemistry/GasRates.H"
#include "common/chemistry/GasJacobian.H"
#include "tool/chemistry/mechanisms/GeneratedH2O2.H"
#include <cassert>
#include <cmath>
#include <limits>
using namespace ugkwp;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[2]; GasStoichTerm<double> re[2],pr[2];
 GasColliderEfficiency<double> eff[1];
 SpeciesThermoView<double,2> t; GasMechanismView<double,2> m;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 for(int r=0;r<2;++r){rx[r].reactantOffset=r;rx[r].reactantCount=1;rx[r].productOffset=r;rx[r].productCount=1;rx[r].sourceIndex=r;rx[r].highRate.preExponential=2;re[r].species=0;re[r].coefficient=1;pr[r].species=1;pr[r].coefficient=1;}
 m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=2;m.products=pr;m.productTermCount=2;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-12+r*std::abs(b);}

#include "common/chemistry/LocalStiffIntegrator.H"
#include <iostream>
#include <iomanip>
#include <string>
template<int N> void run(std::string name,ClosedReactorInput<double,N>& b,SpeciesThermoView<double,N> t,GasMechanismView<double,N> m,double T,double h,int terminal=0){
 ChemistryControls<double> c;c.relativeTolerance=1e-7;c.absoluteMassFractionTolerance=1e-13;c.maximumNewtonIterations=16;c.maximumLineSearchIterations=24;
 gasChemistryDetail::ReactorContext<double,N> ctx(b,t,m,c);ctx.prepare();
 double z[N]={},rhs[N]={},f[N]={},mass[N]={},res[N]={};
 probe_iterations=probe_states=probe_evals=probe_jacs=probe_halvings=0;
 ChemistryStatus s;
#ifdef BASELINE
 if(terminal){ctx.refinement=false;bool scalar=false,evaluated=false;s=gasChemistryDetail::continueImplicitStage(ctx,rhs,h,1.,z,T,mass,f,scalar,false,&evaluated);}
 else
#endif
 s=gasChemistryDetail::implicitStage(ctx,rhs,h,1.,z,T);
 int iterations=probe_iterations,states=probe_states,evals=probe_evals,jacs=probe_jacs,halvings=probe_halvings;
 auto check=ctx.evaluate(z,f,T,nullptr,mass);double minmass=mass[0],masssum=0,maxres=0;
 for(int i=0;i<m.independentRank;++i){res[i]=z[i]-h*f[i];maxres=std::max(maxres,std::abs(res[i]));}
 for(double v:mass){minmass=std::min(minmass,v);masssum+=v;}
 if(!check)maxres=NAN;
 double norm=check?gasChemistryDetail::coordinateNorm(ctx,res,mass):NAN;
 bool valid=check&&minmass>=0&&std::isfinite(T)&&T>0;
 std::cout<<name<<','<<h<<','<<terminal<<','<<int(s.code)<<','<<int(check.code)<<','<<norm<<','<<maxres<<','<<valid<<','<<minmass<<','<<T<<','<<iterations<<','<<states<<','<<evals<<','<<jacs<<','<<halvings<<','<<masssum-b.totalMass<<','<<mixtureEnergy(mass,T,t)-b.internalEnergy<<'\n';
}
int main(){std::cout<<std::setprecision(17)<<"case,h,terminal,status,check_status,norm,max_coordinate_residual,valid,min_mass,T,iterations,states,evaluations,jacobians,halvings,mass_error,energy_error\n";
 for(double order:{1.,.5,2.})for(double h:{.0001,.01,.1,1.,10.,100.}){
 Model a;a.re[0].coefficient=a.pr[0].coefficient=order;a.rx[0].highRate.preExponential=1000.;ClosedReactorInput<double,2> b;b.speciesMass[0]=.028;b.totalMass=.028;b.volume=.001;b.internalEnergy=mixtureEnergy(b.speciesMass,700.,a.t);
 run("fixture_order_"+std::to_string(order),b,a.t,a.m,700.,h);
#ifdef BASELINE
 run("fixture_order_"+std::to_string(order),b,a.t,a.m,700.,h,1);
#endif
 }
 GeneratedH2O2<double> a;std::string name;double volume,T,h;while(std::cin>>name>>volume>>T>>h){ClosedReactorInput<double,10> b;b.volume=volume;for(double& v:b.speciesMass){std::cin>>v;b.totalMass+=v;}b.internalEnergy=mixtureEnergy(b.speciesMass,T,a.thermoView());run(name,b,a.thermoView(),a.mechanismView(),T,h);}
}
