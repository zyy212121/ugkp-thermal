
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

#include <cstdio>
int main(){Model m;m.in.integrateOwnerKSource=false;m.in.matchingDistance=0.0002502234625842738;m.in.ownerDistance=0.00010008938503370952;m.in.temperature=429.0911069139838;m.in.matching.temperature=700.4819572437555;m.in.matching.velocity[0]=3.6081810686220432;m.in.matching.k=0.0007464183767680095;m.in.matching.omega=22.13106654849767;m.in.massFlux[0]=.7*0.43002516802901253;m.in.massFlux[1]=.3*0.43002516802901253;
WallModelConfig<double>c;c.nodes=16;c.enableSst=true;WallWorkspace<double,2,16>w;detail::LayerContext<double,2>ctx;assert(detail::makeContext(m.in,c,ctx));const double data[16][7]={{0.0,1.806321703699435e-20,0.0,0.0,0.3,0.0,0.027265987439566576},{1.1121042781523278e-06,0.0009701580012755172,0.0,0.32333237899693673,0.3,1.456412029296103e-07,0.027290780548730787},{4.448417112609311e-06,0.004309012442654712,0.0,1.3314538257485276,0.3,0.03803651548205896,0.04652343878644342},{1.0008938503370953e-05,0.011360186666362612,0.0,3.2249727970231876,0.3,0.1040323020490823,0.04793725730973221},{1.7793668450437245e-05,0.022599312367760013,0.0,6.225968903841304,0.3,0.18300829280303932,0.04444768129468847},{2.7802606953808196e-05,0.03774138962235693,0.0,10.362417938196968,0.3,0.2636802412048115,0.03893700589935318},{4.003575401348381e-05,0.05627078167023859,0.0,15.40009082312551,0.3,0.33714103418627805,0.033359919626877836},{5.449310962946407e-05,0.07846179037550642,0.0,21.171883313049793,0.3,0.39869874300453195,0.028412778649171126},{7.117467380174898e-05,0.10625269286705187,0.0,27.85905669895391,0.3,0.44711319046844616,0.02409610821936999},{9.008044653033856e-05,0.14452600065377383,0.0,36.14567616523101,0.3,0.4826131180536706,0.020198564521772776},{0.00011121042781523278,0.20398268778881734,0.0,47.396480045400814,0.3,0.5050228202097654,0.016536011782698586},{0.00013456461765643166,0.3076411368716878,0.0,63.8411744690081,0.3,0.5131006437443678,0.013103736908333174},{0.00016014301605393524,0.5047034854865352,0.0,88.65957213379738,0.3,0.5052416343100639,0.010120476390518955},{0.00018794562300774342,0.9017494675963446,0.0,126.30083780475854,0.3,0.4774024822934763,0.007882652203889931},{0.00021797243851785628,1.741332604830509,0.0,183.5408820722439,0.3,0.4053528039903891,0.00685863657308626},{0.0002502234625842738,3.6081810686220432,0.0,271.39085032977164,0.3,0.027320658424862483,0.21256846085020858}};for(int i=0;i<16;++i){w.y[i]=data[i][0];for(int j=0;j<6;++j)w.state[i][j]=data[i][j+1];}double norm=0;assert(detail::allResidual(m.in,c,ctx,w.state,w.y,w.residual,norm));for(int i=0;i<16;++i)assert(detail::assembleJacobianNode(m.in,c,ctx,w,i));for(int i=0;i<16;++i)for(int row=0;row<6;++row)for(int j=0;j<16;++j)for(int col=0;col<6;++col){double value=i==j?w.diagonal[i][row][col]:(i==j+1?w.lower[i][row][col]:(i+1==j?w.upper[i][row][col]:0));printf("%d,%d,%.17g\n",i*6+row,j*6+col,value);}}
