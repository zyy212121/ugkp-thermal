#!/usr/bin/env python3
"""CPU-only real wall-operator replay. Writes only a new test output directory."""
import argparse,hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True,type=Path);p.add_argument('--revision',default='a8af17679aef3f52680e8921ee63d7ae66d3d335');p.add_argument('--output',required=True,type=Path);p.add_argument('--variant',choices=['formal','before_zero','natural_trace','rejected858','consistent_k','bounded_dogleg_k','causal726'],default='formal');p.add_argument('--capture',action='store_true');p.add_argument('--chemistry',action='store_true');p.add_argument('--matrix',choices=['94','352']);p.add_argument('--count',type=int,default=1000);a=p.parse_args();root=Path(__file__).resolve().parent;out=a.output.resolve();allowed=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test').resolve()
if not out.is_relative_to(allowed):raise SystemExit('Output must be inside the dedicated test directory.')
out.mkdir(parents=True,exist_ok=False);sha=subprocess.check_output(['git','rev-parse',a.revision],cwd=a.repo,text=True).strip();archive=subprocess.check_output(['git','archive',sha,'common','tool/chemistry/mechanisms/GeneratedH2O2.H'],cwd=a.repo)
with tarfile.open(fileobj=io.BytesIO(archive))as t:
 for member in t.getmembers():
  if member.issym()or member.islnk()or not (out/member.name).resolve().is_relative_to(out):raise SystemExit('Unsafe archive member')
 t.extractall(out)
if a.variant!='formal':shutil.copytree(root/'views'/a.variant,out,dirs_exist_ok=True)
if a.chemistry:source=root/'inputs/chemistry-probe.cpp'
elif a.capture:source=root/'inputs/wall-k-capture.cpp'
elif a.matrix:source=root/'inputs'/('wall-jacobian-'+a.matrix+'.cpp')
elif a.variant in['consistent_k','bounded_dogleg_k']:source=root/'inputs/wall-k-selected.cpp'
elif a.variant=='causal726':source=root/'inputs/wall726-probe.cpp'
elif a.variant in['natural_trace','rejected858']:source=root/'inputs/wall-trace-probe.cpp'
else:source=root/'inputs/wall-probe.cpp'
command=['g++','-std=c++17','-O2','-ffp-contract=off','-DDIAGNOSTICS=1','-I'+str(out),'-I'+str(root),str(source),'-o',str(out/'probe')];build=subprocess.run(command,capture_output=True,text=True);(out/'build.log').write_text(build.stdout+build.stderr)
record={'source_reference':sha,'variant':a.variant,'experimental_not_committed':a.variant not in['formal','before_zero'],'build':command,'build_exit':build.returncode,'selected_header_sha256':{str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest()for f in[out/'common/gasWall/ReactingWallLayer.H',out/'common/gasWall/WallModelTypes.H']}}
if build.returncode==0:
 run=[str(out/'probe')]+([]if a.capture or a.matrix or a.chemistry else[str(a.count)]);r=subprocess.run(run,input=(root/'inputs/chemistry-inputs.txt').read_text()if a.chemistry else None,capture_output=True,text=True);(out/'stdout.csv').write_text(r.stdout);(out/'stderr.log').write_text(r.stderr);record.update(stdin=('inputs/chemistry-inputs.txt'if a.chemistry else None),run=run,run_exit=r.returncode,artifact_sha256=hashlib.sha256((out/'probe').read_bytes()).hexdigest())

if a.chemistry:
 for name in ['common/chemistry/LocalStiffIntegrator.H','common/chemistry/ConservativeReactor.H','common/chemistry/NewtonFactor.H','common/chemistry/GasRates.H','common/chemistry/GasJacobian.H','common/gasTransport/MixtureThermo.H','tool/chemistry/mechanisms/GeneratedH2O2.H']:
  record['selected_header_sha256'][name]=hashlib.sha256((out/name).read_bytes()).hexdigest()
 record['stdin_sha256']=hashlib.sha256((root/'inputs/chemistry-inputs.txt').read_bytes()).hexdigest()

(out/'commands.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2));raise SystemExit(build.returncode if build.returncode else record['run_exit'])
