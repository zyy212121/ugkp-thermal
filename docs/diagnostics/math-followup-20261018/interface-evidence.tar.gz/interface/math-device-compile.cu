#include "ablation/InterfaceMath.H"
__global__ void actual(chmt::SurfacePhysicsInput* i,chmt::PhysicsConfig*p,chmt::SurfacePhysicsResult*r,bool*ok){if(threadIdx.x==0)ok[0]=chmt::solveSurfaceInterface(i[0],p[0],r[0]);}
