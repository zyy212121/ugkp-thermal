#include "DiagnosticsCatalogue.H"
#include <cassert>
int main(){auto c=ugkp::diagnostics::sourceCatalogue();for(unsigned id=3860;id<=3870;++id){unsigned count=0;for(const auto& p:c)if(p.siteId==id){++count;assert(p.file=="applications/CHMT/ablation/InterfaceMath.H"&&!p.function.empty()&&p.line>0);}assert(count==1);}}
