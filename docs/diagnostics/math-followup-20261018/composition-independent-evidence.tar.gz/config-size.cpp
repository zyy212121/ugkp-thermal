#include "ablation/InterfaceMath.H"
#include <iostream>
int main(){std::cout<<sizeof(chmt::PhysicsConfig)<<"\n";}
