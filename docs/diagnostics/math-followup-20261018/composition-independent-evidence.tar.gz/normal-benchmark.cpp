#include "ablation/InterfaceMath.H"
#include <chrono>
#include <random>
#include <iostream>
#include <iomanip>
#include <vector>
using namespace chmt;
struct Input{double b[Ns],y[Ns],R[Ns],D[Ns],Js[Ns];};
int main(int argc,char**argv){int mode=argc>1?atoi(argv[1]):0;const int count=20000;std::vector<Input> input(count);std::mt19937_64 gen(74921);std::uniform_real_distribution<double>u(0,1);for(auto& x:input){double sb=0,sy=0,R=0;for(int i=0;i<Ns;++i){x.b[i]=std::pow(10.,-5*u(gen));x.y[i]=std::pow(10.,-5*u(gen));sb+=x.b[i];sy+=x.y[i];x.R[i]=std::pow(10.,1+3*u(gen));x.D[i]=std::pow(10.,-6+5*u(gen));}for(int i=0;i<Ns;++i){x.b[i]/=sb;x.y[i]/=sy;}if(mode){sy=0;for(int i=0;i<Ns;++i){x.R[i]=250+150*u(gen);x.D[i]=1e-5+1e-4*u(gen);x.y[i]=x.b[i]*(1+(mode==1?1e-4:1e-6)*(u(gen)-.5));sy+=x.y[i];}for(int i=0;i<Ns;++i)x.y[i]/=sy;}for(int i=0;i<Ns;++i)R+=x.y[i]*x.R[i];double rho=101325/(R*300),J=mode?(mode==1?.01:1e-8):std::pow(10.,-5+5*u(gen)),S=0;for(int i=0;i<Ns;++i)S+=rho*x.D[i]/.01*(x.y[i]-x.b[i]);for(int i=0;i<Ns;++i)x.Js[i]=J*x.y[i]+rho*x.D[i]/.01*(x.y[i]-x.b[i])-x.y[i]*S;}
int good=0;double solver=0,maxError=0,maxResidual=0,checksum=0;for(const auto& x:input){PhysicsConfig p;for(int i=0;i<Ns;++i){p.species[i].R=x.R[i];p.gasDiffusivity[i]=x.D[i];}double out[Ns]{},f[Ns]{};auto begin=std::chrono::steady_clock::now();bool ok=interfaceComposition(x.Js,x.b,101325,300,.01,p,1e-12,out);solver+=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();bool valid=compositionResidual(out,x.b,x.Js,101325,300,.01,p,f,nullptr);double norm=0,sum=0,err=0;bool bounded=true;for(int i=0;i<Ns;++i){norm=std::max(norm,std::abs(f[i]));sum+=out[i];err=std::max(err,std::abs(out[i]-x.y[i]));bounded=bounded&&out[i]>=0&&out[i]<=1;checksum+=out[i]*(i+1);}good+=ok&&valid&&bounded&&norm<1e-8&&std::abs(sum-1)<1e-10;maxResidual=std::max(maxResidual,norm);maxError=std::max(maxError,err);}
std::cout<<std::setprecision(17)<<"mode="<<mode<<" ns="<<Ns<<" count="<<count<<" good="<<good<<" solver_seconds="<<solver<<" maxError="<<maxError<<" maxResidual="<<maxResidual<<" checksum="<<checksum<<'\n';return 0;}
