
#include <cstddef>
#include <cassert>
using std::size_t;
int copies=0;
struct Owner{int completeReadback(int status=0,bool completed=true){if(completed)++copies;return status;}};
struct DeviceState{int nBoundarySources=0,nFaces=0,nCells=0,hostTurbulenceModel=3,sstConfigured=1;
 int*sourceFace=nullptr; double *sourceResidualMass=nullptr,*gasBoundaryRho=nullptr,*gasBoundaryUx=nullptr,
 *gasBoundaryUy=nullptr,*gasBoundaryUz=nullptr,*gasBoundaryP=nullptr,*gasBoundaryT=nullptr,*k=nullptr,*omega=nullptr,*nut=nullptr;Owner*diagnosticOwner;};
DeviceState*asState(void*p){return static_cast<DeviceState*>(p);}int validateState(DeviceState*,const char*){return 0;}
void setLastErrorText(const char*){}
template<class T> int copyToHost(T*,const T*,size_t n,const char*){if(n)++copies;return 0;}
extern "C" int ugkwpGpuResidentStrictDownloadSourceResidualMass
(
    void* handle,
    int* nSources,
    int maxSources,
    int* sourceFace,
    double* residualMass
)
{

    DeviceState* s = asState(handle);
    if (validateState(s, "source residual download") != 0 || nSources == nullptr)
    {
        return 1;
    }
    *nSources = s->nBoundarySources;
    if (maxSources == 0)
    {
        return 0;
    }
    if
    (
        sourceFace == nullptr
     || residualMass == nullptr
    )
    {
        setLastErrorText("invalid source residual download buffers");
        return 1;
    }
    const size_t n = static_cast<size_t>(s->nBoundarySources);
    int rc = 0;
    rc |= copyToHost(sourceFace, s->sourceFace, n, "cudaMemcpy strict sourceFace restart");
    rc |= copyToHost(residualMass, s->sourceResidualMass, n, "cudaMemcpy strict source residual restart");
    return s->diagnosticOwner->completeReadback(rc == 0 ? 0 : 1);
}
int main(){Owner owner;DeviceState s;s.diagnosticOwner=&owner;int count=0,face=0;double x=0;assert(ugkwpGpuResidentStrictDownloadSourceResidualMass(&s,&count,1,&face,&x)==0);assert(copies==0);}