
#include <cstddef>
#include <cassert>
using std::size_t;
int copies=0;
struct Owner{int completeReadback(int status=0,bool completed=true){if(completed)++copies;return status;}};
struct DeviceState{int nBoundarySources=0,nFaces=0,nCells=0,hostTurbulenceModel=3,sstConfigured=1;
 int*sourceFace=nullptr; double *sourceResidualMass=nullptr,*gasBoundaryRho=nullptr,*gasBoundaryUx=nullptr,
 *gasBoundaryUy=nullptr,*gasBoundaryUz=nullptr,*gasBoundaryP=nullptr,*gasBoundaryT=nullptr,*k=nullptr,*omega=nullptr,*nut=nullptr;Owner*diagnosticOwner;};
DeviceState*asState(void*p){return static_cast<DeviceState*>(p);}int validateState(DeviceState*,const char*){return 0;}
void setLastErrorText(const char*){}
template<class T> int copyToHost(T*,const T*,size_t n,const char*){if(n)++copies;return 0;}
extern "C" int ugkwpGpuResidentStrictDownloadGasBoundaryFields
(
    void* handle,
    double* rho,
    double* Ux,
    double* Uy,
    double* Uz,
    double* p,
    double* Tgas
)
{

    DeviceState* s = asState(handle);
    if (validateState(s, "gas boundary field download") != 0)
    {
        return 1;
    }

    const size_t n = static_cast<size_t>(s->nFaces);
    int rc = 0;
    rc |= copyToHost(rho, s->gasBoundaryRho, n, "cudaMemcpy strict gas boundary rho");
    rc |= copyToHost(Ux, s->gasBoundaryUx, n, "cudaMemcpy strict gas boundary Ux");
    rc |= copyToHost(Uy, s->gasBoundaryUy, n, "cudaMemcpy strict gas boundary Uy");
    rc |= copyToHost(Uz, s->gasBoundaryUz, n, "cudaMemcpy strict gas boundary Uz");
    rc |= copyToHost(p, s->gasBoundaryP, n, "cudaMemcpy strict gas boundary p");
    rc |= copyToHost(Tgas, s->gasBoundaryT, n, "cudaMemcpy strict gas boundary T");
    return s->diagnosticOwner->completeReadback(rc == 0 ? 0 : 1);
}
int main(){Owner owner;DeviceState s;s.diagnosticOwner=&owner;int count=0,face=0;double x=0;assert(ugkwpGpuResidentStrictDownloadGasBoundaryFields(&s,&x,&x,&x,&x,&x,&x)==0);assert(copies==0);}