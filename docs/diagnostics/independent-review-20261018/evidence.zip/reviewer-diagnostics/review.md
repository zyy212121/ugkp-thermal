# Independent diagnostics/CHT review
Review base: 7c696b19b5510ef94cfbbf7eb837a00c29d74f0d
Original PR head: 42188aa3cc5d3a34e5cfde759d62c75ebc8ab022
Reviewer performed read-only source review, CPU fixture builds in this evidence directory, no Git mutation, production writes or GPU jobs.

## Finding P2: CHT empty download adds a completion boundary
applications/CHT/gpu/GpuResidentStrict.cu:3720,5646,6093 (DownloadSourceResidualMass, DownloadGasBoundaryFields, DownloadSst).
The calls use completeReadback(status) rather than completeReadback(status,n!=0). copyToHost is a no-op for zero elements, so there is no preceding blocking readback; completeReadback nevertheless performs cudaMemcpy D2H on diagnostics. This violates the requested existing-synchronization-boundary policy and differs from gasUGKP/FSH. Nonempty paths are correct. SourceResidualMass with nBoundarySources=0 and positive caller capacity is possible even in a nonempty mesh.
Reproduction: cht_empty_repro.py adapts the existing extracted-production-body regression to CHT; three saved probe.cpp/binaries fail copies==0 (SIGABRT, -6). See cht_empty_repro.log. The original regression excludes CHT. Fix: pass n!=0 in these three paths and extend parameterization/path selection to CHT. Parent notified; no repair made by this reviewer.

## Reviewed behavior
- First fatal is claimed atomically before the record is written. This is correct under the documented contract: other device threads inspect only the stop flag, and payload readers run after producer completion and blocking copy. There is no device payload reader requiring a release/acquire publication handshake. Warning sample has the same completion-boundary contract; saturating counts use atomic operations.
- Metadata setup kernel and graph replay use the default stream; setup occurs outside capture. New metadata does not clear first fatal or unread warning samples. Explicit-operation metadata overrides shared operation stamping, preserving first-event provenance.
- GpuOwner has per-instance storage and sticky fatal snapshots. Host first fatal survives later observations. Warning deltas are computed independently of the output switch; first representative sample is explicitly labelled historical. finish drains warnings while retaining fatal. Teardown drains diagnostics after existing frees complete users and before freeing diagnostic storage.
- IPC versions and fixed-width wire layouts changed together. Both clients read the 8-byte version prefix before the changed frame extent. All response routes collect and encode a snapshot, fatal replies suppress payload and terminate server dispatch, clients reject subsequent advance, and release returns pending diagnostics. Client fatal dispatch precedes physics-payload interpretation.
- OpenFOAM fatal handling uses FatalError; warning output is rank-local on non-master ranks rather than introducing a collective. No new MPI collectives were added. Parent owns real OpenFOAM/MPI validation; this reviewer did not rerun it.
- CHT shared gas gravity validates original nonfinite inputs and computed outputs before publication, including the gas-only/zero-particle route. It retains the disclosed finite density floor. No failure replay or alternate gravity algorithm remains.
- CHT solid/DO finite iteration-budget misses warn and retain computed values. Iteration logic is not gated by the warning switch. Extrapolation performs the same arithmetic with warnings off. I/O paths check close/flush and report FatalIOError.
- Offline Mie checks unusable inputs, coefficient sums and phase normalization rather than replacing failure with isotropic phase. Legitimate Planck underflow, zero size and no-scattering isotropic limits remain. No candidate retries were introduced.
- Managed mirrors add the new diagnostic headers and related common helper paths; this is ownership metadata, not executable fallback selection.

## Remaining mechanisms within this scope
Allowed: existing finite gravity density floor; CHT table endpoint clamp when explicitly configured; finite solid extrapolation; nonlinear solid/Aitken, interface, DO linear/source and phase-balance mathematical iterations; tiny negative radiation-intensity roundoff clamp; Mie zero-size/no-scattering and Planck underflow limits.
Necessary execution checks: CUDA status, allocation, IPC framing, missing buffers and file/stream write failure.
No unreported failure-driven time-step replay, candidate acceptance/rejection or selectable backup found in this scoped diff.
Particle algorithms are excluded; lifecycle/readback integration and shared gas gravity were still reviewed.

## Validation
python3 -m pytest -q validation/tests/test_diagnostic_ipc_transport.py validation/tests/test_gpu_diagnostic_owner.py validation/tests/test_mie_generator_physics.py validation/tests/diagnostics/test_cht_remaining_paths.py --basetemp=../pr19-evidence-20261017/reviewer-diagnostics/pytest-temp -o cache_dir=../pr19-evidence-20261017/reviewer-diagnostics/pytest-cache
17 passed in 7.15 s; scoped-tests.log. CPU fakes/extracted bodies are explicitly not GPU numerical evidence.
CHT empty-readback regression: 3 expected failures against original PR, saved probes and log. No GPU jobs launched by reviewer.

## Files and boundaries
Full scoped diffs reviewed: common/Diagnostics.H, DiagnosticsCatalogue.H, DiagnosticsCodec.H, DiagnosticsFoam.H, DiagnosticsHost.H, GpuDiagnosticsOwner.cuh, GpuGravityUpdate.cuh, operators/applyGasGravityKernel.cuh; gasUGKP and FSH gpu/GpuBackendApi.H, GpuBackendClient.C, GpuBackendProtocol.H, GpuResidentStrict.H and private_backend/GpuBackendServer.C, GpuResidentStrict.cu; CHT gpu/GpuBackendApi.H, GpuResidentStrict.H, GpuResidentStrict.cu, diluteUgkwpFoam.C; CHT thermal/GpuSolidThermalCoupler.C, GpuSolidThermalProperties.C, MieDoRadiationSolver.C, ThermalHostDiagnostics.H; tool/radiation/mieTables/make_alumina_mie_table.py and tool/managed_mirrors.json.
Also traced common/GpuGasAdvance.cuh capture/replay ordering and inspected relevant diagnostics tests and exception report.
Other reviewers own CHMT and common gas/chemistry/wall producer correctness, including site 30420 producer-to-dispatch test coverage. Catalogue entries were read; registration count is not dynamic coverage.
Verdict: fix the one P2 synchronization-policy gap before acceptance of this scope. No additional confirmed scoped defect. Overall merge recommendation remains with coordinator after all reviews, final-tree tests and real GPU requirements.

## Follow-up: repair review and independent SDIRK oracle
Reviewed fixes worktree diff: the three CHT completeReadback calls now pass n!=0; no unrelated CHT code changed. Regression extends all three methods to CHT using gpu path, with no altered assertion. Parent green evidence cht-readback-green.log: 9 passed. Original P2 is closed.

Created only the separately authorized validation/tests/chemistry/test_review_sdirk_accuracy.py in fixes worktree. It independently derives the two-stage SDIRK2 stability function for y'=-2y and tests fixed uniform external partitions over total time .25. No failure-driven step controller is used. At one step, mass 0.016891377442955758 matches method oracle, but exp(-.5)*.028=0.016982858471953736; error 9.1481028997978525e-5 exceeds the old adaptive 2e-5 test tolerance. This is disclosed numerical behavior, not a claim of identical normal-operation precision. Errors for 2,4,8,16,32 predetermined steps are 2.2051538769593537e-5,5.4327127815001486e-6,1.3493919377438601e-6,3.3632316630630155e-7,8.395717674899994e-8. Tests demand method value within 2e-15, second-order global convergence, conservation, constant temperature, and one attempt per call. Both tests pass; sdirk-oracle.log. Existing historical assertions were not weakened.
