
#include <cstddef>
#include <cassert>
using std::size_t;
int copies=0;
struct Owner{int completeReadback(int status=0,bool completed=true){if(completed)++copies;return status;}};
struct DeviceState{int nBoundarySources=0,nFaces=0,nCells=0,hostTurbulenceModel=3,sstConfigured=1;
 int*sourceFace=nullptr; double *sourceResidualMass=nullptr,*gasBoundaryRho=nullptr,*gasBoundaryUx=nullptr,
 *gasBoundaryUy=nullptr,*gasBoundaryUz=nullptr,*gasBoundaryP=nullptr,*gasBoundaryT=nullptr,*k=nullptr,*omega=nullptr,*nut=nullptr;Owner*diagnosticOwner;};
DeviceState*asState(void*p){return static_cast<DeviceState*>(p);}int validateState(DeviceState*,const char*){return 0;}
void setLastErrorText(const char*){}
template<class T> int copyToHost(T*,const T*,size_t n,const char*){if(n)++copies;return 0;}
extern "C" int ugkwpGpuResidentStrictDownloadSst
(
    void* handle,
    double* k,
    double* omega,
    double* nut
)
{

    DeviceState* s = asState(handle);
    if (validateState(s, "SST field download") != 0)
    {
        return 1;
    }
    if
    (
        k == nullptr
     || omega == nullptr
     || nut == nullptr
    )
    {
        setLastErrorText("SST download requires configured SST and outputs");
        return 1;
    }
    const size_t n = static_cast<size_t>(s->nCells);
    int rc = 0;
    rc |= copyToHost(k, s->k, n, "cudaMemcpy SST k result");
    rc |= copyToHost(omega, s->omega, n, "cudaMemcpy SST omega result");
    rc |= copyToHost(nut, s->nut, n, "cudaMemcpy SST nut result");
    return s->diagnosticOwner->completeReadback(rc == 0 ? 0 : 1);
}
int main(){Owner owner;DeviceState s;s.diagnosticOwner=&owner;int count=0,face=0;double x=0;assert(ugkwpGpuResidentStrictDownloadSst(&s,&x,&x,&x)==0);assert(copies==0);}