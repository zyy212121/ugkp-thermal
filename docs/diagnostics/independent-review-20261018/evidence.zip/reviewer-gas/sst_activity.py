import sys, pathlib, subprocess
root=pathlib.Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-review-20261017');out=root.parent/'pr19-evidence-20261017/reviewer-gas';sys.path[:0]=[str(root),str(root/'validation/tests/gas_transport')]
from test_mixture_transport import fixture
pre=(root/'validation/tests/gas_transport/gas_state_probe.cpp').read_text().split('void hashBytes')[0]
body=r'''
int main(){State s;initialise(s);ugkp::diagnostics::DeviceContext d{};s.diagnostics=&d;s.sstConfigured=1;s.sstWallTreatment=3;s.cellPlaneCount[0]=0;s.sstCoefficients=ugkwp::defaultSstCoefficients();s.k[0]=s.rhoK[0]=1;s.omega[0]=s.rhoOmega[0]=std::numeric_limits<Real>::denorm_min()*Real(100);s.sstOmegaMin=s.omega[0];s.sstKMin=1e-10;s.gradUxY[0]=1;s.nut[0]=.1;s.gradKX[0]=1e-10;s.gradOmegaX[0]=1e-10;Real sk,so;sstSourcesForCell(s,0,Real(0),sk,so);printf("sizeof=%zu sourceK=%g sourceOmega=%g rhoOmega=%g physicalNext=%g\n",sizeof(Real),double(sk),double(so),double(s.rhoOmega[0]),double(s.rhoOmega[0]+so));threadIdx.x=0;applySstFluxAndSourceKernel(&s,1.);printf("fatal=%u site=%u activity=%g finalOmega=%g\n",d.fatalClaim,d.firstFatal.sourceSiteId,double(s.sstSourceNumber[0]),double(s.rhoOmega[0]));}
'''
(out/'sst_activity.cpp').write_text(pre+fixture()+body)
cmd=['g++','-std=c++17','-O0','-I'+str(root/'common'),'-I'+str(root/'common/gasNumerics'),'-I'+str(root/'validation/tests/gas_transport'),str(out/'sst_activity.cpp'),'-o',str(out/'sst_activity')]
subprocess.run(cmd,check=True);subprocess.run([str(out/'sst_activity')],check=True)

