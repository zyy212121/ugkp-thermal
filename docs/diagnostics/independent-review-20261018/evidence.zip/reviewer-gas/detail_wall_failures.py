from pathlib import Path
import subprocess,shutil
base=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');out=base/'pr19-evidence-20261017/reviewer-gas/wall-failure-details';repo=base/'pr19-fixes-20261017';trace=out/'trace';shutil.copytree(repo/'common',trace/'common',dirs_exist_ok=True)
p=trace/'common/gasWall/ReactingWallLayer.H';s=p.read_text();s='#include <cstdio>\n'+s;s=s.replace('if(!eliminateBlock(w.diagonal[i],w.upper[i],w.delta[i]))return false;','if(!eliminateBlock(w.diagonal[i],w.upper[i],w.delta[i])){fprintf(stderr,"ELIMINATE failed node=%d\\n",i);return false;}');s=s.replace('return false;', 'return false;')
p.write_text(s)
for name in ['selected_invalid','positivity']:
 src=out/(name+'_main.cpp');s=src.read_text();s='\n'.join(line for line in s.splitlines() if 's.diagnostics=new' not in line);src.write_text(s);r=base/'pr19-main-20261017';exe=src.with_suffix('');cmd=['g++','-std=c++17','-O1','-I'+str(r),'-I'+str(r/'common'),'-I'+str(r/'common/gasNumerics'),'-I'+str(r/'validation/tests/gas_transport'),str(src),'-o',str(exe)];subprocess.run(cmd,check=True);run=subprocess.run([str(exe)],capture_output=True,text=True);print(name,'main',run.returncode,run.stderr)
for name in ['coupled','residual1']:
 src=out/(name+'_fixed.cpp');s=src.read_text().replace('std::signal(SIGABRT,reviewAbort);','std::signal(SIGABRT,reviewAbort);std::cout<<std::unitbuf;');src.write_text(s);exe=out/(name+'_trace');cmd=['g++','-std=c++17','-O1','-I'+str(trace),'-I'+str(trace/'common'),str(src),'-o',str(exe)];subprocess.run(cmd,check=True);run=subprocess.run([str(exe)],capture_output=True,text=True);print(name,run.returncode,run.stdout,run.stderr);(out/(name+'_trace.log')).write_text(run.stdout+run.stderr)
