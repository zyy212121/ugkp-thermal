// Runs unchanged production device functions serially on a host. Not CUDA execution.
#include <cmath>
using std::isfinite;
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include "GpuPrecisionTypes.H"
#include "CharacteristicMuscl.cuh"
#include "OpenFoamLimitedLinear.cuh"
#include "OpenFoamViscousFlux.cuh"
#include "OpenFoamWallFunctions.cuh"
#include "RiemannBoundaryState.cuh"
#include "RiemannGasFlux.cuh"
#include "GpuSstAlgebra.cuh"
#include "GpuLesAlgebra.cuh"
using Real=GpuReal;
using Time=double;
#define GPU_OPERATOR_REAL Real
#define GPU_OPERATOR_TIME Time
#define GPU_OPERATOR_R GPU_R
#define GPU_OPERATOR_TINY(x) GPU_R(1e-30)
#define __host__
#define __global__
#define __device__
#define __forceinline__ inline
// PTX traps are represented by process failure in this serial host emulator.
#define asm(...) std::abort()
struct ThreadIndex { int x=0; } blockIdx, threadIdx, blockDim;
constexpr Real OfSmall=GPU_R(2.22044604925031308085e-16);
constexpr Real OfVSmall=GPU_R(1e-30);
constexpr Real OfGreat=GPU_R(1.0)/OfSmall;
struct GasPrimDevice { Real rho,ux,uy,uz,p,T; };
#include "legacy_gas_fixture.hpp"
#ifdef LEGACY_REFERENCE
using DeviceState=LegacyGasFixture;
#else
// No application DeviceState definition: the actual operators must be generic.
#include "gasTransport/GasStateView.H"
#endif
#include "operators/clampMin.cuh"
#include "operators/clampRange.cuh"
#include "operators/linearScheduledValueDevice.cuh"
#include "operators/makeGasPrimDevice.cuh"
#include "operators/riemannFacePrimitiveForGradient.cuh"
#include "operators/computeGasPrimitiveGradientsKernel.cuh"
#include "operators/computeSstGradientsKernel.cuh"
#include "operators/sstVelocityInvariants.cuh"
#include "operators/computeGasHllcAdcSensorKernel.cuh"
#include "operators/updateBarthLimiter.cuh"
#include "operators/computeGasGradientLimiterKernel.cuh"
#include "operators/computeGasEddyViscosityKernel.cuh"
#include "operators/updateWaveTransmissivePressureBoundaryKernel.cuh"
#include "operators/updateLegacyGasBoundaryMirrorKernel.cuh"
#include "operators/gasFaceSubgridTransportProperties.cuh"
#include "operators/computeRiemannGasFaceFluxDevice.cuh"
#include "operators/computeGasInternalFaceFluxKernel.cuh"
#include "operators/computeGasFluxPositivityScaleKernel.cuh"
#include "operators/computeSstFaceFluxKernel.cuh"

#ifdef LEGACY_OPTIONAL_SPECIES
struct TestLegacyGasFixture:LegacyGasFixture{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
#else
using TestLegacyGasFixture=LegacyGasFixture;
#endif

struct State:ugkwp::GasStateView<Real,Time,ugkwp::SstCoefficients>{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
void ck(bool a,const char*m){if(!a){std::fprintf(stderr,"%s\n",m);std::abort();}}
void near(Real a,Real b,const char*m){if(std::abs(a-b)>Real(128)*std::numeric_limits<Real>::epsilon()*std::max(Real(1),std::abs(b))){std::fprintf(stderr,"%s: %.17g != %.17g\n",m,double(a),double(b));std::abort();}}
void initialise(State&s){
s.diagnostics=new ugkp::diagnostics::DeviceContext[8]{};
s.Cx=new Real[8]{};
s.Cy=new Real[8]{};
s.Cz=new Real[8]{};
s.Sfx=new Real[8]{};
s.Sfy=new Real[8]{};
s.Sfz=new Real[8]{};
s.Tgas=new Real[8]{};
s.Ux=new Real[8]{};
s.Uy=new Real[8]{};
s.Uz=new Real[8]{};
s.V=new Real[8]{};
s.cellFaceId=new int[8]{};
s.cellLength=new Real[8]{};
s.cellPlaneCount=new int[8]{};
s.cellPlaneStart=new int[8]{};
s.deltaCoeffs=new Real[8]{};
s.faceCx=new Real[8]{};
s.faceCy=new Real[8]{};
s.faceCz=new Real[8]{};
s.faceNeighbour=new int[8]{};
s.faceOwner=new int[8]{};
s.facePeriodicDx=new Real[8]{};
s.facePeriodicDy=new Real[8]{};
s.facePeriodicDz=new Real[8]{};
s.facePeriodicPair=new int[8]{};
s.faceWeight=new Real[8]{};
s.gasBoundaryKind=new int[8]{};
s.gasBoundaryP=new Real[8]{};
s.gasBoundaryPFix=new int[8]{};
s.gasBoundaryPWave=new int[8]{};
s.gasBoundaryPWaveFieldInf=new Real[8]{};
s.gasBoundaryPWaveGamma=new Real[8]{};
s.gasBoundaryPWaveLInf=new Real[8]{};
s.gasBoundaryRho=new Real[8]{};
s.gasBoundaryRhoFix=new int[8]{};
s.gasBoundaryT=new Real[8]{};
s.gasBoundaryTFix=new int[8]{};
s.gasBoundaryUFix=new int[8]{};
s.gasBoundaryUx=new Real[8]{};
s.gasBoundaryUy=new Real[8]{};
s.gasBoundaryUz=new Real[8]{};
s.gasDiffusionNumber=new Real[8]{};
s.gasFluxPositivityScale=new Real[8]{};
s.gasGradientLimiterP=new Real[8]{};
s.gasGradientLimiterRho=new Real[8]{};
s.gasGradientLimiterT=new Real[8]{};
s.gasGradientLimiterUx=new Real[8]{};
s.gasGradientLimiterUy=new Real[8]{};
s.gasGradientLimiterUz=new Real[8]{};
s.gasHllcAdcSensor=new Real[8]{};
s.gasPhiRho=new Real[8]{};
s.gasPhiRhoE=new Real[8]{};
s.gasPhiRhoUx=new Real[8]{};
s.gasPhiRhoUy=new Real[8]{};
s.gasPhiRhoUz=new Real[8]{};
s.gradKX=new Real[8]{};
s.gradKY=new Real[8]{};
s.gradKZ=new Real[8]{};
s.gradOmegaX=new Real[8]{};
s.gradOmegaY=new Real[8]{};
s.gradOmegaZ=new Real[8]{};
s.gradPx=new Real[8]{};
s.gradPy=new Real[8]{};
s.gradPz=new Real[8]{};
s.gradRhoX=new Real[8]{};
s.gradRhoY=new Real[8]{};
s.gradRhoZ=new Real[8]{};
s.gradTX=new Real[8]{};
s.gradTY=new Real[8]{};
s.gradTZ=new Real[8]{};
s.gradUxX=new Real[8]{};
s.gradUxY=new Real[8]{};
s.gradUxZ=new Real[8]{};
s.gradUyX=new Real[8]{};
s.gradUyY=new Real[8]{};
s.gradUyZ=new Real[8]{};
s.gradUzX=new Real[8]{};
s.gradUzY=new Real[8]{};
s.gradUzZ=new Real[8]{};
s.k=new Real[8]{};
s.magSf=new Real[8]{};
s.nut=new Real[8]{};
s.omega=new Real[8]{};
s.p=new Real[8]{};
s.pressureScheduleTimes=new Time[8]{};
s.pressureScheduleValues=new Real[8]{};
s.rho=new Real[8]{};
s.rhoE=new Real[8]{};
s.rhoENext=new Real[8]{};
s.rhoK=new Real[8]{};
s.rhoKInitial=new Real[8]{};
s.rhoNext=new Real[8]{};
s.rhoOmega=new Real[8]{};
s.rhoOmegaInitial=new Real[8]{};
s.rhoUx=new Real[8]{};
s.rhoUxNext=new Real[8]{};
s.rhoUy=new Real[8]{};
s.rhoUyNext=new Real[8]{};
s.rhoUz=new Real[8]{};
s.rhoUzNext=new Real[8]{};
s.riemannBoundaryKind=new int[8]{};
s.riemannBoundaryP=new Real[8]{};
s.riemannBoundaryPFix=new int[8]{};
s.riemannBoundaryPWave=new int[8]{};
s.riemannBoundaryRho=new Real[8]{};
s.riemannBoundaryRhoFix=new int[8]{};
s.riemannBoundaryT=new Real[8]{};
s.riemannBoundaryTFix=new int[8]{};
s.riemannBoundaryUFix=new int[8]{};
s.riemannBoundaryUx=new Real[8]{};
s.riemannBoundaryUy=new Real[8]{};
s.riemannBoundaryUz=new Real[8]{};
s.scheduledInletFaceMask=new int[8]{};
s.sstBoundaryK=new Real[8]{};
s.sstBoundaryKMode=new int[8]{};
s.sstBoundaryOmega=new Real[8]{};
s.sstBoundaryOmegaMode=new int[8]{};
s.sstF1=new Real[8]{};
s.sstF2=new Real[8]{};
s.sstPhiRhoK=new Real[8]{};
s.sstPhiRhoOmega=new Real[8]{};
s.sstSourceNumber=new Real[8]{};
s.sstWallDistance=new Real[8]{};
s.nCells=2;s.nFaces=3;s.nInternalFaces=1;s.gasFluxScheme=1;s.gasReconstruction=0;s.gasLimiter=0;s.gammaGas=1.4;s.Rgas=287;s.gasCp=1004.5;s.gasMu=0;s.gasPrClamped=.7;s.rhoMin=1e-12;s.TgasMin=1e-9;s.maxDiffusionNumber=.25;
s.gasSpecies.cellStatus=new int[2]{};s.gasSpecies.faceStatus=new int[3]{};
s.sstCoefficients=ugkwp::defaultSstCoefficients();s.sstKMin=1e-12;s.sstOmegaMin=1e-9;s.sstMaxSourceNumber=.25;s.turbulentPrandtl=.9;
for(int c=0;c<2;++c){s.V[c]=1;s.Cx[c]=c;s.cellLength[c]=1;s.rho[c]=2;s.p[c]=100000;s.Tgas[c]=s.p[c]/(s.rho[c]*s.Rgas);s.rhoE[c]=s.p[c]/(s.gammaGas-1);s.cellPlaneStart[c]=2*c;s.cellPlaneCount[c]=2;s.k[c]=3;s.omega[c]=4;s.rhoK[c]=6;s.rhoOmega[c]=8;s.sstWallDistance[c]=.5;}
s.cellFaceId[0]=0;s.cellFaceId[1]=1;s.cellFaceId[2]=0;s.cellFaceId[3]=2;
for(int f=0;f<3;++f){s.faceOwner[f]=f==2?1:0;s.faceNeighbour[f]=f==0?1:-1;s.facePeriodicPair[f]=-1;s.magSf[f]=1;s.Sfx[f]=f==1?-1:1;s.faceCx[f]=f==0?.5:f==1?-.5:1.5;s.faceWeight[f]=.5;s.deltaCoeffs[f]=f==0?1:2;s.gasBoundaryKind[f]=s.riemannBoundaryKind[f]=f==0?0:1;s.gasHllcAdcSensor[f]=1;}
blockDim.x=1;blockIdx.x=threadIdx.x=0;
}
void moving(State&s,Real*oldV,Real*newV,Real*sweeps,Real dt){s.gasGeometry.enabled=true;s.gasGeometry.oldVolume=oldV;s.gasGeometry.newVolume=newV;s.gasGeometry.faceSweptVolume=sweeps;s.gasGeometry.interval=dt;s.gasGeometry.absoluteGeometryTolerance=Real(16)*std::numeric_limits<Real>::epsilon();s.gasGeometry.relativeGeometryTolerance=Real(16)*std::numeric_limits<Real>::epsilon();}
void flux(State&s,double dt){for(int c=0;c<2;++c){threadIdx.x=c;computeGasPrimitiveGradientsKernel(&s);computeGasGradientLimiterKernel(&s);computeGasEddyViscosityKernel(&s);}for(int f=0;f<3;++f){threadIdx.x=f;computeGasInternalFaceFluxKernel<false>(&s,dt);}for(int c=0;c<2;++c){threadIdx.x=c;computeGasFluxPositivityScaleKernel(&s,dt);}for(int f=0;f<3;++f){threadIdx.x=f;applyGasFluxPositivityScaleKernel(&s);}}

// Test-owned observations only. No audit storage or hook is attached to State.
struct SstObservation{bool enabled=true;Real transportK[2]{},transportOmega[2]{},sourceK[2]{},sourceOmega[2]{},constraintK[2]{},constraintOmega[2]{},initialTransportK[2]{},initialTransportOmega[2]{},initialSourceK[2]{},initialSourceOmega[2]{},initialConstraintK[2]{},initialConstraintOmega[2]{},volume[2]{};} observed;
void audit(State&s){observed={};for(int c=0;c<2;++c)observed.volume[c]=s.gasGeometry.enabled?s.gasGeometry.oldVolume[c]:s.V[c];}
void samePhysical(Real got,Real expected,const char*why){if(std::isnan(expected))ck(std::isnan(got),why);else if(std::isinf(expected))ck(got==expected,why);else{ck(std::isfinite(got),why);near(got,expected,why);}}
void observedApply(State*sp,double dt,bool strict=false){auto&s=*sp;const int c=blockIdx.x*blockDim.x+threadIdx.x;if(c>=s.nCells)return;if(strict){applySstFluxAndSourceKernel(sp,dt,true);return;}
 const Real k=s.rhoK[c],o=s.rhoOmega[c];const bool moving=s.gasGeometry.enabled;
 const Real oldV=moving?s.gasGeometry.oldVolume[c]:s.V[c],newV=moving?s.gasGeometry.newVolume[c]:s.V[c];
 Real fk=0,fo=0,div=0;bool constrained=ugkwp::gasBoundaryLayerOwnerSlot(s,c)>=0;
 for(int i=0;i<s.cellPlaneCount[c];++i){int f=s.cellFaceId[s.cellPlaneStart[c]+i];if(f<0||f>=s.nFaces)continue;Real sign=s.faceOwner[f]==c?-1:1;fk+=sign*s.sstPhiRhoK[f];fo+=sign*s.sstPhiRhoOmega[f];Real vf=s.gasPhiRho[f]/sstFaceDensity(s,f);if(moving)vf+=s.gasGeometry.faceSweptVolume[f]/dt;div-=sign*vf;
 constrained=constrained||((s.sstWallTreatment==0||s.sstWallTreatment==1||s.sstWallTreatment==2)&&f>=s.nInternalFaces&&s.riemannBoundaryKind[f]==2);}
 Real sk,so;sstSourcesForCell(s,c,div/clampMin(oldV,OfSmall),sk,so);
 const Real floorK=clampMin(s.rho[c],s.rhoMin)*s.sstKMin,floorO=clampMin(s.rho[c],s.rhoMin)*s.sstOmegaMin;
 const Real ek=moving?clampMin((k*oldV+dt*(fk+oldV*sk))/newV,floorK*oldV/newV):clampMin(finiteOr(k+dt*(fk/clampMin(s.V[c],OfSmall)+sk),floorK),floorK);
 const Real eo=moving?clampMin((o*oldV+(constrained?0:dt*(fo+oldV*so)))/newV,floorO*oldV/newV):(constrained?o:clampMin(finiteOr(o+dt*(fo/clampMin(s.V[c],OfSmall)+so),floorO),floorO));
 applySstFluxAndSourceKernel(sp,dt,false);
 samePhysical(s.rhoK[c],ek,"physical SST k differs from independent face/source prediction");samePhysical(s.rhoOmega[c],eo,"physical SST omega differs from independent face/source prediction");
 if(observed.enabled){observed.transportK[c]+=dt*fk;observed.transportOmega[c]+=dt*fo;observed.sourceK[c]+=dt*oldV*sk;observed.sourceOmega[c]+=dt*oldV*so;observed.constraintK[c]+=ek*newV-k*oldV-dt*fk-dt*oldV*sk;observed.constraintOmega[c]+=eo*newV-o*oldV-dt*fo-dt*oldV*so;observed.volume[c]=newV;}}
void observedRecover(State*sp){auto&s=*sp;int c=blockIdx.x*blockDim.x+threadIdx.x;Real k=s.rhoK[c],o=s.rhoOmega[c];recoverSstPrimitivesKernel(sp);if(s.sstConfigured){const Real floor=clampMin(s.rho[c],s.rhoMin)*s.sstKMin;samePhysical(s.rhoK[c],clampMin(finiteOr(k,floor),floor),"SST recovery changed physical k beyond its floor");}if(observed.enabled){observed.constraintK[c]+=(s.rhoK[c]-k)*observed.volume[c];observed.constraintOmega[c]+=(s.rhoOmega[c]-o)*observed.volume[c];}}
void observedWall(State*sp,bool only=false,bool strict=false){auto&s=*sp;int c=blockIdx.x*blockDim.x+threadIdx.x;Real k=s.rhoK[c],o=s.rhoOmega[c];applySstWallFunctionStateKernel(sp,only,strict);if(observed.enabled){observed.constraintK[c]+=(s.rhoK[c]-k)*observed.volume[c];observed.constraintOmega[c]+=(s.rhoOmega[c]-o)*observed.volume[c];}}
void observedSave(State*sp){saveGasConservativeStateKernel(sp);int c=blockIdx.x*blockDim.x+threadIdx.x;
observed.initialTransportK[c]=observed.transportK[c];
observed.initialTransportOmega[c]=observed.transportOmega[c];
observed.initialSourceK[c]=observed.sourceK[c];
observed.initialSourceOmega[c]=observed.sourceOmega[c];
observed.initialConstraintK[c]=observed.constraintK[c];
observed.initialConstraintOmega[c]=observed.constraintOmega[c];
}
void observedBlend(State*sp,Real a,Real b){blendGasConservativeStateKernel(sp,a,b);int c=blockIdx.x*blockDim.x+threadIdx.x;
 observed.transportK[c]=a*observed.initialTransportK[c]+b*observed.transportK[c];
observed.transportOmega[c]=a*observed.initialTransportOmega[c]+b*observed.transportOmega[c];
observed.sourceK[c]=a*observed.initialSourceK[c]+b*observed.sourceK[c];
observed.sourceOmega[c]=a*observed.initialSourceOmega[c]+b*observed.sourceOmega[c];
observed.constraintK[c]=a*observed.initialConstraintK[c]+b*observed.constraintK[c];
observed.constraintOmega[c]=a*observed.initialConstraintOmega[c]+b*observed.constraintOmega[c];
}
void checkBudget(State&s,Real k0,Real o0,int c){near(s.rhoK[c]*observed.volume[c],k0+observed.transportK[c]+observed.sourceK[c]+observed.constraintK[c],"test-side k inventory balance");near(s.rhoOmega[c]*observed.volume[c],o0+observed.transportOmega[c]+observed.sourceOmega[c]+observed.constraintOmega[c],"test-side omega inventory balance");}
#define applySstFluxAndSourceKernel observedApply
#define recoverSstPrimitivesKernel observedRecover
#define applySstWallFunctionStateKernel observedWall
#define saveGasConservativeStateKernel observedSave
#define blendGasConservativeStateKernel observedBlend
void stage(State&s,double dt){for(int c=0;c<2;++c){threadIdx.x=c;applySstFluxAndSourceKernel(&s,dt);recoverSstPrimitivesKernel(&s);}}

#include "gasWall/WallModel.H"
#include "gasTransport/GasBoundaryLayerEvaluation.H"
struct ActualWall {
 ugkwp::SpeciesThermoData<Real> sp[2];Real coefficients[6]={1004,0,10000,1100,0,20000};
 ugkwp::gaswall::WallInput<Real,2> input;ugkwp::gaswall::WallModelConfig<Real> config;
 ugkwp::gaswall::WallWorkspace<Real,2,24> workspace;ugkwp::gaswall::WallOutput<Real,2> output;
 ActualWall(State&s){
  for(int j=0;j<2;++j){sp[j].coefficientOffset=3*j;sp[j].molarMass=.028;sp[j].minTemperature=100;sp[j].maxTemperature=4000;}
  input.model.thermo.species=sp;input.model.thermo.coefficients=coefficients;input.model.thermo.coefficientCount=6;
  input.model.viscosity=.002;input.model.conductivity=.08;input.model.diffusivity[0]=.001;input.model.diffusivity[1]=.002;
  input.pressure=90000;input.temperature=500;input.normal[0]=1;input.velocity[1]=2;
  input.matchingDistance=.2;input.ownerDistance=.1;input.quadrature.volume=1;
  input.matching.temperature=600;input.matching.velocity[1]=20;input.matching.massFraction[0]=.7;input.matching.massFraction[1]=.3;
  input.massFlux[0]=.007;input.massFlux[1]=.003;input.matching.k=.5;input.matching.omega=200;
  config.enableSst=true;config.nodes=3;config.maxIterations=1;
  s.sstWallTreatment=2;s.sstConfigured=1;s.turbulenceModel=3;s.sstWallCmu=.09;s.sstWallKappa=.41;s.sstWallE=9.8;
  s.gasSpecies.mode=ugkwp::GasMode::MixtureFrozen;s.gasSpecies.thermo=input.model.thermo;
  s.gasSpecies.rho=new Real[4]{1.4,1.4,.6,.6};s.gasSpecies.flux=new Real[6]{811,812,813,814,815,816};
  s.gasSpecies.soundSpeed=new Real[2]{400,400};s.gasSpecies.diffusivity=input.model.diffusivity;
  s.riemannBoundaryKind[1]=2;s.gasSpecies.cellStatus[0]=s.gasSpecies.faceStatus[1]=0;
  auto&w=s.gasBoundaryLayer;w.enabled=true;w.count=1;w.faceSlot=new int[3]{-1,0,-1};w.ownerSlot=new int[2]{0,-1};
  w.status=new int[1]{};w.exchange=new ugkwp::GasBoundaryLayerExchange<Real>[1];w.sst=new ugkwp::GasBoundaryLayerSstClosure<Real>[1];w.speciesFlux=new Real[2]{817,818};
 }
 void produce(State&s){ugkwp::gaswall::WallStatus status;
  ck(ugkwp::gaswall::evaluateWallModel(input,config,workspace,output,status),"actual BVP unavailable");
  ck(ugkwp::publishGasBoundaryLayerOutput(s,0,input,output,Real(1),Real(.25)),"actual wall exchange unavailable");
 }
};

int main(){State s;initialise(s);ActualWall wall(s);
if(true)wall.input.matching.temperature=std::numeric_limits<Real>::infinity();
wall.produce(s);auto&ex=s.gasBoundaryLayer.exchange[0];auto&closure=s.gasBoundaryLayer.sst[0];
ck(ex.ready&&ex.k==0,"profile completion or high-Re k failed");
ck(wall.output.traceTemperature==500&&wall.output.wallSpeciesFlux[0]==.007,"actual profile fields lost");
const Real correction=s.p[0]-wall.input.pressure;
Real expected[5]={ex.mass,ex.momentumX+correction*s.Sfx[1],ex.momentumY,ex.momentumZ,ex.energy};
// Stationary face has no pressure correction sweep; publisher's prescribed
// wall motion remains the actual physical trace/work in its exchange.
threadIdx.x=1;computeGasInternalFaceFluxKernel<false>(&s,Real(.001));
Real got[5]={s.gasPhiRho[1],s.gasPhiRhoUx[1],s.gasPhiRhoUy[1],s.gasPhiRhoUz[1],s.gasPhiRhoE[1]};
for(int i=0;i<5;++i)ck(got[i]==expected[i]||(std::isnan(got[i])&&std::isnan(expected[i])),"selected actual bulk tail missing");
ck(s.gasSpecies.flux[1]==-.007&&s.gasSpecies.flux[4]==-.003,"selected species-major tail missing");
audit(s);threadIdx.x=0;const Real kBefore=s.rhoK[0],omegaBefore=s.rhoOmega[0];
applySstWallFunctionStateKernel(&s);
near(s.omega[0],clampMin(closure.ownerOmega,s.sstOmegaMin),"actual owner omega");
near(observed.constraintK[0],Real(0),"wall profile replaced coarse k");
near(observed.constraintOmega[0],s.rhoOmega[0]-omegaBefore,"actual omega constraint audit");
threadIdx.x=1;computeSstFaceFluxKernel(&s);
ck(s.sstPhiRhoK[1]==0&&s.sstPhiRhoOmega[1]==0,"auxiliary wall profile became inventory flux");
if(!true){threadIdx.x=0;Real sk,so;sstSourcesForCell(s,0,Real(0),sk,so);
 const Real production=std::min(closure.wallShearStress*std::pow(s.sstWallCmu,Real(.25))*std::sqrt(s.k[0])/(s.rho[0]*s.sstWallKappa*closure.ownerDistance),s.sstCoefficients.c1*s.sstCoefficients.betaStar*s.k[0]*s.omega[0]);
 near(sk,s.rho[0]*(production-s.sstCoefficients.betaStar*s.k[0]*s.omega[0]),"actual traction/coarse-k source");
 const Real div=s.gasPhiRho[1]/sstFaceDensity(s,1)/s.V[0];
 sstSourcesForCell(s,0,div,sk,so);
 const Real dt=1e-7;applySstFluxAndSourceKernel(&s,dt);
 near(s.rhoK[0],kBefore+dt*sk,"actual SST inventory increment");
 near(observed.sourceK[0],dt*sk,"actual SST source audit");
 ck(observed.transportK[0]==0&&observed.transportOmega[0]==0,"unexpected transport audit");
 ck(std::isfinite(observed.sourceOmega[0])&&std::isfinite(observed.constraintOmega[0]),"omega audit tails missing");
 }
}
