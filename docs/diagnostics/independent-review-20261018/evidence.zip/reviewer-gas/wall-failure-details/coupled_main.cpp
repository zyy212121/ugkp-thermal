
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

#include <type_traits>
#include <iomanip>
int main(){
 Model m;m.in.temperature=500;m.in.matching.temperature=700;m.in.matching.velocity[0]=30;
 m.in.matching.k=.5;m.in.matching.omega=200;m.in.model.mode=GasMode::MixtureChemistry;
 m.coef[2]=100000;m.rx[0].highRate.preExponential=20;
 m.in.model.diffusivity[0]=1e-4;m.in.model.diffusivity[1]=3e-4;
 m.in.massFlux[0]=.0007;m.in.massFlux[1]=.0003;
 double y[2]={.002,.006},weights[2]={2e-7,2e-7};m.in.quadrature={y,weights,2,4e-7,1.6e-9};
 WallModelConfig<double> c;c.enableSst=true;c.nodes=48;c.maxIterations=100;
 WallWorkspace<double,2,48> w;WallOutput<double,2> out;WallStatus status;
 static_assert(sizeof(w.state[0][0])==sizeof(double),"wall arithmetic is binary64");
 assert(evaluateWallModel(m.in,c,w,out,status));assert(status.residual<1.01e-8);
 std::cout<<std::setprecision(17)<<"{\"residual\":"<<status.residual<<",\"balance\":[";
 for(int j=0;j<2;++j){
  // Recompute after storing actual public values, not from an FP64-only audit.
  const double matching=out.matchingSpeciesFlux[j],wall=out.wallSpeciesFlux[j],reaction=out.reactionIntegral[j];
  const double balance=double(matching)-double(wall)-double(reaction);
  assert(std::abs(balance)<1e-8);assert(std::abs(out.speciesBalanceResidual[j])<1e-8);
  assert(std::abs(double(out.speciesBalanceResidual[j])-balance)<1e-15);
  if(j)std::cout<<",";
  std::cout<<balance;
 }
 std::cout<<"],\"q\":"<<out.conductiveHeatFlux<<",\"tau\":"<<out.traction[0]<<",\"omega\":"<<out.ownerOmega<<"}\n";
 c.relativeTolerance=1e-20;c.absoluteTolerance=0;
 assert(evaluateWallModel(m.in,c,w,out,status));assert(status.residual>c.relativeTolerance);
 assert(status.code==WallCode::Success&&out.residual==double(status.residual));
 c.model=BoundaryLayerModel::ConstantTransport;c.enableSst=false;c.relativeTolerance=1e-8;
 m.in.model.mode=GasMode::MixtureFrozen;m.in.massFlux[0]=m.in.massFlux[1]=0;m.in.temperature=std::numeric_limits<double>::quiet_NaN();
 assert(evaluateWallModel(m.in,c,w,out,status));assert(status.code!=WallCode::Success);
 assert(std::isnan(out.traceTemperature)&&std::isnan(out.conductiveHeatFlux));
 assert(out.wallSpeciesFlux[0]==0&&out.matchingSpeciesFlux[1]==0);

}
