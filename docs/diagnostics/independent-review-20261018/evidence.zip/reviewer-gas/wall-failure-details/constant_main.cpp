
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

int main(){

 Model m;WallModelConfig<double> c;c.model=BoundaryLayerModel::ConstantTransport;
 WallWorkspace<double,2,32> w;WallOutput<double,2> o;WallStatus s;
 assert(evaluateWallModel(m.in,c,w,o,s));
 assert(near(o.traction[0],.02));assert(near(o.traction[1],0));
 // Dissipation heats the gas: linear conduction plus half the shear work.
 assert(near(o.conductiveHeatFlux,-800-.1));
 assert(near(o.traceTemperature,300));
 m.in.matching.velocity[0]=0;m.in.massFlux[0]=.0007;m.in.massFlux[1]=.0003;
 assert(evaluateWallModel(m.in,c,w,o,s));
 const double pe=.001*1000*.01/.04;
 assert(near(o.conductiveHeatFlux,-.001*1000*200/std::expm1(pe)));
 m.in.temperature=-1;
 assert(evaluateWallModel(m.in,c,w,o,s));assert(o.traceTemperature==-1);
 m.in.temperature=300;m.in.massFlux[0]=-.1;
 assert(evaluateWallModel(m.in,c,w,o,s));assert(o.wallSpeciesFlux[0]==-.1);
 m.in.massFlux[0]=.0007;m.in.normal[1]=2;
 assert(evaluateWallModel(m.in,c,w,o,s));assert(std::isfinite(o.conductiveHeatFlux));
 m.in.temperature=std::numeric_limits<double>::quiet_NaN();
 assert(evaluateWallModel(m.in,c,w,o,s));assert(std::isnan(o.traceTemperature)&&std::isnan(o.conductiveHeatFlux));
 assert(o.wallSpeciesFlux[0]==.0007&&o.matchingSpeciesFlux[1]==.0003);
 
}
