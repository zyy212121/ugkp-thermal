
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

#include <cstring>
template<class T> void same(T a,T b){assert(std::memcmp(&a,&b,sizeof(T))==0);}
template<class T,int N> void sameOutput(const WallOutput<T,N>& a,const WallOutput<T,N>& b){
 same(a.traceTemperature,b.traceTemperature);same(a.traceDensity,b.traceDensity);
 same(a.conductiveHeatFlux,b.conductiveHeatFlux);same(a.integratedKSource,b.integratedKSource);
 same(a.ownerOmega,b.ownerOmega);same(a.wallKFlux,b.wallKFlux);same(a.residual,b.residual);
 same(a.chemistryMismatchAvailable,b.chemistryMismatchAvailable);same(a.iterations,b.iterations);
 for(int d=0;d<3;++d){same(a.traceVelocity[d],b.traceVelocity[d]);same(a.traction[d],b.traction[d]);}
 for(int j=0;j<N;++j){same(a.traceMassFraction[j],b.traceMassFraction[j]);
  same(a.wallSpeciesFlux[j],b.wallSpeciesFlux[j]);same(a.matchingSpeciesFlux[j],b.matchingSpeciesFlux[j]);
  same(a.reactionIntegral[j],b.reactionIntegral[j]);same(a.chemistryMismatch[j],b.chemistryMismatch[j]);
  same(a.speciesBalanceResidual[j],b.speciesBalanceResidual[j]);}
}

template<class R> void physicalCast(const WallOutput<R,2>& out,const WallOutput<double,2>& exact){
#define FIELD(name) assert(out.name==R(exact.name)&&std::isfinite(out.name))
 FIELD(traceTemperature);FIELD(traceDensity);FIELD(conductiveHeatFlux);FIELD(ownerOmega);FIELD(wallKFlux);
#undef FIELD
 for(int d=0;d<3;++d){assert(out.traceVelocity[d]==R(exact.traceVelocity[d])&&std::isfinite(out.traceVelocity[d]));
  assert(out.traction[d]==R(exact.traction[d])&&std::isfinite(out.traction[d]));}
 for(int j=0;j<2;++j){
#define ARRAY(name) assert(out.name[j]==R(exact.name[j])&&std::isfinite(out.name[j]))
  ARRAY(traceMassFraction);ARRAY(wallSpeciesFlux);ARRAY(matchingSpeciesFlux);ARRAY(reactionIntegral);
#undef ARRAY
 }
 assert(out.iterations==exact.iterations);
}
int main(){

 Model m;m.in.integrateOwnerKSource=false;m.in.temperature=m.in.matching.temperature=500;m.in.matching.velocity[0]=0;
 m.in.matchingDistance=1;m.in.ownerDistance=.5;m.in.massFlux[0]=3e38;m.in.massFlux[1]=-3e38;
 m.in.model.diffusivity[0]=m.in.model.diffusivity[1]=2e38;for(int j=0;j<6;++j)m.coef[j]=0;
 WallModelConfig<double> c;c.nodes=3;c.maxIterations=0;WallWorkspace<double,2,3> w;WallOutput<double,2> out;WallStatus status;
 auto in=detail::wallComputationInput(m.in);auto controls=detail::wallComputationConfig(c);WallOutput<double,2> exact;
 assert(evaluateReactingWallLayerImpl(in,controls,w,exact,status));
 detail::LayerContext<double,2> ctx;detail::makeContext(in,controls,ctx);
 for(int i=0;i<3;++i)w.state[i][3]=1.8-1.5*w.y[i];
 double norm;assert(!detail::allResidual(in,controls,ctx,w.state,w.y,w.residual,norm));
 // This deliberately signed profile is ineligible for Newton, but terminal
 // publication still preserves the actual overflowing diagnostic arithmetic.
 assert(detail::publishLayer(in,controls,ctx,w,0,norm,exact,true));
 std::memset(static_cast<void*>(&out),0xA5,sizeof(out));assert(detail::publishWallPrecision(m.in,exact,out));physicalCast(out,exact);
 const double audit=double(out.matchingSpeciesFlux[0])-double(out.wallSpeciesFlux[0])-double(out.reactionIntegral[0]);
 assert(std::isfinite(audit)&&audit<-1e38);
 assert(out.speciesBalanceResidual[0]==double(audit)&&std::isfinite(out.speciesBalanceResidual[0])&&out.speciesBalanceResidual[0]<0);
 std::cout<<"audit64="<<audit<<" published_audit="<<out.speciesBalanceResidual[0]<<'\n';

}