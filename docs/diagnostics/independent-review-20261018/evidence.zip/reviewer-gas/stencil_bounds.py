import sys,pathlib,subprocess
root=pathlib.Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-review-20261017');out=root.parent/'pr19-evidence-20261017/reviewer-gas';sys.path[:0]=[str(root),str(root/'validation/tests/gas_transport')]
from test_mixture_transport import fixture
pre=(root/'validation/tests/gas_transport/gas_state_probe.cpp').read_text().split('void hashBytes')[0]
body=r'''
int main(){State s;initialise(s);ugkp::diagnostics::DeviceContext d{};s.diagnostics=&d;s.cellPlaneStart[0]=8;s.cellPlaneCount[0]=1;threadIdx.x=0;computeGasPrimitiveGradientsKernel(&s);}
'''
(out/'stencil_bounds.cpp').write_text(pre+fixture()+body)
cmd=['g++','-std=c++17','-O0','-g','-fsanitize=address','-I'+str(root/'common'),'-I'+str(root/'common/gasNumerics'),'-I'+str(root/'validation/tests/gas_transport'),str(out/'stencil_bounds.cpp'),'-o',str(out/'stencil_bounds')]
subprocess.run(cmd,check=True);p=subprocess.run([str(out/'stencil_bounds')],capture_output=True,text=True);(out/'stencil_bounds.log').write_text(p.stdout+p.stderr);print('exit',p.returncode);print(p.stderr[:1800])
