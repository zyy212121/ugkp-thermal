from pathlib import Path
root=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-fixes-20261017')
p=root/'common/operators/computeSstFaceFluxKernel.cuh';s=p.read_text();old='''        if(s.diagnostics)recordFatal(s.diagnostics,makeRecord(Code::NonFinite,2611,27,0,
            EntityKind::Cell,c,-1,s.sstSourceNumber[c]));
        ugkwp::gasRecordCellFailure(s,c,ugkwp::GasTransportCode::NonFiniteState);
        return;''';new='''        // This post-update activity ratio is an audit only. The next Courant
        // query recomputes its own stability predictor before reducing it.
        recordWarning(s.diagnostics,makeRecord(Code::AccuracyResidual,2611,27,0,
            EntityKind::Cell,c,-1,s.sstSourceNumber[c],s.sstMaxSourceNumber,
            s.sstSourceNumber[c],Quantity::Accuracy));''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=root/'common/operators/gasFaceSubgridTransportProperties.cuh';s=p.read_text();old='''                    if(!ugkwp::gasFinite(sum) || clippedSum==GPU_OPERATOR_R(0))
                    {failure(!ugkwp::gasFinite(sum)?Code::NonFinite:Code::ZeroDenominator,
                        2659,!ugkwp::gasFinite(sum)?sum:clippedSum,Quantity::MassFraction);return;}
                    if(fabs(sum-GPU_OPERATOR_R(1))>s.gasSpecies.densityClosureTolerance)''';new='''                    if(clippedSum==GPU_OPERATOR_R(0))
                    {failure(Code::ZeroDenominator,2659,clippedSum,Quantity::MassFraction);return;}
                    // Raw fractions supply only the conservation audit. Physical
                    // properties above and below consume the finite clipped Y.
                    if(!ugkwp::gasFinite(sum) || fabs(sum-GPU_OPERATOR_R(1))>s.gasSpecies.densityClosureTolerance)''';assert old in s;s=s.replace(old,new);p.write_text(s)
