// Runs unchanged production device functions serially on a host. Not CUDA execution.
#include <cmath>
using std::isfinite;
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include "GpuPrecisionTypes.H"
#include "CharacteristicMuscl.cuh"
#include "OpenFoamLimitedLinear.cuh"
#include "OpenFoamViscousFlux.cuh"
#include "OpenFoamWallFunctions.cuh"
#include "RiemannBoundaryState.cuh"
#include "RiemannGasFlux.cuh"
#include "GpuSstAlgebra.cuh"
#include "GpuLesAlgebra.cuh"
using Real=GpuReal;
using Time=double;
#define GPU_OPERATOR_REAL Real
#define GPU_OPERATOR_TIME Time
#define GPU_OPERATOR_R GPU_R
#define GPU_OPERATOR_TINY(x) GPU_R(1e-30)
#define __host__
#define __global__
#define __device__
#define __forceinline__ inline
// PTX traps are represented by process failure in this serial host emulator.
#define asm(...) std::abort()
struct ThreadIndex { int x=0; } blockIdx, threadIdx, blockDim;
constexpr Real OfSmall=GPU_R(2.22044604925031308085e-16);
constexpr Real OfVSmall=GPU_R(1e-30);
constexpr Real OfGreat=GPU_R(1.0)/OfSmall;
struct GasPrimDevice { Real rho,ux,uy,uz,p,T; };
#include "legacy_gas_fixture.hpp"
#ifdef LEGACY_REFERENCE
using DeviceState=LegacyGasFixture;
#else
// No application DeviceState definition: the actual operators must be generic.
#include "gasTransport/GasStateView.H"
#endif
#include "operators/clampMin.cuh"
#include "operators/clampRange.cuh"
#include "operators/linearScheduledValueDevice.cuh"
#include "operators/makeGasPrimDevice.cuh"
#include "operators/riemannFacePrimitiveForGradient.cuh"
#include "operators/computeGasPrimitiveGradientsKernel.cuh"
#include "operators/computeSstGradientsKernel.cuh"
#include "operators/sstVelocityInvariants.cuh"
#include "operators/computeGasHllcAdcSensorKernel.cuh"
#include "operators/updateBarthLimiter.cuh"
#include "operators/computeGasGradientLimiterKernel.cuh"
#include "operators/computeGasEddyViscosityKernel.cuh"
#include "operators/updateWaveTransmissivePressureBoundaryKernel.cuh"
#include "operators/updateLegacyGasBoundaryMirrorKernel.cuh"
#include "operators/gasFaceSubgridTransportProperties.cuh"
#include "operators/computeRiemannGasFaceFluxDevice.cuh"
#include "operators/computeGasInternalFaceFluxKernel.cuh"
#include "operators/computeGasFluxPositivityScaleKernel.cuh"
#include "operators/computeSstFaceFluxKernel.cuh"

#ifdef LEGACY_OPTIONAL_SPECIES
struct TestLegacyGasFixture:LegacyGasFixture{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
#else
using TestLegacyGasFixture=LegacyGasFixture;
#endif

struct State:ugkwp::GasStateView<Real,Time,ugkwp::SstCoefficients>{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
void ck(bool good,const char*message){if(!good){std::fprintf(stderr,"%s\n",message);std::abort();}}
void initialise(State&s){
s.diagnostics=new ugkp::diagnostics::DeviceContext[8]{};
s.Cx=new Real[8]{};
s.Cy=new Real[8]{};
s.Cz=new Real[8]{};
s.Sfx=new Real[8]{};
s.Sfy=new Real[8]{};
s.Sfz=new Real[8]{};
s.Tgas=new Real[8]{};
s.Ux=new Real[8]{};
s.Uy=new Real[8]{};
s.Uz=new Real[8]{};
s.V=new Real[8]{};
s.cellFaceId=new int[8]{};
s.cellLength=new Real[8]{};
s.cellPlaneCount=new int[8]{};
s.cellPlaneStart=new int[8]{};
s.deltaCoeffs=new Real[8]{};
s.faceCx=new Real[8]{};
s.faceCy=new Real[8]{};
s.faceCz=new Real[8]{};
s.faceNeighbour=new int[8]{};
s.faceOwner=new int[8]{};
s.facePeriodicDx=new Real[8]{};
s.facePeriodicDy=new Real[8]{};
s.facePeriodicDz=new Real[8]{};
s.facePeriodicPair=new int[8]{};
s.faceWeight=new Real[8]{};
s.gasBoundaryKind=new int[8]{};
s.gasBoundaryP=new Real[8]{};
s.gasBoundaryPFix=new int[8]{};
s.gasBoundaryPWave=new int[8]{};
s.gasBoundaryPWaveFieldInf=new Real[8]{};
s.gasBoundaryPWaveGamma=new Real[8]{};
s.gasBoundaryPWaveLInf=new Real[8]{};
s.gasBoundaryRho=new Real[8]{};
s.gasBoundaryRhoFix=new int[8]{};
s.gasBoundaryT=new Real[8]{};
s.gasBoundaryTFix=new int[8]{};
s.gasBoundaryUFix=new int[8]{};
s.gasBoundaryUx=new Real[8]{};
s.gasBoundaryUy=new Real[8]{};
s.gasBoundaryUz=new Real[8]{};
s.gasDiffusionNumber=new Real[8]{};
s.gasFluxPositivityScale=new Real[8]{};
s.gasGradientLimiterP=new Real[8]{};
s.gasGradientLimiterRho=new Real[8]{};
s.gasGradientLimiterT=new Real[8]{};
s.gasGradientLimiterUx=new Real[8]{};
s.gasGradientLimiterUy=new Real[8]{};
s.gasGradientLimiterUz=new Real[8]{};
s.gasHllcAdcSensor=new Real[8]{};
s.gasPhiRho=new Real[8]{};
s.gasPhiRhoE=new Real[8]{};
s.gasPhiRhoUx=new Real[8]{};
s.gasPhiRhoUy=new Real[8]{};
s.gasPhiRhoUz=new Real[8]{};
s.gradKX=new Real[8]{};
s.gradKY=new Real[8]{};
s.gradKZ=new Real[8]{};
s.gradOmegaX=new Real[8]{};
s.gradOmegaY=new Real[8]{};
s.gradOmegaZ=new Real[8]{};
s.gradPx=new Real[8]{};
s.gradPy=new Real[8]{};
s.gradPz=new Real[8]{};
s.gradRhoX=new Real[8]{};
s.gradRhoY=new Real[8]{};
s.gradRhoZ=new Real[8]{};
s.gradTX=new Real[8]{};
s.gradTY=new Real[8]{};
s.gradTZ=new Real[8]{};
s.gradUxX=new Real[8]{};
s.gradUxY=new Real[8]{};
s.gradUxZ=new Real[8]{};
s.gradUyX=new Real[8]{};
s.gradUyY=new Real[8]{};
s.gradUyZ=new Real[8]{};
s.gradUzX=new Real[8]{};
s.gradUzY=new Real[8]{};
s.gradUzZ=new Real[8]{};
s.k=new Real[8]{};
s.magSf=new Real[8]{};
s.nut=new Real[8]{};
s.omega=new Real[8]{};
s.p=new Real[8]{};
s.pressureScheduleTimes=new Time[8]{};
s.pressureScheduleValues=new Real[8]{};
s.rho=new Real[8]{};
s.rhoE=new Real[8]{};
s.rhoENext=new Real[8]{};
s.rhoK=new Real[8]{};
s.rhoKInitial=new Real[8]{};
s.rhoNext=new Real[8]{};
s.rhoOmega=new Real[8]{};
s.rhoOmegaInitial=new Real[8]{};
s.rhoUx=new Real[8]{};
s.rhoUxNext=new Real[8]{};
s.rhoUy=new Real[8]{};
s.rhoUyNext=new Real[8]{};
s.rhoUz=new Real[8]{};
s.rhoUzNext=new Real[8]{};
s.riemannBoundaryKind=new int[8]{};
s.riemannBoundaryP=new Real[8]{};
s.riemannBoundaryPFix=new int[8]{};
s.riemannBoundaryPWave=new int[8]{};
s.riemannBoundaryRho=new Real[8]{};
s.riemannBoundaryRhoFix=new int[8]{};
s.riemannBoundaryT=new Real[8]{};
s.riemannBoundaryTFix=new int[8]{};
s.riemannBoundaryUFix=new int[8]{};
s.riemannBoundaryUx=new Real[8]{};
s.riemannBoundaryUy=new Real[8]{};
s.riemannBoundaryUz=new Real[8]{};
s.scheduledInletFaceMask=new int[8]{};
s.sstBoundaryK=new Real[8]{};
s.sstBoundaryKMode=new int[8]{};
s.sstBoundaryOmega=new Real[8]{};
s.sstBoundaryOmegaMode=new int[8]{};
s.sstF1=new Real[8]{};
s.sstF2=new Real[8]{};
s.sstPhiRhoK=new Real[8]{};
s.sstPhiRhoOmega=new Real[8]{};
s.sstSourceNumber=new Real[8]{};
s.sstWallDistance=new Real[8]{};
s.nCells=2;s.nFaces=3;s.nInternalFaces=1;s.gasFluxScheme=1;s.gasReconstruction=0;s.gasLimiter=0;s.gasMu=0;s.gasPrClamped=.7;s.gammaGas=1.4;s.Rgas=287;s.gasCp=1004.5;s.rhoMin=1e-12;s.TgasMin=1e-9;
s.gasSpecies.mode=ugkwp::GasMode::MixtureFrozen;
auto&g=s.gasSpecies;g.rho=new Real[4]{};g.initial=new Real[4]{};g.flux=new Real[6]{};g.gradX=new Real[4]{};g.gradY=new Real[4]{};g.gradZ=new Real[4]{};g.limiter=new Real[2]{};g.boundaryMassFraction=new Real[6]{};g.compositionBoundaryFixed=new int[3]{};g.positivityScale=new Real[4]{};g.soundSpeed=new Real[2]{};g.heatCapacity=new Real[2]{};g.gasConstant=new Real[2]{};g.cellStatus=new int[2]{};g.faceStatus=new int[3]{};
auto*meta=new ugkwp::SpeciesThermoData<Real>[2];auto*coeff=new Real[6]{1000,0,-1e6,1000,0,2e6};g.thermo.species=meta;g.thermo.coefficients=coeff;g.thermo.coefficientCount=6;g.thermoControls.relativeEnergyTolerance=Real(2e-6);g.thermoControls.relativeTemperatureTolerance=Real(2e-6);
for(int k=0;k<2;++k){meta[k].molarMass=.028;meta[k].minTemperature=100;meta[k].maxTemperature=3000;meta[k].referencePressure=101325;meta[k].coefficientOffset=3*k;}
g.rho[0]=.9;g.rho[1]=.1;g.rho[2]=.1;g.rho[3]=.9;
for(int c=0;c<2;++c){s.V[c]=1;s.Cx[c]=c;s.rho[c]=1;Real rhos[2]={g.rho[c],g.rho[2+c]};s.rhoE[c]=ugkwp::mixtureEnergy(rhos,Real(700),g.thermo);s.Tgas[c]=700;s.cellPlaneStart[c]=2*c;s.cellPlaneCount[c]=2;}
s.cellFaceId[0]=0;s.cellFaceId[1]=1;s.cellFaceId[2]=0;s.cellFaceId[3]=2;
for(int f=0;f<3;++f){s.faceOwner[f]=f==2?1:0;s.faceNeighbour[f]=f==0?1:-1;s.facePeriodicPair[f]=-1;s.magSf[f]=1;s.Sfx[f]=f==1?-1:1;s.faceCx[f]=f==0?.5:f==1?-.5:1.5;s.faceWeight[f]=.5;s.deltaCoeffs[f]=f==0?1:2;s.gasBoundaryKind[f]=s.riemannBoundaryKind[f]=f==0?0:1;}
blockDim.x=1;blockIdx.x=0;
for(int c=0;c<2;++c){threadIdx.x=c;recoverGasPrimitivesKernel(&s);}
}
void transport(State&s,double dt){
for(int c=0;c<2;++c){threadIdx.x=c;computeGasPrimitiveGradientsKernel(&s);computeGasGradientLimiterKernel(&s);computeGasEddyViscosityKernel(&s);}
for(int f=0;f<3;++f){threadIdx.x=f;computeGasInternalFaceFluxKernel<false>(&s,dt);}
for(int c=0;c<2;++c){threadIdx.x=c;computeGasFluxPositivityScaleKernel(&s,dt);}
for(int f=0;f<3;++f){threadIdx.x=f;applyGasFluxPositivityScaleKernel(&s);}
for(int c=0;c<2;++c){threadIdx.x=c;applyGasFluxDivergenceByCellKernel(&s,dt);recoverGasPrimitivesKernel(&s);}
}

int main(){State s;initialise(s);ugkp::diagnostics::DeviceContext d{};s.diagnostics=&d;s.sstConfigured=1;s.sstWallTreatment=3;s.cellPlaneCount[0]=0;s.sstCoefficients=ugkwp::defaultSstCoefficients();s.k[0]=s.rhoK[0]=1;s.omega[0]=s.rhoOmega[0]=std::numeric_limits<Real>::denorm_min()*Real(100);s.sstOmegaMin=s.omega[0];s.sstKMin=1e-10;s.gradUxY[0]=1;s.nut[0]=.1;s.gradKX[0]=1e-10;s.gradOmegaX[0]=1e-10;Real sk,so;sstSourcesForCell(s,0,Real(0),sk,so);printf("sizeof=%zu sourceK=%g sourceOmega=%g rhoOmega=%g physicalNext=%g\n",sizeof(Real),double(sk),double(so),double(s.rhoOmega[0]),double(s.rhoOmega[0]+so));threadIdx.x=0;applySstFluxAndSourceKernel(&s,1.);printf("fatal=%u site=%u activity=%g finalOmega=%g\n",d.fatalClaim,d.firstFatal.sourceSiteId,double(s.sstSourceNumber[0]),double(s.rhoOmega[0]));}
