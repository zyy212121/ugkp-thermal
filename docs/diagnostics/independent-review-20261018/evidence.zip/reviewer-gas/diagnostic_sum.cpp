#include "gasTransport/MixtureThermo.H"
#include <cstdio>
#include <limits>
int main(){ugkp::diagnostics::DeviceContext d{}; double p[2]={std::numeric_limits<double>::max(),std::numeric_limits<double>::max()},y[2]={-7,-7};bool ok=ugkwp::mixtureMassFractionsFromDensities<double,2>(p,1.,1e-10,y,&d);printf("ok=%d fatal=%u site=%u observed=%g Y=%g,%g\n",ok,d.fatalClaim,d.firstFatal.sourceSiteId,d.firstFatal.observed,y[0],y[1]);}
