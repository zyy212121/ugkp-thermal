#include "gasTransport/MixtureThermo.H"
#include "gasTransport/SpeciesDiffusion.H"
#include <cstdio>
#include <limits>
int main(){using namespace ugkwp;ugkp::diagnostics::DeviceContext d{};SpeciesThermoData<double> meta[1];meta[0].molarMass=.028;meta[0].minTemperature=1;meta[0].maxTemperature=3000;double coef[3]={1000,0,0};SpeciesThermoView<double,1> t;t.species=meta;t.coefficients=coef;t.coefficientCount=3;t.diagnostics=&d;
 double y[1]={1},g[1]={0},f[1]={7},e=7;bool ok=correctedSpeciesDiffusion(y,g,std::numeric_limits<double>::quiet_NaN(),(const double*)nullptr,0.,.7,300.,t,f,e);printf("densityNaN ok=%d site=%u observed=%g (expected NaN)\n",ok,d.firstFatal.sourceSiteId,d.firstFatal.observed);
 d={};coef[1]=std::numeric_limits<double>::max();double cp=speciesCp(0,300.,t);printf("cpOverflow cp=%g site=%u observed=%g (expected inf) quantity=%u\n",cp,d.firstFatal.sourceSiteId,d.firstFatal.observed,d.firstFatal.quantityId);
}
