from pathlib import Path
import subprocess
base=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');out=base/'pr19-evidence-20261017/reviewer-gas/wall-failure-details';out.mkdir(exist_ok=True)
cases={'selected_invalid':'test_actual_wall_selected_face1/mixture.cpp','positivity':'test_actual_wall_positivity_en0/mixture.cpp','constant':'test_constant_limits_and_failu0/wall.cpp','coupled':'test_double_state_strict_coupl0/internal_64.cpp','residual1':'test_large_double_residual_pub1/diagnostic.cpp','species_balance':'test_large_double_species_bala0/diagnostic.cpp'}
logs=[]
for name,rel in cases.items():
 raw=(Path('/tmp/pytest-of-lss/pytest-24')/rel).read_text();(out/(name+'_original.cpp')).write_text(raw)
 for version,repo in [('main','pr19-main-20261017'),('fixed','pr19-fixes-20261017')]:
  source=raw
  if version=='fixed':
   trace='''\n#include <csignal>\nugkp::diagnostics::DeviceContext reviewContext{};\nvoid reviewAbort(int){auto&r=reviewContext.firstFatal;fprintf(stderr,"FIRST fatal=%u site=%u op=%u stage=%u entity=%lld comp=%d observed=%.17g code=%u\\n",reviewContext.fatalClaim,r.sourceSiteId,r.operatorId,r.stageId,(long long)r.entityIndex,r.component,r.observed,unsigned(r.code));std::_Exit(93);}\n'''
   at=source.index('int main(');source=source[:at]+trace+source[at:]
   source=source.replace('Model m;','Model m;std::signal(SIGABRT,reviewAbort);m.in.diagnostics=&reviewContext;')
   source=source.replace('ActualWall wall(s);','ActualWall wall(s);std::signal(SIGABRT,reviewAbort);wall.input.diagnostics=&reviewContext;s.diagnostics=&reviewContext;')
  src=out/(name+'_'+version+'.cpp');src.write_text(source);exe=src.with_suffix('');root=base/repo
  cmd=['g++','-std=c++17','-O1','-I'+str(root),'-I'+str(root/'common'),'-I'+str(root/'common/gasNumerics'),'-I'+str(root/'validation/tests/gas_transport'),str(src),'-o',str(exe)]
  build=subprocess.run(cmd,capture_output=True,text=True)
  if build.returncode: result=f'{name} {version} BUILD FAIL\n{build.stderr[:1200]}'
  else:
   run=subprocess.run([str(exe)],capture_output=True,text=True);result=f'{name} {version} exit={run.returncode}\n{run.stdout}{run.stderr}'
  logs.append(result);print(result)
(out/'results.log').write_text('\n'.join(logs))
