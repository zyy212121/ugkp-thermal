from pathlib import Path
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-fixes-20261017/validation/tests')
p=r/'gas_transport/test_actual_wall_producer_consumers.py';s=p.read_text();s=s.replace('if(TERMINAL)wall.input.matching.temperature=std::numeric_limits<Real>::infinity();','''ugkp::diagnostics::DeviceContext diagnostic{};s.diagnostics=&diagnostic;wall.input.diagnostics=&diagnostic;
if(TERMINAL){wall.input.matching.temperature=std::numeric_limits<Real>::infinity();
 ugkwp::gaswall::WallStatus status;wall.output.traceTemperature=123;
 ck(!ugkwp::gaswall::evaluateWallModel(wall.input,wall.config,wall.workspace,wall.output,status),"nonfinite wall temperature accepted");
 ck(diagnostic.firstFatal.code==ugkp::diagnostics::Code::NonFinite&&std::isinf(diagnostic.firstFatal.observed),"temperature evidence lost");
 ck(diagnostic.firstFatal.sourceSiteId==2403&&diagnostic.firstFatal.component==2&&wall.output.traceTemperature==123,"invalid wall published output");return 0;}''');s=s.replace('wall.input.massFlux[0]=-.007;wall.input.massFlux[1]=.003;wall.produce(s);','ugkp::diagnostics::DeviceContext diagnostic{};s.diagnostics=&diagnostic;wall.input.diagnostics=&diagnostic;\nwall.input.massFlux[0]=-.007;wall.input.massFlux[1]=.003;wall.produce(s);');s=s.replace('ck(s.gasSpecies.faceStatus[1]==int(ugkwp::GasTransportCode::NegativeInventory)&&sink[1]==902,"strict native limiter certificate changed");','''ck(!ugkp::diagnostics::hasFatal(&diagnostic)&&s.gasSpecies.faceStatus[1]==0&&sink[1]==s.gasPhiRhoE[1],"finite limiter audit rejected physical exchange");
ck(diagnostic.warnings[1].count>0,"limiter warning missing");''');p.write_text(s)
p=r/'gas_wall/test_wall_model.py';s=p.read_text();s=s.replace('Model m;WallModelConfig<double> c;c.model=BoundaryLayerModel::ConstantTransport;','Model m;ugkp::diagnostics::DeviceContext diagnostic{};m.in.diagnostics=&diagnostic;\n WallModelConfig<double> c;c.model=BoundaryLayerModel::ConstantTransport;',1);s=s.replace('assert(evaluateWallModel(m.in,c,w,o,s));assert(o.traceTemperature==-1);','''const auto saved=o;
 assert(!evaluateWallModel(m.in,c,w,o,s));assert(diagnostic.firstFatal.code==ugkp::diagnostics::Code::NegativeTemperature&&diagnostic.firstFatal.observed==-1);
 assert(o.traceTemperature==saved.traceTemperature&&o.conductiveHeatFlux==saved.conductiveHeatFlux);diagnostic={};''',1);s=s.replace('assert(evaluateWallModel(m.in,c,w,o,s));assert(std::isnan(o.traceTemperature)&&std::isnan(o.conductiveHeatFlux));','''const auto finite=o;
 assert(!evaluateWallModel(m.in,c,w,o,s));assert(diagnostic.firstFatal.code==ugkp::diagnostics::Code::NonFinite&&std::isnan(diagnostic.firstFatal.observed));
 assert(o.traceTemperature==finite.traceTemperature&&o.conductiveHeatFlux==finite.conductiveHeatFlux);''',1);p.write_text(s)
p=r/'gas_wall/test_wall_internal_precision.py';s=p.read_text();s=s.replace('Model m;m.in.temperature=500;m.in.matching.temperature=700;m.in.matching.velocity[0]=30;','Model m;ugkp::diagnostics::DeviceContext diagnostic{};m.in.diagnostics=&diagnostic;\n m.in.temperature=500;m.in.matching.temperature=700;m.in.matching.velocity[0]=30;',1);s=s.replace('assert(evaluateWallModel(m.in,c,w,out,status));assert(status.code!=WallCode::Success);\n assert(std::isnan(out.traceTemperature)&&std::isnan(out.conductiveHeatFlux));\n assert(out.wallSpeciesFlux[0]==0&&out.matchingSpeciesFlux[1]==0);','''const auto saved=out;
 assert(!evaluateWallModel(m.in,c,w,out,status));assert(status.code!=WallCode::Success);
 assert(diagnostic.firstFatal.code==ugkp::diagnostics::Code::NonFinite&&std::isnan(diagnostic.firstFatal.observed));
 assert(out.traceTemperature==saved.traceTemperature&&out.conductiveHeatFlux==saved.conductiveHeatFlux);
 assert(out.wallSpeciesFlux[0]==saved.wallSpeciesFlux[0]&&out.matchingSpeciesFlux[1]==saved.matchingSpeciesFlux[1]);''',1);p.write_text(s)
p=r/'gas_wall/test_wall_diagnostic_continuation.py';s=p.read_text();s=s.replace('Model m;m.in.integrateOwnerKSource=false;m.in.model.viscosity=1e20;m.in.model.conductivity=-.04;','Model m;ugkp::diagnostics::DeviceContext diagnostic{};m.in.diagnostics=&diagnostic;\n m.in.integrateOwnerKSource=false;m.in.model.viscosity=1e20;m.in.model.conductivity=-.04;',1);s=s.replace('assert(evaluateReactingWallLayerImpl(in,controls,w,exact,exactStatus));','''if(LIMIT==1){exact.traceTemperature=123;
  assert(!evaluateReactingWallLayerImpl(in,controls,w,exact,exactStatus));
  assert(diagnostic.firstFatal.code==ugkp::diagnostics::Code::ZeroDenominator&&diagnostic.firstFatal.sourceSiteId==2421&&diagnostic.firstFatal.observed==0);
  assert(exact.traceTemperature==123);return 0;}
 assert(evaluateReactingWallLayerImpl(in,controls,w,exact,exactStatus));''',1);s=s.replace('m.in.model.diffusivity[0]=m.in.model.diffusivity[1]=2e38;for(int j=0;j<6;++j)m.coef[j]=0;','''m.in.model.diffusivity[0]=m.in.model.diffusivity[1]=2e38;
 ugkp::diagnostics::DeviceContext diagnostic{};m.in.diagnostics=&diagnostic;
 // Positive heat capacity keeps this a diagnostic-residual test.
 for(int j=0;j<6;++j)m.coef[j]=j%3==0?1000:0;''',1);s=s.replace('double norm;assert(!detail::allResidual(in,controls,ctx,w.state,w.y,w.residual,norm));\n // This deliberately signed profile is ineligible for Newton, but terminal\n // publication still preserves the actual overflowing diagnostic arithmetic.','''double norm;assert(detail::allResidual(in,controls,ctx,w.state,w.y,w.residual,norm));
 assert(!ugkp::diagnostics::hasFatal(&diagnostic)&&diagnostic.warnings[2].count>0);
 // Finite fractions clip; the resulting physical fluxes retain their audit.''',1);p.write_text(s)
