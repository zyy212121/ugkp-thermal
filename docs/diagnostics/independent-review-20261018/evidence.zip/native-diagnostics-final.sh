source "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/env-fixes.sh"
OUT="/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/native-diagnostics-final"
mkdir -p "$OUT"
g++ -std=c++14 -pthread -DWM_DP -DWM_LABEL_SIZE=32 -I"$ROOT/common" -I"$WM_PROJECT_DIR/src/OpenFOAM/lnInclude" -I"$WM_PROJECT_DIR/src/OSspecific/POSIX/lnInclude" "$ROOT/validation/diagnostics/test_foam.cpp" -L"$FOAM_LIBBIN" -L"$FOAM_LIBBIN/$FOAM_MPI" -lOpenFOAM -lPstream -o "$OUT/foam"
"$OUT/foam"
UGKP_DIAGNOSTIC_WARNINGS=0 "$OUT/foam"
set +e
"$OUT/foam" exit
printf 'fatal exit=%s
' "$?"
mpirun -np 2 "$OUT/foam" mpi
printf 'mpi exit=%s
' "$?"
set -e
nvcc -std=c++17 -arch=sm_89 -I"$ROOT/common" "$ROOT/validation/diagnostics/test_device.cu" -o "$OUT/device"
"$OUT/device"
compute-sanitizer --tool memcheck --error-exitcode 91 "$OUT/device"
compute-sanitizer --tool racecheck --error-exitcode 92 "$OUT/device"
compute-sanitizer --tool synccheck --error-exitcode 93 "$OUT/device"
