source "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/env-main.sh"
export PYTHONPATH="$ROOT/validation/tests/chemistry:$PYTHONPATH"
export UGKP_CASES_ROOT=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-cases
python3 -m pytest -q --import-mode=importlib validation/tests/chemistry validation/tests/gas_transport validation/tests/gas_wall --junitxml="/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/affected-main.xml"
