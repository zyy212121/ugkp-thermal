#define main original_main
#include "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-fixes-20261017/validation/solvers/CHMT/devtools/multirate/test_sweep_constraints.cpp"
#undef main
 
#include "DiagnosticsHost.H"
#include <cassert>
int main(){
    HostMesh mesh=twoHexahedra(0),out;
    std::vector<Vec3> zero(mesh.points.size());
    std::vector<unsigned char> fixed(mesh.points.size(),1);
    std::vector<Real> sweeps;SweepConstraintControls controls;
    controls.maximumIterations=1;
    controls.faceVolumeTolerance={std::numeric_limits<Real>::denorm_min()};
    SweepConstraintReport report;std::string error;
    ugkp::diagnostics::DeviceContext ctx{};Tolerances tol;tol.diagnostics=&ctx;
    assert(constrainFaceSweeps(mesh,{0},{.01},zero,fixed,zero,1,out,sweeps,report,error,controls,tol));
    assert(sweeps[0]==0 && out.points[0].x==mesh.points[0].x);
    assert(!ugkp::diagnostics::hasFatal(&ctx));
    assert(ctx.warnings[0].count+ctx.warnings[1].count>0);
    controls.faceVolumeTolerance={-1};
    assert(!constrainFaceSweeps(mesh,{0},{.01},zero,fixed,zero,1,out,sweeps,report,error,controls,tol));
    controls.faceVolumeTolerance={std::numeric_limits<Real>::quiet_NaN()};
    assert(!constrainFaceSweeps(mesh,{0},{.01},zero,fixed,zero,1,out,sweeps,report,error,controls,tol));
    controls.faceVolumeTolerance={std::numeric_limits<Real>::denorm_min()};
    zero[0].x=std::numeric_limits<Real>::quiet_NaN();
    assert(!constrainFaceSweeps(mesh,{0},{.01},zero,fixed,zero,1,out,sweeps,report,error,controls,tol));
}
