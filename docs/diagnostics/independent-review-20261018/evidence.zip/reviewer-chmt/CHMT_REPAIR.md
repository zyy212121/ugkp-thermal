# CHMT reviewer repair handoff

Repair workspace: pr19-fixes-20261017. Original review clone unchanged. Changes are uncommitted; parent owns final SHA, full build/test and upload.

Changed files:
- applications/CHMT/mesh/GeometryDiagnostics.H: positive finite residual ratios evaluated in long double; saturate report metric only. Invalid residual or nonpositive/NaN tolerance stays NaN. Positive derived infinite tolerance yields zero ratio, consistent with a tolerance beyond representable scale.
- applications/CHMT/mesh/Geometry.C: both sweep and planarity normalized metrics use the helper. Existing finite physical residual checks remain; no retries or alternate trajectories added.
- applications/CHMT/materials/Thermodynamics.H: recoverGas invalid volume/mass/momentum/energy/composition now records real value, cell, component and inherited operation/time. Momentum/mass use Unspecified rather than misleading velocity/density quantity labels. Nonfinite fraction checked before clip.
- applications/CHMT/materials/CpuMaterialDriver.C: predictor baseTrace passes actual cell index; checks surface face-map size and gas volume backing before dereference.
- validation/tests/test_review_chmt_diagnostics.py: actual real-helper geometry and recoverGas tests. Geometry checks unchanged valid geometry under denormal tolerance; NaN point and negative/NaN tolerances still fail. Gas probes mass=-123, infinite momentum.y, NaN species[1], and check actual provenance/time.

Red: repair-red.log, 2 failed at required assertion after compiling real original helper implementations; geometry unexpected false; gas missing fatal. Exit1.
Green initial: repair-green.log, 6 passed.
Expanded: repair-expanded.log, 12 passed.
Final after parent feedback: repair-final.log, 12 passed in 22.34s; exit0. git diff --check scoped files also exit0.

Final command (run from repair workspace):
PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -q -p no:cacheprovider validation/tests/test_review_chmt_diagnostics.py validation/tests/test_chmt_ablation_diagnostics.py validation/tests/test_chmt_film_single_pass.py validation/tests/test_chmt_material_domain_diagnostics.py validation/tests/test_chmt_phase_composition_diagnostic.py validation/tests/test_chmt_single_pass_diagnostics.py validation/tests/test_geometry_single_pass_diagnostics.py --basetemp=../pr19-evidence-20261017/reviewer-chmt/final-tmp

Parent registers catalogue3858; no shared catalogue edits by this reviewer. ExchangeLedger untouched by reviewer. No GPU jobs, production build/install, commits or remote changes.

Native conduction follow-up: reviewed NativeMaterialProbe and test_cpu_material_of fixtures and actual residual assembly. No end-to-end physical finite native scenario reproducing residual-only overflow obtained; no conduction change made. The source-level narrowing concern remains explicitly unproven dynamically. Large caloric scaling can affect matrix/source representability before the final audit, so a fabricated standalone summation would not prove production reachability. Parent may address source robustness separately but should not label it independently reproduced native failure.

Full regression/build/actual predictor integration remains parent verification. The helper test checks the producer and source inspection verifies baseTrace forwards the real cell; it does not execute OpenFOAM FatalError dispatch.
