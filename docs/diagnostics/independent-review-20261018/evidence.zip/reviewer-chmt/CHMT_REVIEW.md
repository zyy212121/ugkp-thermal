# Independent CHMT review of original PR 19

Base 7c696b19b5510ef94cfbbf7eb837a00c29d74f0d; head 42188aa3cc5d3a34e5cfde759d62c75ebc8ab022. Read-only checkout review; CPU probes written only under reviewer-chmt. No Git mutations, production writes, builds/installations, or GPU work performed by this reviewer.

## Confirmed defects

1. Important (P2): diagnostic scale overflow is fatal in ExchangeLedger.C:61-64, with analogous mass scale logic at 39-46. A GasSolid packet with conductive=1e308, advective=-1e308, energy=0 and all other physical values zero is finite, conservative, and has no physical state update. Absolute diagnostic scale overflows, causing false/NonFinite and observed=0. The production caller validatePacketMath is used by CpuSurfaceInterface.C and Backend interface packet calculation; failures propagate and stop, so this is not an ignored-status issue. Repro packet_overflow.cpp compiled against actual original headers yields `ok=0 fatal=1 status=8 value=0`. Use robust/scaled diagnostic summation and comparison; do not relax individual physical nonfinite checks.

2. Important (P2): finite geometry residual can reject solely because normalized diagnostic overflows. Geometry.C:866-887 evaluate() computes abs(r)/sweepTolerance and returns finite(metric), then lines 912-915 reject. The per-face tolerance can legally be denorm_min, overriding the geometric floor. Repro geometry_overflow.cpp uses real constrainFaceSweeps and twoHexahedra fixture: all points fixed, no motion, .01 target, one iteration, denorm_min face tolerance. Result `ok=0 error=nonfinite swept-volume constraint residual`. The PR fixture explicitly expects the same unattainable finite target with ordinary tolerance to retain unchanged valid geometry and warn. Saturate diagnostic ratios / use scaled comparisons; retain fatal checks on actual geometry and required Newton arithmetic.

3. Important (P2), producer probe plus complete source chain: negative gas mass loses actual first-error provenance in material predictor. recoverGas(q.mass=-123, volume=1, p.diagnostics=live context) returns false but records no fatal because failStatus gets nullptr. baseTrace (CpuMaterialDriver.C:131-143) supplies no status/entity, emits only 'wall predictor gas EOS failed', and predictWall synthesizes 4102 with observed default 0 and EntityKind::None/-1. Probe recover_provenance.cpp yields `ok=0 fatal=0 badmass=-123`. The caller does stop; this is lost site/entity/component/value, not unsafe continuation. Similar legacy failStatus(nullptr) paths exist for material/film calls. Record precise physical producer details and pass cell/face identity through wrappers.

## Additional source-confirmed gaps needing integration judgement

- CpuMaterialDriver.C:98-111 computes a global conservation diagnostic with long-double stableChange but narrows it to Real and treats nonfinite residual as fatal. boundary and each inventoryScale addition also occur in Real first. Finite per-cell values can exceed Real range when aggregated; the conservation diagnostic is not consumed by the update. No full-native extreme-state reproduction was performed, so distinguish this source finding from dynamic probes. Keep per-cell caloric state / flux validity separate, sum in extended or scaled arithmetic, and warn on diagnostic representability.
- InterfaceMath.H:618-622 similarly declares a summed thermalResidual fatal jointly with phaseEnergy; actual phaseEnergy is physical but residual needs overflow-safe evaluation. Interface composition scale accumulation and IntervalAudit.H's difference/tolerance overflow can also reject diagnostic-only arithmetic. These are not separately dynamically reproduced.
- Configuration/import/output paths call the new warning-capable thermo helpers with model.physics.diagnostics default nullptr. CHMT.C creates backend contexts only after readCoupledCase, while check-input exits beforehand. MeshIO import geometry has its own context; thermodynamic import and initialFilm do not. Consequently some new clipping/extrapolation warnings can be silently lost. This is output coverage, not warning-switch-dependent computation.
- baseTrace indexes surface.gasFace and gasMesh.volumes without checking their lengths. validateRuntimeState rebuilds meshes but does not establish all surface vector lengths. WallClosureHost::sample(HostState) checks vectors nonempty rather than c<size. No malformed-case native/ASan reproduction performed; these are pre-existing primary-path assumptions, not shown to be new regressions.

## Mechanism inventory

Removed in the reviewed diff: terminal material/conduction completion APIs, reaction full-step/two-half-step accept/retry, local material retry/halving, film and material 48-trial reconstruction attenuation, interface line-search alpha loop, gas rollback/window replay/shortening, geometry backup/completion family and geometry line search, allocation-policy cache-versus-stream fallback.

Remaining mathematical iteration: material nonlinear secant conduction/PCG, material energy Newton, interface composition Newton with explicitly bounded mass fractions, fixed-temperature composition fixed point, surface thermal bracket discovery and bisection, phase-rate bisection, geometry harmonic fixed-point solve, swept-volume full Newton with rank-revealing linear correction, adaptive spatial edge quadrature. Surface bracket discovery returns immediately on invalid evaluation; no alternative feasible domain after error. Geometry Newton certifies each full correction and stops on invalid trajectory. These do not replay physical time.

Remaining physical subdivision: gas microsteps selected from CFL before advance, material transport CFL selection before source evaluation, reaction rate/Jacobian CFL local steps, wall-program knots / material drive regime boundaries. No failed physical interval replay found in reviewed scope.

Remaining limiters/direct mechanisms: [0,1] composition/porosity/accommodation/emissivity bounds; reaction aggregate inventory factor; interface donor factor; Barth-Jespersen reconstruction; tiny negative packet inventory roundoff-to-zero (MaterialTransport.C); exact phase-event dryout roundoff; signed material sweep remainder and representable geometric target rounding. These are direct algebraic/representation policies, not retry chains. SharedGasDeviceStorage retains legacy interpolation weight .5 only for zero own+other distance; examine geometry preconditions if extending malformed-state support. Thermal boundary/input validation remains necessary operator/physics validation. Empty extrusion exact two-layer topology restriction remains an operator restriction.

## Status/synchronization/warnings

Checked Backend gas failure return chain through advanceCoupledWindow and CHMT io::require; observed failures stop rather than publish zero flux. assembleSurfacePackets now returns immediately on packet failure. No remaining selectable terminal backup implementation found in scoped files (some bool Terminal template parameters remain but no alternate behavior). GpuOwner outlives SharedGasDeviceStorage by member order; host contexts live through predictor/material calls. Device observation is added after existing blocking copies/reductions/checkStatus synchronization; metadata launch is asynchronous. No new per-check synchronization found in scoped changes. CHMT frontend explicitly noParallel, so no CHMT MPI run claimed. Shared diagnostic record concurrency and common GPU kernels owned by other reviewers.

Warning switch is in makeFoamSink/dispatch and controls output only for these owned contexts. Clipping executes before recordWarning and does not branch on output switch. No evidence of warning-toggle numerical differences found by source inspection; this reviewer did not run full warning-on/off frontend cases.

## Coverage and limitations

Read complete scoped base-to-head diffs for all 47 files listed below, not only keyword search. Traced immediate call sites in CHMT.C, MultirateEvolution, CpuMaterialDriver, CpuSurfaceInterface, Backend, SharedGasDeviceStorage, StateValidation, ThermalBoundary, InitialConditions and WallClosureHost. Read DiagnosticsFoam/host dispatch boundaries to assess warnings. Original tests were used as fixtures, not accepted as proof. Parent owns full builds, broad regression, production isolation audit, remote SHAs and final integration. No GPU, MPI, normal numerical A/B, or full-native conduction extreme-state test claimed by this reviewer. Particle algorithms excluded, but shared gas/packet routes inspected.

Conclusion: original scoped PR should not be accepted unchanged because the first two real-helper repros violate diagnostic-only warning requirements and physical error provenance is incomplete. Re-review parent fixes and final merged tree before final merge judgement.

### Reviewed changed files

- applications/CHMT/CHMT.C
- applications/CHMT/ablation/CpuSurfaceInterface.C
- applications/CHMT/ablation/CpuSurfaceInterface.H
- applications/CHMT/ablation/InterfaceMath.H
- applications/CHMT/ablation/WallClosureHost.H
- applications/CHMT/configuration/InitialConditions.H
- applications/CHMT/core/Configuration.H
- applications/CHMT/core/Types.H
- applications/CHMT/coupling/Coordinator.H
- applications/CHMT/coupling/ExchangeLedger.C
- applications/CHMT/coupling/ExchangeLedger.H
- applications/CHMT/coupling/IntervalAudit.H
- applications/CHMT/coupling/IntervalContracts.H
- applications/CHMT/film/CpuFilmDriver.C
- applications/CHMT/film/CpuFilmDriver.H
- applications/CHMT/film/FilmMath.H
- applications/CHMT/film/ResolvedNormalThermal.H
- applications/CHMT/gpu/Backend.H
- applications/CHMT/gpu/Backend.cu
- applications/CHMT/gpu/GasWallMath.H
- applications/CHMT/gpu/SharedGasDeviceStorage.cuh
- applications/CHMT/gpu/SharedMixtureStorage.H
- applications/CHMT/gpu/SingleGasContract.H
- applications/CHMT/gpu/StateValidation.H
- applications/CHMT/io/CoupledOutput.H
- applications/CHMT/io/MeshIO.H
- applications/CHMT/io/MultirateEvolution.C
- applications/CHMT/materials/ConductionContinuation.H
- applications/CHMT/materials/CpuMaterialDriver.C
- applications/CHMT/materials/CpuMaterialDriver.H
- applications/CHMT/materials/DarcyGradient.H
- applications/CHMT/materials/GasThermoAdapter.H
- applications/CHMT/materials/MaterialCaloric.H
- applications/CHMT/materials/MaterialTransport.C
- applications/CHMT/materials/MaterialTransport.H
- applications/CHMT/materials/Reaction.H
- applications/CHMT/materials/ReactionStepControl.H
- applications/CHMT/materials/StencilMath.H
- applications/CHMT/materials/Thermodynamics.H
- applications/CHMT/mesh/EmptyExtrusion.H
- applications/CHMT/mesh/Geometry.C
- applications/CHMT/mesh/Geometry.H
- applications/CHMT/mesh/GeometryDiagnostics.H
- applications/CHMT/mesh/Motion.H
- applications/CHMT/mesh/SweepConstraints.H
- applications/CHMT/mesh/SweepWorkspace.H
- applications/CHMT/mesh/TrajectorySurface.H
