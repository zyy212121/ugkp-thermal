#include "coupling/ExchangeLedger.H"
#include <iostream>
int main(){chmt::ExchangePacket p{};p.kind=chmt::ExchangeKind::GasSolid;p.gasCell=0;p.solidCell=0;p.conductive=1e308;p.advective=-1e308;ugkp::diagnostics::DeviceContext ctx{};ugkp::diagnostics::reset(ctx,1,1,3,0.5);chmt::Tolerances tol;tol.diagnostics=&ctx;chmt::DeviceStatus status{};bool ok=chmt::validatePacketMath(p,tol,&status);std::cout<<"ok="<<ok<<" fatal="<<ugkp::diagnostics::hasFatal(&ctx)<<" status="<<status.code<<" value="<<status.value<<"\n";return ok?0:1;}
