#define main historical_geometry_main
#include "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-review-20261017/validation/solvers/CHMT/devtools/multirate/test_sweep_constraints.cpp"
#undef main
int main(){HostMesh mesh=twoHexahedra(0),out;std::vector<Vec3> zero(mesh.points.size());std::vector<unsigned char> fixed(mesh.points.size(),1);std::vector<Real> sweeps;SweepConstraintControls controls;controls.maximumIterations=1;controls.faceVolumeTolerance={std::numeric_limits<Real>::denorm_min()};SweepConstraintReport report;std::string error;bool ok=constrainFaceSweeps(mesh,{0},{.01},zero,fixed,zero,1,out,sweeps,report,error,controls);std::cout<<"ok="<<ok<<" error="<<error<<"\n";return ok?0:1;}
