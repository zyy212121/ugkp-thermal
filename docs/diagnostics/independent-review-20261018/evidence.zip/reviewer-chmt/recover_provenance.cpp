#include "materials/Reaction.H"
#include <iostream>
int main(){chmt::PhysicsConfig p;ugkp::diagnostics::DeviceContext c{};ugkp::diagnostics::reset(c,8,99,4,.25);p.diagnostics=&c;p.tolerances.diagnostics=&c;chmt::GasQ q{};q.mass=-123;chmt::GasPrimitive out{};bool ok=chmt::recoverGas(q,1,p,out);std::cout<<"ok="<<ok<<" fatal="<<ugkp::diagnostics::hasFatal(&c)<<" badmass="<<q.mass<<"\n";return 0;}
