#include "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/reviewer-chmt/expanded-tmp/test_film_single_pass_and_warn0/film.C"

#include <cassert>
using namespace chmt;
int main(){
 ugkp::diagnostics::DeviceContext ctx{};PhysicsConfig p;p.diagnostics=&ctx;
 p.enableFilm=true;p.spatialOrder=2;p.reconstruction=ReconstructionMode::SmoothVerification;
 p.liquid.rho=1000;p.liquid.cp0=1000;p.liquid.Tmin=100;p.liquid.Tmax=1000;p.liquidViscosity=1;
 HostState h;h.surface.area={1,1};h.surface.normal={{0,0,1},{0,0,1}};h.film.resize(2);h.filmAux.resize(2);
 h.surface.edgeOwner={0};h.surface.edgeNeighbour={1};h.surface.edgeLength={1};h.surface.edgeConormal={{1,0,0}};
 h.surface.edgeOwnerOffset={{.5,0,0}};h.surface.edgeNeighbourOffset={{-.5,0,0}};
 std::vector<CpuFilmForcing> f(2);std::vector<CpuFilmDrive>d(2);for(int i=0;i<2;++i){d[i].pressure=0;h.filmAux[i].pressure=0;}f[0].species[0]=.1;
 std::string error;bool numerical=false;assert(validate(h,p,.01,f,d,error,&numerical));
 assert(ctx.warnings[0].count==1&&!ugkp::diagnostics::hasFatal(&ctx));
 Evaluation e;e.q.resize(2);e.aux.resize(2);e.incidentOffsets={0,1,2};e.incident={0,0};
 for(int i=0;i<2;++i){e.aux[i].pressure=0;e.q[i].mass=1;e.q[i].species[0]=1;e.q[i].enthalpy=1000*(300+100*i);}
 FilmQ out;out.mass=77;
 recoveryCalls=0;assert(!reconstruct(0,{-10,0,0},e,h.surface,p,out));assert(recoveryCalls==1&&out.mass==77);
 recoveryCalls=0;assert(reconstruct(0,{.1,0,0},e,h.surface,p,out));assert(recoveryCalls==1&&out.mass==1);
 assert(out.enthalpy==310000);
}
