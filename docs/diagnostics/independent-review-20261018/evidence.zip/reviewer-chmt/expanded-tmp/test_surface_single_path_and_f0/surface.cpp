
#include "fixture.hpp"
int main(){
 auto p=physics();ugkp::diagnostics::DeviceContext diagnostics{};
 p.diagnostics=&diagnostics;p.tolerances.diagnostics=&diagnostics;
 auto h=host(p);auto in=input(h,p);SurfacePhysicsResult r;
 assert(solveSurfaceInterface(in,p,r));assert(std::isfinite(r.topTemperature));
 assert(!ugkp::diagnostics::hasFatal(&diagnostics));
 auto w=bulk(h,p);w.Y[0]=1.0000000000000002;
 auto q=conservativeGas(w,1,p);assert(std::isfinite(q.mass));
 assert(q.species[0]==q.mass);assert(diagnostics.warnings[2].count>0);
 w.temperature=-1;q=conservativeGas(w,1,p);assert(!std::isfinite(q.mass));
 double flux[Ns]{},fraction[Ns]{},out[Ns]{};fraction[0]=1;flux[0]=.01;
 for(auto& D:p.gasDiffusivity)D=.001;
 assert(interfaceComposition(flux,fraction,101325,300,.01,p,1e-12,out));
 assert(out[0]>=0&&out[0]<=1);assert(!ugkp::diagnostics::hasFatal(&diagnostics));
}
