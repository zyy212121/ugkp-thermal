
#include "materials/Thermodynamics.H"
#include <cassert>
using namespace chmt;
using namespace ugkp::diagnostics;
int main(){
    DeviceContext context{};reset(context,8,99,4,.25);
    PhysicsConfig p;p.diagnostics=&context;p.tolerances.diagnostics=&context;
    GasQ q{};q.mass=-123;GasPrimitive out{};
    assert(!recoverGas(q,1,p,out,nullptr,7));
    assert(hasFatal(&context));
    assert(context.firstFatal.observed==-123);
    assert(context.firstFatal.entityKind==EntityKind::Cell && context.firstFatal.entityIndex==7);
    assert(context.firstFatal.step==4 && context.firstFatal.simulationTime==.25);
    reset(context,8,99,4,.25);q.mass=1;q.momentum.y=std::numeric_limits<Real>::infinity();
    assert(!recoverGas(q,1,p,out,nullptr,9));
    assert(context.firstFatal.code==Code::NonFinite && context.firstFatal.component==1);
    assert(context.firstFatal.observed==q.momentum.y && context.firstFatal.entityIndex==9);
}
