
#include "controller.H"
#include <cassert>
#include <cmath>
using namespace chmt;
int main() {
    PhysicsConfig p;p.enableReactions=true;p.nReactions=1;
    ugkp::diagnostics::DeviceContext context{};p.diagnostics=&context;
    for(auto& c:p.condensed){c.rho=1000;c.cp0=1000;c.cp1=2;c.Tmin=100;c.Tmax=3000;}
    for(auto& s:p.species){s.R=300;s.cp0=1000;s.Tmin=100;s.Tmax=3000;}
    p.reactions[0].A=10;p.reactions[0].order[0]=1;
    p.reactions[0].condensedNu[0]=-1;p.reactions[0].condensedNu[1]=1;
    SolidQ q;q.condensed[0]=1;q.energy=caloricIntegral(0,1000,2,500);
    for(Real requested:{.001,.1,1.}) {
        ReactionStepControl control;assert(reactionStepControl(q,.001,p,.4,control));
        const Real expectedDt=minValue(requested,control.dtLimit);
        SolidQ expected,out;Real rates[Nr]{};
        assert(advanceLocalReactions(q,.001,p,expectedDt,expected,rates));
        Real dt=0;bool active=false;calls=0;
        assert(reactionStepCandidate(q,.001,p,requested,.4,out,dt,active));
        assert(active&&calls==1&&dt==expectedDt);
        assert(out.energy==expected.energy);
        for(int c=0;c<Nc;++c)assert(out.condensed[c]==expected.condensed[c]);
        for(int r=0;r<Nr;++r)assert(out.progress[r]==expected.progress[r]);
        q=out;
    }
    Real dt=17;bool active=true;SolidQ out=q;calls=0;
    assert(!reactionStepCandidate(q,.001,p,0,.4,out,dt,active));
    assert(calls==0&&dt==17&&out.energy==q.energy);
    assert(context.fatalClaim&&context.firstFatal.sourceSiteId==4117);
}
