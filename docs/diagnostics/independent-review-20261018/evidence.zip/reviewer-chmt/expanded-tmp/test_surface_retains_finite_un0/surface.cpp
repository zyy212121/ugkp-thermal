
#include "fixture.hpp"
int main(){
 auto p=physics();ugkp::diagnostics::DeviceContext diagnostics{};
 p.diagnostics=&diagnostics;p.tolerances.diagnostics=&diagnostics;
 auto h=host(p);auto in=input(h,p);MaterialPrimitive material;
 assert(recoverMaterial(in.solid,in.solidVolume,p,material));
 SurfacePhysicsResult result;material.temperature=100.25;SurfaceRootTrace trace;
 assert(findFeasibleSurfaceRoot<true>(in,p,material,p.meltTemperature,100,101,result,&trace));
 assert(result.topTemperature!=material.temperature&&result.topTemperature==trace.completedState.topTemperature);
 assert(result.topTemperature==101&&std::isfinite(result.thermalResidual));
 assert(diagnostics.warnings[1].count>0&&!diagnostics.fatalClaim);
 in.normal={1.000001,0,0};in.gasNormal={1.000001,0,0};in.solidNormal={1.000001,0,0};
 assert(solveSurfaceInterface(in,p,result));assert(std::isfinite(result.topTemperature));
 assert(!diagnostics.fatalClaim);
 Real Y[Ns]{},J[Ns]{},residual[Ns]{};Y[0]=1;
 assert(!compositionResidual(Y,Y,J,std::numeric_limits<Real>::quiet_NaN(),300,1,p,residual,nullptr));
 assert(diagnostics.firstFatal.code==ugkp::diagnostics::Code::NonFinite&&diagnostics.firstFatal.component==1);
 diagnostics={};
 assert(!compositionResidual(Y,Y,J,101325,300,0,p,residual,nullptr));
 assert(diagnostics.firstFatal.observed==0&&diagnostics.firstFatal.component==3);
}
