from pathlib import Path
import re,json,numpy as np
b=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017');t='1.1999999999999999e-06'
number=r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?'
def field(p):
 s=p.read_text();m=re.search(r'internalField\s+nonuniform\s+List<(scalar|vector)>\s+(\d+)\s*\((.*?)\)\s*;',s,re.S)
 if m:
  n=int(m[2]);v=np.array([float(x) for x in re.findall(number,m[3])]);assert len(v)==n*(3 if m[1]=='vector' else 1),(p,len(v),n);return v
 m=re.search(r'internalField\s+uniform\s+([^;]+);',s);return np.array([float(x) for x in re.findall(number,m[1])]) if m else None
out={}
for p in sorted((b/'runs/flatplate-main'/t).iterdir()):
 q=b/'runs/flatplate-original'/t/p.name
 if not q.is_file() or not p.is_file():continue
 a=field(p);c=field(q)
 if a is None:continue
 assert a.shape==c.shape
 delta=np.abs(a-c);scale=float(np.max(np.abs(a)))
 out[p.name]={'values':len(a),'finite':bool(np.isfinite(a).all() and np.isfinite(c).all()),'max_abs':float(delta.max()),'Linf_relative_to_main_max':float(delta.max()/scale) if scale else 0,'L2_relative':float(np.linalg.norm(a-c)/np.linalg.norm(a)) if np.linalg.norm(a) else 0,'main_min':float(a.min()),'main_max':float(a.max()),'pr_min':float(c.min()),'pr_max':float(c.max())}
(b/'normal-original-physical-fields.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

