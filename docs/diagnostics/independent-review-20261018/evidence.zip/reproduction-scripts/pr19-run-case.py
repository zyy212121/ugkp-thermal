import pathlib,shutil,re,subprocess,json,os,hashlib,time
base=pathlib.Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');e=base/'pr19-evidence-20261017';prod=pathlib.Path('/home/lss/arc3696-work/generic-wall-opt-20261017/runs/initial-baseline-1/case')
version=os.environ.get('REVIEW_VERSION','original');tree=base/('pr19-review-20261017' if version=='original' else 'pr19-main-20261017' if version=='main' else 'pr19-fixes-20261017');case=e/'runs'/('flatplate-'+version);case.mkdir(parents=True,exist_ok=False)
for d in ['0','constant','system']:shutil.copytree(prod/d,case/d)
env=os.environ.copy();env['GAS_UGKP_CUDA_BACKEND']=str(tree/'.review-install/bin/gasUGKPCudaBackend')
cmd=[str(tree/'.review-install/bin/gasUGKP'),'-case',str(case)]
with (case/'run.log').open('w') as log:
 t=time.monotonic();p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=120)
r={'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'sha':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [tree/'.review-install/bin/gasUGKP',tree/'.review-install/bin/gasUGKPCudaBackend']}}
(case/'result.json').write_text(json.dumps(r,indent=2));print(json.dumps(r));print((case/'run.log').read_text()[-6000:])
