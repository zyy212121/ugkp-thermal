from pathlib import Path
import shutil,subprocess,os,json,time
b=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');e=b/'pr19-evidence-20261017';r=b/'pr19-review-20261017'
c=e/'runs'/'missing-scheduled-original';c.mkdir()
for d in ['0','constant','system']:shutil.copytree(e/'runs/flatplate-original'/d,c/d)
p=c/'constant/schedulingProperties';p.write_text(p.read_text().replace('gpuResidentDynamicInlet false','gpuResidentDynamicInlet true'))
(c/'constant/inletPressure.table').write_text('((0 124094.11053558919)(1 124094.11053558919))\n')
(c/'constant/inletVolumeFraction.table').write_text('((0 0)(1 0))\n')
env=os.environ.copy();env['GAS_UGKP_CUDA_BACKEND']=str(r/'.review-install/bin/gasUGKPCudaBackend')
with (c/'run.log').open('w') as f:p=subprocess.run([str(r/'.review-install/bin/gasUGKP'),'-case',str(c)],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=120)
print('exit',p.returncode);print((c/'run.log').read_text()[-5000:])
