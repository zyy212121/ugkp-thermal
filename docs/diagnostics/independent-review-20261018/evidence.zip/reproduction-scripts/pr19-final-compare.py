from pathlib import Path
import json,hashlib
p=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017');t='1.1999999999999999e-06';a=p/'runs/flatplate-original'/t;b=p/'runs/final-normal-on'/t
rows=[]
for f in a.rglob('*'):
 if f.is_file():
  rel=f.relative_to(a);rows.append({'file':str(rel),'equal':f.read_bytes()==(b/rel).read_bytes()})
(p/'original-final-output-comparison.json').write_text(json.dumps(rows,indent=2));print('equal',sum(x['equal'] for x in rows),'/',len(rows));print([x for x in rows if not x['equal']])
