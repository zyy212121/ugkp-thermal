from pathlib import Path
import sys,subprocess
b=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');r=b/'pr19-main-20261017';e=b/'pr19-evidence-20261017';sys.path[:0]=[str(r),str(r/'validation/tests/gas_transport')]
from test_mixture_transport import fixture
pre=(r/'validation/tests/gas_transport/gas_state_probe.cpp').read_text().split('void hashBytes')[0]
x=pre+fixture()+'\nint main(){State s;initialise(s);s.cellPlaneStart[0]=8;s.cellPlaneCount[0]=1;threadIdx.x=0;computeGasPrimitiveGradientsKernel(&s);}\n'
p=e/'stencil-main.cpp';p.write_text(x);exe=e/'stencil-main';subprocess.run(['g++','-std=c++17','-O0','-g','-fsanitize=address','-I'+str(r/'common'),'-I'+str(r/'common/gasNumerics'),'-I'+str(r/'validation/tests/gas_transport'),str(p),'-o',str(exe)],check=True)
p=subprocess.run([str(exe)],capture_output=True,text=True);(e/'stencil-main.log').write_text(p.stdout+p.stderr);print(p.returncode,p.stderr[:500])
