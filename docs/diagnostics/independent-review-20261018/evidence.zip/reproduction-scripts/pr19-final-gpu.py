from pathlib import Path
import shutil,subprocess,os,json,hashlib,time
b=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');e=b/'pr19-evidence-20261017';r=b/'pr19-fixes-20261017';source=e/'runs/flatplate-original'
gpu=subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True).strip()
if gpu:raise RuntimeError('GPU occupied; no test started: '+gpu)
results=[]
for mode in ['normal-on','normal-off','missing-on','missing-off']:
 c=e/'runs'/('final-'+mode);c.mkdir(exist_ok=False)
 for d in ['0','constant','system']:shutil.copytree(source/d,c/d)
 if mode.startswith('missing'):
  p=c/'constant/schedulingProperties';p.write_text(p.read_text().replace('gpuResidentDynamicInlet false','gpuResidentDynamicInlet true'))
  (c/'constant/inletPressure.table').write_text('((0 124094.11053558919)(1 124094.11053558919))\n')
  (c/'constant/inletVolumeFraction.table').write_text('((0 0)(1 0))\n')
 env=os.environ.copy();env['GAS_UGKP_CUDA_BACKEND']=str(r/'.review-install/bin/gasUGKPCudaBackend');env['UGKP_DIAGNOSTIC_WARNINGS']='0' if mode.endswith('off') else '1'
 cmd=[str(r/'.review-install/bin/gasUGKP'),'-case',str(c)]
 with (c/'run.log').open('w') as f:
  t=time.monotonic();p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=150)
 result={'mode':mode,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'binary_sha256':{n:hashlib.sha256((r/'.review-install/bin'/n).read_bytes()).hexdigest() for n in ['gasUGKP','gasUGKPCudaBackend']}}
 (c/'result.json').write_text(json.dumps(result,indent=2));results.append(result);print(json.dumps(result),flush=True)
 text=(c/'run.log').read_text()
 if mode.startswith('missing'):assert p.returncode!=0 and 'site=30420' in text and 'FOAM FATAL ERROR' in text
 else:assert p.returncode==0
outtime='1.1999999999999999e-06';a=e/'runs/final-normal-on'/outtime;z=e/'runs/final-normal-off'/outtime
diffs=[str(p.relative_to(a)) for p in a.rglob('*') if p.is_file() and p.read_bytes()!=(z/p.relative_to(a)).read_bytes()]
assert not diffs,diffs
(e/'gpu-final-results.json').write_text(json.dumps({'runs':results,'warning_toggle_output_differences':diffs},indent=2))

