source /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/env.sh
python3 /mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work/pr19-fault-case.py
