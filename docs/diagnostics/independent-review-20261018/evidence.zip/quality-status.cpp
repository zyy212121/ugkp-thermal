#include <cstdio>

#include "common/operators/advanceGasChemistryKernel.cuh"
#include <cassert>
#include <cmath>
#include <cstring>
#include <limits>
using namespace ugkwp;
using Real=double;
struct State:GasStateView<Real,double,int>{GasSpeciesState<Real,2> gasSpecies;};
struct Fixture {
 State state;ugkp::diagnostics::DeviceContext diagnostics{};
 Real rho[2]={Real(2),Real(4)},mx[2]={Real(6),Real(-4)},my[2]={Real(-2),Real(8)},mz[2]={Real(1),Real(2)};
 Real energy[2],volume[2]={Real(8),Real(16)},temperature[2]={Real(-77),Real(-88)};
 Real partial[4]={Real(1.5),Real(3),Real(.5),Real(1)};
 int cellStatus[2]={};ChemistryStatus chemistryStatus[2];
 SpeciesThermoData<Real> species[2];Real coefficients[6]={Real(1000),Real(0),Real(0),Real(1000),Real(0),Real(-1e5)};
 Real elements[2]={Real(1),Real(1)},basis[2]={Real(-1),Real(1)};
 GasReactionData<Real> reaction[1];GasStoichTerm<Real> reactants[1],products[1];
 Fixture(){
  state.diagnostics=&diagnostics;state.nCells=2;state.rho=rho;state.rhoUx=mx;state.rhoUy=my;state.rhoUz=mz;state.rhoE=energy;state.V=volume;state.Tgas=temperature;
  auto& g=state.gasSpecies;g.mode=GasMode::MixtureChemistry;g.rho=partial;g.cellStatus=cellStatus;g.chemistryStatus=chemistryStatus;
  for(int s=0;s<2;++s){species[s].coefficientOffset=3*s;species[s].molarMass=Real(.028);species[s].minTemperature=Real(200);species[s].maxTemperature=Real(4000);species[s].referencePressure=Real(101325);}
  g.thermo.species=species;g.thermo.coefficients=coefficients;g.thermo.coefficientCount=6;g.thermo.elementCount=1;g.thermo.elementComposition=elements;
  reaction[0].reactantCount=reaction[0].productCount=1;reaction[0].highRate.preExponential=Real(2);
  reactants[0].species=0;reactants[0].coefficient=Real(1);products[0].species=1;products[0].coefficient=Real(1);
  g.mechanism.reactions=reaction;g.mechanism.reactionCount=1;g.mechanism.reactants=reactants;g.mechanism.reactantTermCount=1;g.mechanism.products=products;g.mechanism.productTermCount=1;g.mechanism.stoichiometricBasis=basis;g.mechanism.independentRank=1;g.mechanism.referencePressure=Real(101325);

  for(int c=0;c<2;++c){Real masses[2]={partial[c],partial[2+c]};energy[c]=mixtureEnergy(masses,Real(700),g.thermo)+(mx[c]*mx[c]+my[c]*my[c]+mz[c]*mz[c])/(Real(2)*rho[c]);}
 }
};

int main(){
 Fixture f;auto& c=f.state.gasSpecies.chemistryControls;c.maximumSteps=0;c.maximumNewtonIterations=0;c.maximumLineSearchIterations=0;c.absoluteMassTolerance=0;c.absoluteElementTolerance=0;c.relativeConservationTolerance=0;c.thermo.relativeEnergyTolerance=0;c.thermo.absoluteEnergyTolerance=0;
 f.partial[2]+=.01;
 ClosedReactorInput<Real,2> input;input.volume=Real(.7);input.totalMass=f.rho[0]*input.volume;for(int i=0;i<2;++i)input.speciesMass[i]=f.partial[2*i]*input.volume;
 const Real ux=f.mx[0]/f.rho[0],uy=f.my[0]/f.rho[0],uz=f.mz[0]/f.rho[0];input.internalEnergy=(f.energy[0]-Real(.5)*f.rho[0]*(ux*ux+uy*uy+uz*uz))*input.volume;
 ClosedReactorResult<Real,2> expected;bool available=false;auto direct=advanceClosedReactor(input,.1,f.state.gasSpecies.thermo,f.state.gasSpecies.mechanism,c,expected,&available);printf("code=%d available=%d thermo=%d observed=%g\n",int(direct.code),available,int(direct.thermoCode),direct.observed);return 0;
 const Real savedEnergy=f.energy[0];auto st=advanceGasChemistryCell(f.state,0,.1,Real(.7));assert(st);assert(f.partial[0]<1.5);assert(f.energy[0]==savedEnergy);assert(f.cellStatus[0]==0);assert(f.partial[0]==expected.speciesMass[0]/input.volume&&f.partial[2]==expected.speciesMass[1]/input.volume);
 Fixture reference;assert(advanceGasChemistryCell(reference.state,0,.01,Real(.5)));
 Fixture stale;stale.cellStatus[0]=int(GasTransportCode::NegativeInventory);stale.chemistryStatus[0].code=ChemistryCode::ConservationFailure;
 // Real trial owners reset aggregate and chemistry statuses before a new trial.
 // Direct adapter success owns chemistryStatus, not other operators' aggregate.
 if(false){stale.cellStatus[0]=0;stale.chemistryStatus[0]=ChemistryStatus{};}
 const Real staleEnergy=stale.energy[0];assert(advanceGasChemistryCell(stale.state,0,.01,Real(.5)));
 assert(stale.cellStatus[0]==(false?0:int(GasTransportCode::NegativeInventory))&&stale.chemistryStatus[0]);
 assert(std::memcmp(stale.partial,reference.partial,sizeof stale.partial)==0);
 assert(stale.partial[0]<Real(1.5)&&stale.partial[2]>Real(.5));
 assert(std::abs(stale.partial[0]+stale.partial[2]-stale.rho[0])<Real(1e-12));
 assert(stale.energy[0]==staleEnergy&&stale.rho[0]==reference.rho[0]&&stale.mx[0]==reference.mx[0]&&stale.my[0]==reference.my[0]&&stale.mz[0]==reference.mz[0]);
 Fixture other;other.cellStatus[0]=int(GasTransportCode::InvalidStorage);assert(advanceGasChemistryCell(other.state,0,.01,Real(.5)));assert(other.partial[0]<Real(1.5));assert(other.cellStatus[0]==int(GasTransportCode::InvalidStorage));
 Fixture missing;missing.state.rhoE=nullptr;assert(!advanceGasChemistryCell(missing.state,0,.01,Real(.5)));assert(missing.partial[0]==Real(1.5)&&missing.partial[2]==Real(.5));assert(!missing.chemistryStatus[0]);
 Fixture tiny;tiny.reaction[0].highRate.preExponential=Real(1e30);st=advanceGasChemistryCell(tiny.state,0,1e-46,Real(.5));assert(st);assert(tiny.partial[0]==Real(1.5)&&tiny.partial[2]>=Real(0));assert(tiny.chemistryStatus[0]&&tiny.cellStatus[0]==0);
 Fixture zero;Real before[4];std::memcpy(before,zero.partial,sizeof before);st=advanceGasChemistryCell(zero.state,0,0.,Real(.7));assert(st);assert(std::memcmp(before,zero.partial,sizeof before)==0);
}
