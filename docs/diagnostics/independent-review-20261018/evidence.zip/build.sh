source "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-evidence-20261017/env.sh"
bash ./Allwmake
