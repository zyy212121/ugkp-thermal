from pathlib import Path
import subprocess,os,time,json,re,statistics,hashlib,csv,sys
import numpy as np
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');b=r/'work/pr22-native-cuda-20261021';o=b/'profile-source-face-20steps';source=b/'profile-2f4a66f-20steps';records=[]
sys.path.insert(0,str(r/'validation/cuda/wall_coupling'));from compare_case import field
assert len(json.loads((o/'builds.json').read_text()))==2 and all(v['exit']==0 for v in json.loads((o/'builds.json').read_text()))
for label in ['old','new']:
 rt=o/(label+'-runtime');case=o/(label+'-case');case.mkdir()
 import shutil
 for part in ['0','constant','system']:shutil.copytree(source/(label+'-case')/part,case/part)
 env=dict(os.environ,GAS_UGKP_CUDA_STACK_BYTES='131072',FOAM_SIGFPE='false')
 for key in ['UGKP_WALL_AUDIT_DIR','UGKP_GAS_BUDGET_OUTPUT']:env.pop(key,None)
 cmd=['bash','-c','ulimit -s 65536; exec bash "$@"','profile',str(r/'docs/diagnostics/bvp-coupling-20261020/run-case.sh'),str(rt),str(case)]
 print('RUN START',label,flush=True);start=time.monotonic()
 with (o/(label+'.log')).open('w')as log:rc=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
 text=(o/(label+'.log')).read_text();steps=re.findall(r'UGKP_REPRO step=(\d+)',text);assert rc==0 and steps==[str(i)for i in range(1,21)] and 'nodes=24' in text
 pattern=r'UGKP_PHASE slot=(\d+) setupFitNs=(\d+) sourceMeanNs=(\d+) faceNs=(\d+) totalNs=(\d+)';calls={};allrows=[]
 for match in re.finditer(pattern,text):
  slot,fit,sourceTime,face,total=map(int,match.groups());seq=len(calls.setdefault(slot,[]));row=dict(slot=slot,call=seq+1,step=seq//2+1,stage=seq%2+1,setupFitNs=fit,sourceMeanNs=sourceTime,faceNs=face,totalNs=total,sourceFaceNs=sourceTime+face);assert fit+sourceTime+face==total;calls[slot].append(row);allrows.append(row)
 assert len(calls)==336 and all(len(v)==40 for v in calls.values()),[(k,len(v))for k,v in calls.items()]
 chosen=[row for row in allrows if 3<=row['step']<=19];assert len(chosen)==336*34
 stats={key:dict(count=len(chosen),sum_ns=sum(row[key]for row in chosen),mean_ns=statistics.mean(row[key]for row in chosen),median_ns=statistics.median(row[key]for row in chosen))for key in ['setupFitNs','sourceMeanNs','faceNs','sourceFaceNs','totalNs']}
 fieldstats={}
 terminalDir=lambda root:max((p for p in root.iterdir() if p.is_dir() and re.fullmatch('[0-9eE.+-]+',p.name)),key=lambda p:float(p.name))
 ownref=terminalDir(source/(label+'-case'));terminal=terminalDir(case);assert abs(float(terminal.name)-4e-6)<1e-18
 for name in ['rho','rhoE','p','T','U','rhoU','k','omega','rhoY_Air','rhoY_CO2']:
  f=field(terminal/name,name in ['U','rhoU']);ref=field(ownref/name,name in ['U','rhoU']);assert np.isfinite(f).all();mx=float(np.max(np.abs(f-ref)/np.maximum(1.,np.abs(ref))));fieldstats[name]=mx;assert mx<=1e-5,(label,name,mx)
 row=dict(label=label,command=cmd,exit=rc,elapsed_s=time.monotonic()-start,steps=steps,total_phase_records=len(allrows),selected_records=len(chosen),range='physical steps3..19; all336walls; bothRKstages',stats=stats,own_uninstrumented_field_diff=fieldstats,binary_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in (rt/'bin').iterdir()if f.is_file()})
 with (o/(label+'-phases.csv')).open('w')as f:w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
 records.append(row);(o/'runs.json').write_text(json.dumps(records,indent=2));print('RUN END',label,json.dumps(row),flush=True)
summary=dict(runs=records,new_over_old={key:records[1]['stats'][key]['sum_ns']/records[0]['stats'][key]['sum_ns']for key in records[0]['stats']},scope='Diagnostic globaltimer elapsed nanoseconds per wall warp invocation, not additive application or GPU kernel wall time. Identical3timing partitions andprintf instrumentation in isolatedsource; no numerical production source changes; pureAir/noBlow24nodes20steps.')
(o/'summary.json').write_text(json.dumps(summary,indent=2));print('SUMMARY',json.dumps(summary['new_over_old']),flush=True)

