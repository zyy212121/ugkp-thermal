from pathlib import Path
import subprocess,shutil,os,time,json,hashlib,difflib
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');base=r/'work/pr22-native-cuda-20261021';o=base/'profile-source-face-20steps';o.mkdir(exist_ok=True);records=[]
for label,pin,source,runtime in [('old','2f4a66f82c8405fad65542490c4d88841b2b9cd4',base/'baseline-efficiency/old-source',base/'baseline-efficiency/old-runtime'),('new','21c6397d7a9981048c193c749ab30abc5ca96c45',r,base/'runtime')]:
 root=o/(label+'-source');assert not root.exists();root.mkdir()
 files=subprocess.check_output(['git','ls-tree','-r','--name-only',pin,'--','common','applications/gasUGKP'],cwd=r,text=True).splitlines();hashes={}
 for name in files:
  p=root/name;p.parent.mkdir(exist_ok=True,parents=True);data=(source/name).read_bytes();p.write_bytes(data);hashes[name]=hashlib.sha256(data).hexdigest()
 target=root/'common/gasTransport/GasConservativeWall.H';s=target.read_text();before=s
 def timer(name):return '\n#if defined(__CUDA_ARCH__)\n  unsigned long long '+name+';\n  asm volatile("mov.u64 %0, %%globaltimer;" : "=l"('+name+') :: "memory");\n#endif\n'
 needle='  const auto &col = data.columns[slot];';assert s.count(needle)==1;s=s.replace(needle,needle+'\n  team.sync();'+timer('ugkpPhase0'))
 needle='  if (team.leader())\n    data.active[slot] = 1;';assert s.count(needle)==1;s=s.replace(needle,'  team.sync();'+timer('ugkpPhase1')+needle)
 needle='  for (int j = team.rank(); j < 3; j += team.size()) {';assert s.count(needle)==1;s=s.replace(needle,'  team.sync();'+timer('ugkpPhase2')+needle)
 needle='  team.sync();\n}\n} // namespace ugkwp';assert s.count(needle)==1;s=s.replace(needle,'  team.sync();'+timer('ugkpPhase3')+'\n#if defined(__CUDA_ARCH__)\n  if(team.leader()) printf("UGKP_PHASE slot=%d setupFitNs=%llu sourceMeanNs=%llu faceNs=%llu totalNs=%llu\\n",slot,ugkpPhase1-ugkpPhase0,ugkpPhase2-ugkpPhase1,ugkpPhase3-ugkpPhase2,ugkpPhase3-ugkpPhase0);\n#endif\n}\n} // namespace ugkwp')
 target.write_text(s);(o/(label+'-instrumentation.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/common/gasTransport/GasConservativeWall.H',tofile='b/common/gasTransport/GasConservativeWall.H')))
 rt=o/(label+'-runtime')
 for sub in ['bin','lib','tmp','cuda-cache']:(rt/sub).mkdir(parents=True,exist_ok=True)
 shutil.copy2(runtime/'bin/gasUGKP',rt/'bin/gasUGKP')
 solver=root/'applications/gasUGKP';private=solver/'private_backend';obj=o/(label+'-backend.o');lib=o/(label+'-backend.a');cuda=Path('/usr/local/cuda')
 nvcc=[str(cuda/'bin/nvcc'),'-std=c++17','--expt-relaxed-constexpr','-DUGKWP_GAS_SPECIES=2','-O3','--fmad=false','-arch=sm_89','-Xcompiler','-fPIC','-Ofc=mid','-Xptxas=-v','-I'+str(solver/'gpu'),'-I'+str(root/'common'),'-c',str(private/'GpuResidentStrict.cu'),'-o',str(obj)]
 commands=[nvcc,['ar','rcs',str(lib),str(obj)],['c++','-std=c++17','-O3','-I'+str(solver/'gpu'),'-I'+str(root/'common'),str(private/'GpuBackendServer.C'),str(lib),'-L'+str(cuda/'lib64'),'-Wl,-rpath,'+str(cuda/'lib64'),'-lcudart','-o',str(rt/'bin/gasUGKPCudaBackend')]]
 print('BUILD START',label,flush=True);start=time.monotonic();env=dict(os.environ);env.pop('NVCC_APPEND_FLAGS',None)
 with (o/(label+'-build.log')).open('w')as log:
  for cmd in commands:
   rc=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
   if rc:break
 record=dict(label=label,source_pin=pin,commands=commands,exit=rc,elapsed_s=time.monotonic()-start,copied_source_sha256=hashes,only_instrumented_file='common/gasTransport/GasConservativeWall.H');records.append(record);(o/'builds.json').write_text(json.dumps(records,indent=2));print('BUILD END',label,rc,record['elapsed_s'],flush=True)
 if rc:print((o/(label+'-build.log')).read_text()[-8000:],flush=True);raise SystemExit(rc)
print('BOTH BUILDS COMPLETE',flush=True)
