from pathlib import Path
import subprocess,shutil,os,json,time
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');b=r/'work/pr22-native-cuda-20261021';o=b/'profile-2f4a66f-20steps';records=[]
for label,runtime in [('old',b/'baseline-efficiency/old-runtime'),('new',b/'runtime')]:
 (runtime/'tmp').mkdir(exist_ok=True)
 case=o/(label+'-ncu-case');case.mkdir(exist_ok=True)
 if (o/(label+'-ncu.log')).exists():(o/(label+'-ncu.log')).rename(o/(label+'-ncu-first-attempt.log'))
 for part in ['0','constant','system']:shutil.copytree(o/(label+'-case')/part,case/part,dirs_exist_ok=True)
 env=dict(os.environ,GAS_UGKP_CUDA_STACK_BYTES='131072',FOAM_SIGFPE='false')
 for key in ['UGKP_WALL_AUDIT_DIR','UGKP_GAS_BUDGET_OUTPUT']:env.pop(key,None)
 cmd=['/usr/local/cuda/bin/ncu','--target-processes','all','--target-processes-filter','gasUGKPCudaBackend','--kernel-name-base','function','--kernel-id','::evaluateGasBoundaryLayerTeamKernel:7','--launch-count','1','--clock-control','none','--section','SpeedOfLight','--section','Occupancy','--section','SchedulerStats','--section','WarpStateStats','--section','MemoryWorkloadAnalysis','--section','SourceCounters','--force-overwrite','--export',str(o/(label+'-bvp')),'bash','-c','ulimit -s 65536; exec bash "$@"','profile',str(r/'docs/diagnostics/bvp-coupling-20261020/run-case.sh'),str(runtime),str(case)]
 print('START NCU',label,flush=True);start=time.monotonic()
 with (o/(label+'-ncu.log')).open('w') as f:p=subprocess.Popen(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT);rc=p.wait()
 log=(o/(label+'-ncu.log')).read_text();record=dict(label=label,command=cmd,exit=rc,elapsed_s=time.monotonic()-start);records.append(record);(o/'ncu-runs.json').write_text(json.dumps(records,indent=2));print('END NCU',label,rc,record['elapsed_s'],flush=True)
 if rc or 'ERR_' in log:print(log[-8000:],flush=True);break
 p=subprocess.run(['/usr/local/cuda/bin/ncu','--import',str(o/(label+'-bvp.ncu-rep')),'--page','details','--csv'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/(label+'-bvp.csv')).write_text(p.stdout)
 print(p.stdout[:1500],flush=True)

