from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,re
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');base=r/'work/pr22-native-cuda-20261021';prior=base/'efficiency-2f4a66f-20steps';out=base/'profile-2f4a66f-20steps';out.mkdir(exist_ok=True)
records=json.loads((out/'runs.json').read_text()) if (out/'runs.json').exists() else []
oldhash=records[0]['input_sha256'] if records else None
for label,runtime in [('old',base/'baseline-efficiency/old-runtime'),('new',base/'runtime')]:
 if label not in [v['label'] for v in records]:
  case=out/(label+'-case');case.mkdir(exist_ok=True)
  for part in ['0','constant','system']:
   assert not (case/part).exists(), 'Refuse overwrite profile inputs'
   shutil.copytree(prior/(label+'-case')/part,case/part)
  hashes={str(p.relative_to(case)):hashlib.sha256(p.read_bytes()).hexdigest() for part in ['0','constant','system'] for p in (case/part).rglob('*') if p.is_file()}
  if label=='old':oldhash=hashes
  else:assert hashes==oldhash
  env=dict(os.environ,GAS_UGKP_CUDA_STACK_BYTES='131072',FOAM_SIGFPE='false')
  for key in ['UGKP_WALL_AUDIT_DIR','UGKP_GAS_BUDGET_OUTPUT']:env.pop(key,None)
  cmd=['/usr/local/bin/nsys','profile','--trace=cuda,nvtx,osrt','--sample=none','--cpuctxsw=none','--wait=all','--force-overwrite=true','--export=sqlite','--output='+str(out/label),'bash','-c','ulimit -s 65536; exec bash "$@"','profile',str(r/'docs/diagnostics/bvp-coupling-20261020/run-case.sh'),str(runtime),str(case)]
  print('START',label,flush=True);start=time.monotonic()
  with (out/(label+'.log')).open('w') as log:
   p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
   (out/'active-process.json').write_text(json.dumps(dict(label=label,pid=p.pid,command=cmd)))
   rc=p.wait()
  logtext=(out/(label+'.log')).read_text();steps=re.findall(r'UGKP_REPRO step=(\d+)',logtext)
  record=dict(label=label,command=cmd,exit=rc,elapsed_seconds=time.monotonic()-start,steps=steps,reactingSst24=('wallTreatment=boundaryLayer' in logtext and 'nodes=24' in logtext),input_sha256=hashes,binary_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (runtime/'bin').iterdir() if p.is_file()})
  records.append(record);(out/'runs.json').write_text(json.dumps(records,indent=2));print('END',label,rc,record['elapsed_seconds'],'STEPS',len(steps),flush=True)
  assert rc==0 and steps==[str(i)for i in range(1,21)] and record['reactingSst24']
 for report in ['cuda_gpu_kern_sum:base','cuda_api_sum','cuda_gpu_mem_time_sum','cuda_gpu_mem_size_sum','osrt_sum','cuda_kern_exec_sum:base']:
  name=report.split(':')[0]
  p=subprocess.run(['/usr/local/bin/nsys','stats','--report',report,'--format','csv','--output',str(out/(label+'-'+name)),str(out/(label+'.sqlite'))],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (out/(label+'-'+name+'-export.log')).write_text(p.stdout);assert p.returncode==0,p.stdout
(out/'active-process.json').unlink(missing_ok=True)
print('COMPLETE',out,flush=True)

