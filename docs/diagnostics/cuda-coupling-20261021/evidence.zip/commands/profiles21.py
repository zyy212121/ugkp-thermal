from pathlib import Path
import sys,numpy as np,csv,re,json
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');O=R/'work/cuda-coupling-20261021';sys.path.insert(0,str(R/'validation/cuda/wall_coupling'));from compare_case import field
I=O/'review-input/complete-coupling/twod/input-exactR';x=np.fromfile(I/'Cx.bin');y=np.fromfile(I/'Cy.bin');rows=[];stations=[]
for label,case,audit in [('old','paired-baseline-50us',None),('cuda','final-24-50us','final-24-50us-audit'),('half','final-half-50us','final-half-50us-audit')]:
 c=O/case;t=max((p for p in c.iterdir() if p.is_dir() and re.fullmatch('[0-9eE.+-]+',p.name)),key=lambda p:float(p.name));data={k:field(t/k,k=='U') for k in ['U','T','rho','p','k','omega']}
 wallfile=O/audit/'wall-work.csv' if audit else t/'uniform/gasBoundaryLayer.csv';walls={int(a['owner']):a for a in csv.DictReader(wallfile.open())}
 for idx,owner in enumerate([90,7684,7782,7864,23080]):
  col=np.flatnonzero(abs(x-x[owner])<1e-9);col=col[np.argsort(y[col])]
  for cell in col:
   row={'variant':label,'station':idx+1,'cell':int(cell),'x':x[cell],'y':y[cell],**{k:float(v[cell,0] if k=='U' else v[cell])for k,v in data.items()}}
   rows.append(row)
   if cell==owner:stations.append(dict(row,tau=float(walls[cell]['tractionX'])))
for name,data in [('profiles.csv',rows),('stations.csv',stations)]:
 with (O/name).open('w')as f:w=csv.DictWriter(f,fieldnames=data[0],lineterminator='\n');w.writeheader();w.writerows(data)
print(json.dumps(stations,indent=2))

