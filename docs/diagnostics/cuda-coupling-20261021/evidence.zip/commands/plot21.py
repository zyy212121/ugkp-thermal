from pathlib import Path
import csv,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');O=R/'work/cuda-coupling-20261021';D=R/'docs/diagnostics/cuda-coupling-20261021';data=list(csv.DictReader((D/'profiles.csv').open()));B=O/'review-input/complete-coupling/twod/mass-consistent50us';cp={k:np.fromfile(B/(f+'.bin'))for k,f in [('U','Ux'),('k','k'),('omega','omega')]}
fig,axs=plt.subplots(3,5,figsize=(15,9),sharey=True)
for j in range(5):
 rows=[r for r in data if int(r['station'])==j+1 and r['variant']=='cuda'];xx=float(rows[0]['x'])
 for i,key in enumerate(['U','k','omega']):
  ax=axs[i,j]
  for variant,color,style,label in [('old','#697386','-','Previous PR22'),('cuda','#1565c0','-','CUDA coupled'),('half','#e68523','--','CUDA half dt')]:
   rows=[r for r in data if int(r['station'])==j+1 and r['variant']==variant];ax.plot([float(r[key])/(1e5 if key=='omega'else 1)for r in rows],[float(r['y'])*1000 for r in rows],color=color,ls=style,label=label,lw=1.5)
  ax.plot([cp[key][int(r['cell'])]/(1e5 if key=='omega'else 1)for r in rows],[float(r['y'])*1000 for r in rows],color='#252525',ls=':',lw=1,label='Delivered CPU')
  ax.set_yscale('log');ax.set_ylim(.1,10);ax.grid(alpha=.2);ax.set_xlabel({'U':'U (m/s)','k':'k (m²/s²)','omega':'omega (10⁵ s⁻¹)'}[key]);
  if j==0:ax.set_ylabel('Wall distance (mm)')
  if i==0:ax.set_title(f'x = {xx:.3f} m')
handles,labels=axs[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=4,bbox_to_anchor=(.5,.97));fig.suptitle('Same input, t = 50 µs: five near-wall profiles (transient)',y=1.0);fig.tight_layout(rect=[0,0,1,.93]);fig.savefig(D/'five-station-profiles.png',dpi=160,bbox_inches='tight')
