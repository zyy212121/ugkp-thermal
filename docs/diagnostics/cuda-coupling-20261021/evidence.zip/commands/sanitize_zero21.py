from pathlib import Path
import subprocess,time,json
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');O=R/'work/cuda-coupling-20261021';runs=[]
for tool in ['memcheck','racecheck','synccheck']:
 t=time.monotonic();cmd=['/usr/local/cuda-13.1/bin/compute-sanitizer','--tool',tool,'--error-exitcode','99',str(O/'profile-zero')]
 p=subprocess.run(cmd,capture_output=True,text=True);(O/('profile-zero-'+tool+'.log')).write_text(p.stdout+p.stderr);runs.append(dict(tool=tool,exit=p.returncode,seconds=time.monotonic()-t));print(runs[-1],flush=True);p.check_returncode()
(O/'profile-zero-sanitizers.json').write_text(json.dumps(runs,indent=2))
