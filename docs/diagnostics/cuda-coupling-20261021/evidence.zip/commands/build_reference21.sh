source /opt/openfoam10/etc/bashrc
set -eo pipefail
r=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018
o="$r/work/cuda-coupling-20261021"
export FOAM_USER_APPBIN="$o/bin" FOAM_USER_LIBBIN="$o/lib" CUDA_CACHE_PATH="$o/cuda-cache" TMPDIR="$o/tmp"
export CUDA_HOME=/usr/local/cuda-13.1 UGKWP_CUDA_ARCH=sm_89 UGKWP_GAS_SPECIES=2 GAS_UGKP_FMAD=1 UGKP_DEVELOPMENT_PROBES=0
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
cd "$r"
bash tool/gasUGKP/build_private_backend.sh > "$o/build.log" 2>&1
