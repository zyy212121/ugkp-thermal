from pathlib import Path
import subprocess, json, hashlib,sys
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');O=R/'work/cuda-coupling-20261021';P=R/'validation/cuda/wall_coupling';B=O/'review-input/complete-coupling/twod'
manifest=json.loads((O/'final-build-source.json').read_text())
assert all(hashlib.sha256((R/f).read_bytes()).hexdigest()==h for f,h in manifest.items())
for name,cpu in [('final-24-4us','delivery24-regression'),('final-128-4us','delivery128-regression'),('final-24-50us','mass-consistent50us'),('final-half-50us','mass-consistent-halfdt50us'),('final-euler',None)]:
 print('RUN '+name,flush=True)
 subprocess.run(['python3',str(P/'run_case.py'),'--case',str(O/name),'--runtime',str(O),'--output',str(O/(name+'-audit'))],check=True)
 if cpu:
  with (O/(name+'-compare.stdout')).open('w') as f:subprocess.run(['python3',str(P/'compare_case.py'),'--case',str(O/name),'--cpu',str(B/cpu),'--audit',str(O/(name+'-audit')),'--output',str(O/(name+'-comparison.json'))],stdout=f,check=True)
  x=json.loads((O/(name+'-comparison.json')).read_text());print(json.dumps({'case':name,'work':x['work'],'fields':x['fields']}),flush=True)
subprocess.run(['python3',str(P/'audit_euler.py'),'--case',str(O/'final-euler'),'--input',str(B/'input-exactR'),'--audit',str(O/'final-euler-audit'),'--dt','2e-7','--output',str(O/'final-euler-budget.json')],check=True)
for tool in ['memcheck','racecheck','synccheck']:
 print('SANITIZE '+tool,flush=True)
 subprocess.run(['python3',str(P/'run_case.py'),'--case',str(O/'final-sanitize'),'--runtime',str(O),'--output',str(O/('application-'+tool)),'--sanitize',tool],check=True)
print('DONE',flush=True)
