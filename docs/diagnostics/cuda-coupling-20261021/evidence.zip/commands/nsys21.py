from pathlib import Path
import os,subprocess,json,time
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018');O=R/'work/cuda-coupling-20261021';D=O/'nsys';D.mkdir(exist_ok=True)
env=dict(os.environ,UGKP_WALL_AUDIT_DIR=str(D));runs=[]
cmd=['/usr/local/cuda/bin/nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--force-overwrite=true','-o',str(D/'profile'),'bash',str(R/'docs/diagnostics/bvp-coupling-20261020/run-case.sh'),str(O),str(O/'final-24-4us')]
for name,c in [('profile',cmd),('stats',['/usr/local/cuda/bin/nsys','stats','--report','cuda_gpu_kern_sum,cuda_gpu_mem_time_sum,cuda_gpu_trace','--format','csv','--output',str(D/'stats'),str(D/'profile.nsys-rep')])]:
 t=time.monotonic();p=subprocess.run(c,env=env,capture_output=True,text=True);(D/(name+'.log')).write_text(p.stdout+p.stderr);runs.append(dict(command=c,exit=p.returncode,seconds=time.monotonic()-t));print(runs[-1],flush=True);p.check_returncode()
(D/'commands.json').write_text(json.dumps(runs,indent=2))
