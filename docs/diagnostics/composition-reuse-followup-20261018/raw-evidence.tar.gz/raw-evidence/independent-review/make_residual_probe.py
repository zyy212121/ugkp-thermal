from pathlib import Path
import subprocess
repo=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018')
root=Path('/mnt/d/tempt/ugkp-pr19-composition-reuse-20261018/independent-review')
old=subprocess.check_output(['git','show','d02a96ce86858b64e5a5dba676891798152addee:applications/CHMT/ablation/InterfaceMath.H'],cwd=repo,text=True)
start=old.index('template<bool Report>\nCHMT_HD inline bool compositionResidualPolicy(')
end=old.index('CHMT_HD inline bool compositionResidual(',start)
legacy=old[start:end].replace('compositionResidualPolicy','legacyResidualPolicy')
harness=r'''
#include "ablation/InterfaceMath.H"
#include <fenv.h>
#include <random>
#include <cstdio>
#include <cstring>
#include <cstdlib>
namespace chmt {
LEGACY
}
using namespace chmt;
int main() {
 feenableexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW);
 std::mt19937_64 rng(798251);std::uniform_real_distribution<Real> u(0,1);
 unsigned successes=0,typedFailures=0;
 for(int trial=0;trial<10000;++trial) {
  PhysicsConfig p; Real bulk[Ns],Y[Ns],Js[Ns],sb=0,sy=0;
  for(int i=0;i<Ns;++i) {
   p.species[i].R=std::pow(10.,-300+600*u(rng));
   p.gasDiffusivity[i]=trial%9?std::pow(10.,-300+600*u(rng)):0;
   bulk[i]=u(rng);Y[i]=u(rng);sb+=bulk[i];sy+=Y[i];
   Js[i]=std::pow(10.,-100+200*u(rng))*(u(rng)-.5);
  }
  for(int i=0;i<Ns;++i){bulk[i]/=sb;Y[i]/=sy;}
  const Real pressure=std::pow(10.,-300+600*u(rng)),T=std::pow(10.,-300+600*u(rng)),distance=std::pow(10.,-300+600*u(rng));
  CompositionResidualInputs fixed;
  if(!prepareCompositionResidual<false>(bulk,Js,p,fixed))return 4;
  Real f0[Ns]{},f1[Ns]{},jac0[Ns*Ns]{},jac1[Ns*Ns]{};
  const bool before=legacyResidualPolicy<false>(Y,bulk,Js,pressure,T,distance,p,f0,jac0);
  const bool after=compositionResidualPolicy<false>(Y,bulk,Js,pressure,T,distance,p,f1,jac1,&fixed);
  if(before!=after || (before&&(std::memcmp(f0,f1,sizeof f0)||std::memcmp(jac0,jac1,sizeof jac0)))) {
   std::printf("FAIL: trial %d success %d/%d\n",trial,before,after);return 2;
  }
  if(before)++successes;else ++typedFailures;
 }
 if(std::fetestexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW))return 3;
 std::printf("PASS: 10000 BASE-vs-HEAD residual/Jacobian comparisons at Ns=%d; %u exact successes; %u identical typed failures; traps clear\n",Ns,successes,typedFailures);
}
'''
(root/'residual_probe.cpp').write_text(harness.replace('LEGACY',legacy))