
#include "ablation/InterfaceMath.H"
#include <fenv.h>
#include <random>
#include <cstdio>
#include <cstring>
#include <cstdlib>
namespace chmt {
template<bool Report>
CHMT_HD inline bool legacyResidualPolicy(const Real* Y,const Real* bulk,const Real* Js,
    Real pressure,Real T,Real distance,const PhysicsConfig& p,Real* residual,Real* jacobian) {
    using namespace composition_detail;
    Real gasR[Ns]{},R=0,J=0,S=0,a[Ns]{},difference[Ns]{};
    for(int i=0;i<Ns;++i){
        gasR[i]=p.species[i].R;
        if(!finite(Y[i]))return compositionInputFailure<Report>(p,Y[i],i);
        if(!finite(bulk[i]))return compositionInputFailure<Report>(p,bulk[i],i);
        if(!finite(Js[i]))return compositionInputFailure<Report>(p,Js[i],i);
        if(!finite(gasR[i])||gasR[i]<=0)return compositionInputFailure<Report>(p,gasR[i],i);
        if(!finite(p.gasDiffusivity[i])||p.gasDiffusivity[i]<0)
            return compositionInputFailure<Report>(p,p.gasDiffusivity[i],i);
    }
    if(!scaledSum(gasR,Y,R)||!scaledSum(Js,nullptr,J))
        return compositionArithmeticFailure<Report>(p,HUGE_VAL,-1);
    const Real denominators[]={R,pressure,T,distance};
    for(int component=0;component<4;++component)
        if(!finite(denominators[component])||!(denominators[component]>0))
            return compositionInputFailure<Report>(p,denominators[component],component);
    for(int i=0;i<Ns;++i){
        // Evaluate rho*D/distance without an overflowing intermediate product.
        if(!diffusionScale(pressure,p.gasDiffusivity[i],T,distance,R,a[i])
            ||!sumFinite(Y[i],-bulk[i],difference[i]))
            return compositionArithmeticFailure<Report>(p,HUGE_VAL,i);
        Real term=0;
        if(!productFinite(a[i],difference[i],term)||!sumFinite(S,term,S))
            return compositionArithmeticFailure<Report>(p,HUGE_VAL,i);
    }
    for(int i=0;i<Ns;++i){
        Real first=0,second=0,diffusion=0,advective=0,value=0;
        if(!productFinite(a[i],difference[i],first)||!productFinite(Y[i],S,second)
            ||!sumFinite(first,-second,diffusion)||!productFinite(J,Y[i],advective)
            ||!sumFinite(advective,diffusion,value)||!sumFinite(value,-Js[i],residual[i]))
            return compositionArithmeticFailure<Report>(p,HUGE_VAL,i);
        if(jacobian)for(int j=0;j<Ns;++j){
            Real diagonal=0,off=0,ratio=0,thermo=0;
            if(i==j && (!sumFinite(J,a[i],diagonal)||!sumFinite(diagonal,-S,diagonal)))
                return compositionArithmeticFailure<Report>(p,HUGE_VAL,i);
            bool thermoFinite=productFinite(diffusion,gasR[j],thermo)&&quotientFinite(thermo,R,thermo);
            if(!thermoFinite)thermoFinite=quotientFinite(gasR[j],R,ratio)&&productFinite(diffusion,ratio,thermo);
            if(!productFinite(Y[i],a[j],off)||!thermoFinite||!sumFinite(diagonal,-off,value)
                ||!sumFinite(value,-thermo,jacobian[i*Ns+j]))
                return compositionArithmeticFailure<Report>(p,HUGE_VAL,i);
        }
    }
    return true;
}

}
using namespace chmt;
int main() {
 feenableexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW);
 std::mt19937_64 rng(798251);std::uniform_real_distribution<Real> u(0,1);
 unsigned successes=0,typedFailures=0;
 for(int trial=0;trial<10000;++trial) {
  PhysicsConfig p; Real bulk[Ns],Y[Ns],Js[Ns],sb=0,sy=0;
  for(int i=0;i<Ns;++i) {
   p.species[i].R=std::pow(10.,-300+600*u(rng));
   p.gasDiffusivity[i]=trial%9?std::pow(10.,-300+600*u(rng)):0;
   bulk[i]=u(rng);Y[i]=u(rng);sb+=bulk[i];sy+=Y[i];
   Js[i]=std::pow(10.,-100+200*u(rng))*(u(rng)-.5);
  }
  for(int i=0;i<Ns;++i){bulk[i]/=sb;Y[i]/=sy;}
  const Real pressure=std::pow(10.,-300+600*u(rng)),T=std::pow(10.,-300+600*u(rng)),distance=std::pow(10.,-300+600*u(rng));
  CompositionResidualInputs fixed;
  if(!prepareCompositionResidual<false>(bulk,Js,p,fixed))return 4;
  Real f0[Ns]{},f1[Ns]{},jac0[Ns*Ns]{},jac1[Ns*Ns]{};
  const bool before=legacyResidualPolicy<false>(Y,bulk,Js,pressure,T,distance,p,f0,jac0);
  const bool after=compositionResidualPolicy<false>(Y,bulk,Js,pressure,T,distance,p,f1,jac1,&fixed);
  if(before!=after || (before&&(std::memcmp(f0,f1,sizeof f0)||std::memcmp(jac0,jac1,sizeof jac0)))) {
   std::printf("FAIL: trial %d success %d/%d\n",trial,before,after);return 2;
  }
  if(before)++successes;else ++typedFailures;
 }
 if(std::fetestexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW))return 3;
 std::printf("PASS: 10000 BASE-vs-HEAD residual/Jacobian comparisons at Ns=%d; %u exact successes; %u identical typed failures; traps clear\n",Ns,successes,typedFailures);
}
