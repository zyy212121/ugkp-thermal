#include "ablation/InterfaceMath.H"
#include <fenv.h>
#include <random>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cstdlib>
using namespace chmt;
static double positive(std::mt19937_64& rng) {
    uint64_t raw;
    do { raw=rng()&UINT64_C(0x7fffffffffffffff); } while (raw==0 || (raw>>52)==2047);
    double out;std::memcpy(&out,&raw,sizeof out);return out;
}
int main() {
    feenableexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW);
    std::mt19937_64 rng(91269719);
    unsigned count=0,failed=0,zero=0;
    for(int trial=0;trial<30000;++trial) {
        const double pressure=positive(rng),T=positive(rng),distance=positive(rng),R=positive(rng);
        composition_detail::DiffusionState state(pressure,T,distance,R);
        double values[]={0,4.9406564584124654e-324,2.2250738585072014e-308,1,1.7976931348623157e308,positive(rng),positive(rng)};
        for(double D:values) {
            double old=42,now=42;
            bool a=composition_detail::diffusionScale(pressure,D,T,distance,R,old);
            bool b=state.scale(D,now);
            ++count;
            if(!a)++failed;
            if(a&&old==0)++zero;
            if(a!=b || (a&&std::memcmp(&old,&now,sizeof old))) {
                std::printf("FAIL trial=%d p=%a T=%a distance=%a R=%a D=%a old=%a new=%a success=%d/%d\n",trial,pressure,T,distance,R,D,old,now,a,b);return 2;
            }
        }
    }
    if(std::fetestexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW))return 3;
    std::printf("PASS: %u diffusion comparisons; %u typed range failures; %u represented zeros; FE_INVALID/DIVBYZERO/OVERFLOW remain clear\n",count,failed,zero);
}