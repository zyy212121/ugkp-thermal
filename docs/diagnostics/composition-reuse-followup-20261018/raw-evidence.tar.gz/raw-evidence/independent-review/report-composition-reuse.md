# Independent numerical review: composition certificate and preparation reuse

Reviewed range: `d02a96ce86858b64e5a5dba676891798152addee..ca421b47f9a545934c75686fd76527b9d17e6b7f`.
Repository: `/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018`.
Reviewer scope: all eight changed files; selected-certificate identity, preparation consistency/lifetime, validation and diagnostics, arithmetic order, diffusion degeneracy/extreme range, and instrumentation claims. Review performed read-only. No repository source, index, HEAD, production case, or production GPU changes/tasks. Only isolated probes/report in this directory and compiler temporaries under the explicitly authorized repository `.review-tmp/reuse-review` directory were created.

## Issues, sorted by severity

### Critical

None found.

### Important

None found.

### Minor — the diffusion instrumentation does not observe the new EOS work

Location: `validation/tests/fixtures/interface_composition/publication.cpp:12` and `:35` (implementation being tested: `applications/CHMT/ablation/InterfaceCompositionArithmetic.H:70`).

`fullDiffusionPreparations` counts entries to `diffusionScale`. The normal successful `DiffusionState::scale` path computes the EOS prefix itself and returns without calling `diffusionScale`. Consequently the counter is normally zero and the `<=Ns` assertion does not detect repeated new EOS preparation. For example, constructing a fresh DiffusionState for every species would repeat that work and still pass this check. This is a coverage/measurement gap; source inspection confirms that HEAD actually constructs one DiffusionState outside each species loop.

Suggested fix: describe the counter narrowly as a fallback counter, and, if the test must prove EOS sharing, measure the shared EOS preparation itself (for example via an instrumentable helper and a known number of candidate evaluations). Keep the parent-owned controlled timing/build checks as independent evidence of the intended performance result. This minor issue does not establish a runtime correctness regression. The parent has accepted it and plans a test-only increment: label the existing count as fallback entries and count actual quotientFinite entries in the initial-certified zero-flux mode, where exactly Ns+1 divisions are expected (one EOS division plus Ns diffusion-distance divisions). That increment is pending and is outside the reviewed HEAD above.

## Assessment of the implementation

- `InterfaceComposition.H:376-392` certifies the original equations and copies the exact candidate and its residual norm into the same Selection update. Selection ranking is unchanged: convergence class, then nearest-bulk distance for converged candidates or residual for finite approximations. Every scalar, pole/endpoint, projected, and refined candidate call passes the same invocation-local prepared inputs. No output normalization or clipping is introduced after certification.
- `InterfaceComposition.H:678-692` publishes that owned state/residual pair without mutating it or physical inputs. The zero-diffusion path at `:989-1000` follows the same certificate rule. No successful diagnostic side effect existed in the removed residual evaluation; the actual finite residual warning calls and their typed convergence/approximation conditions remain present.
- `InterfaceMath.H:120-149` prepares species gas constants and total flux from the already validated invocation. The pointers passed through synchronous calls outlive every use. Direct internal solve calls create their own local preparation. No mismatched caller was found.
- `InterfaceMath.H:76-85` recomputes R from `gasR` and each current Y, then constructs a new diffusion state from that R. Density therefore remains composition dependent. Only the species-invariant EOS division is shared within one candidate; the scalar reference diffusion is independently prepared with Rref at `InterfaceComposition.H:838-842`.
- `DiffusionState::scale` preserves the scalar helper's positive finite fast-path operation order and delegates the same guarded extreme-range calculation when the prefix/product/division cannot supply a positive result. Zero diffusivity returns before EOS arithmetic, as before.
- Public validation order, actual-value/component provenance, and fatal/warning producers remain intact. Warning publication still reaches the existing diagnostics machinery and its existing warning switch; no diagnostic context copy, suppression guard, or dt retry/backup was introduced.
- Catalogue changes update moved producer lines and correct the existing bisect producer function name. The new provenance test checks complete source producer context and the owning inline function.

## Commands and actual results

All repository reads were through `wsl.exe -d Ubuntu-22.04 -- bash -lc ...` from PowerShell.

- `git diff --stat BASE HEAD`, `git diff --name-only BASE HEAD`, and full `git diff --no-ext-diff --unified=... BASE HEAD` for all eight files: inspected 240 insertions and 88 deletions.
- `git diff --check d02a96ce86858b64e5a5dba676891798152addee ca421b47f9a545934c75686fd76527b9d17e6b7f`: exit 0, no output.
- `git rev-parse HEAD`: `ca421b47f9a545934c75686fd76527b9d17e6b7f`.
- `git status --short`, before and after review probes: exit 0, empty output. No source/index/HEAD changes found.
- Attempted `rg`; WSL installation lacks rg. Continued with `grep`, `find`, `sed`, and `nl`. No AGENTS.md was found in the repository subtree or checked ancestor directories.

The two independent probes were compiled with this actual command pattern (each exact path below was substituted for NAME):

```sh
TMPDIR=/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/.review-tmp/reuse-review g++ -std=c++14 -O2 -ffp-contract=off -DUGKWP_GAS_SPECIES=10 -I/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/applications/CHMT -I/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/common /mnt/d/tempt/ugkp-pr19-composition-reuse-20261018/independent-review/NAME.cpp -o /mnt/d/tempt/ugkp-pr19-composition-reuse-20261018/independent-review/NAME
```

Both compilations and executions exited 0.

1. `NAME=diffusion_probe`; actual output in `diffusion_probe.log`:
   `PASS: 210000 diffusion comparisons; 36301 typed range failures; 79320 represented zeros; FE_INVALID/DIVBYZERO/OVERFLOW remain clear`
   It uses random positive finite double bit patterns for pressure/T/distance/R and includes exact zero, smallest subnormal, minimum normal, unity, maximum finite, and random diffusivities. Scalar diffusionScale versus shared DiffusionState outcomes and every successful result were compared bitwise; FPE traps were enabled.
2. `python3 .../make_residual_probe.py` extracts the actual BASE residual function using `git show`, renames it locally, and includes HEAD normally; `NAME=residual_probe`. Actual output in `residual_probe.log`:
   `PASS: 10000 BASE-vs-HEAD residual/Jacobian comparisons at Ns=10; 8515 exact successes; 1485 identical typed failures; traps clear`
   It compares the original BASE equation evaluation against HEAD's prepared path over changing normalized compositions and independently varying positive finite coefficients over roughly 600 decimal orders of magnitude. Successful residual vectors/Jacobians were compared bitwise; FPE traps were enabled.

These are bounded independent arithmetic probes, not substitute evidence for full solver or performance validation.

## Declined to judge

- Full pytest/build matrix and controlled before/after CPU/GPU timing: parent owns these; not rerun.
- CUDA compiler register/local-memory/spill effects, GPU throughput, and production GPU behavior: no GPU task or full device build was run here. Extra automatic objects may be optimized away, so source alone is insufficient to quantify these effects.
- Production physical cases or formal repository state beyond this isolated review checkout: not touched or executed.
- Behavior when callers deliberately supply stale/mismatched CompositionResidualInputs or mutate borrowed inputs during a solve: these violate the documented invocation-local immutability contract; no such real caller exists in the inspected tree.
- Exhaustive proof across every representable floating-point input/compiler configuration: probes establish bounded evidence and source preserves the operation sequence, but are not exhaustive enumeration.

## Ready

**Yes**, for the reviewed correctness/structure scope. The accepted minor instrumentation fix is pending a parent-owned test-only increment and brief reviewer readback. No production correctness fix is required. Overall acceptance remains subject to the parent-owned test/build and controlled timing results.
## Readback addendum — test-only commit 1f18b12d7e0442f50d36130469c1c378980f10d7

Reviewed the complete one-file diff from `ca421b47f9a545934c75686fd76527b9d17e6b7f` to `1f18b12d7e0442f50d36130469c1c378980f10d7` without rerunning tests or timing. The original review and its then-pending status above are retained as history; this addendum is the current status.

**Minor resolved.** `publication.cpp:13` now instruments actual quotientFinite function entries, and `:37-39` asserts exactly Ns+1 divisions in the zero-flux initial-certified mode. That mode has one original residual evaluation and no scalar/Newton root work: one EOS division plus one diffusion-distance division per species. A repeated EOS division for each species at Ns>1 therefore fails the new assertion even when no diffusionScale fallback entry occurs. No production arithmetic changed.

Evidence read (parent-generated, not rerun by this reviewer):

- `division-green-command.json` records `python3 -m pytest -q validation/tests/test_interface_composition.py -k certified_result --basetemp /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/.review-tmp/reuse-divisions-final --junitxml /mnt/d/tempt/ugkp-pr19-composition-reuse-20261018/division-green.xml`, exit 0. `division-green.log`: 3 passed, 21 deselected in 1.58s.
- `division-mutant-commands.json` records a successful isolated Ns=10 instrumented g++ build with `-O1 -fno-inline -finstrument-functions -ffp-contract=off`, followed by mutant run exit 2. `division-mutant.log` reports `repeated EOS divisions inside species loop`. Readback of the isolated mutant header confirms the EOS guard update is `attempted=false` at line 71, forcing repeated EOS work; its fallback-entry counter remains zero in the logged modes. This is direct targeted evidence that the new counter closes the reported blind spot.
- `git diff --check ca421b47f9a545934c75686fd76527b9d17e6b7f 1f18b12d7e0442f50d36130469c1c378980f10d7`: exit 0, no output.
- `git status --short`: empty; HEAD is `1f18b12d7e0442f50d36130469c1c378980f10d7`.

Ready: **Yes**, with no remaining Critical, Important, or Minor correctness/coverage finding in this reviewed scope. Performance/device claims remain under the original declined-to-judge limits and the parent-owned evidence.