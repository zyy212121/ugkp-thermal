import os,sys,pytest,json
from pathlib import Path
root=Path("/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-topology-20261018");base=Path("/mnt/d/tempt/ugkp-pr19-followup-20261018/topology/baseline-source")
os.chdir(root)
class Baseline:
 def pytest_collection_modifyitems(self,items):
  for item in items:
   if item.module.__name__=="test_gas_original_success":item.module.ROOT=base
nodes=["validation/tests/gas_transport/test_gas_original_success.py::test_exact_bounded_energy_fallbacks[recovery]"]+["validation/tests/gas_transport/test_gas_original_success.py::test_exact_skipped_face_and_zero_trip_loops["+x+"]" for x in ("convective","diffusion","sst","sst_update","divergence")]+["validation/tests/gas_transport/test_gas_original_success.py::test_exact_courant_fallback_arithmetic"]
raise SystemExit(pytest.main(["-q",*nodes],plugins=[Baseline()]))
