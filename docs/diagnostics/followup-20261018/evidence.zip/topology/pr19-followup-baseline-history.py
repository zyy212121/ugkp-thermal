from pathlib import Path
import subprocess,tarfile,io,os,json,sys
root=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-topology-20261018');o=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/topology');base=o/'baseline-source';base.mkdir(exist_ok=True)
a=subprocess.check_output(['git','archive','e56461583618e78284cfac8c19c5e5233ea4f0c1','common'],cwd=root)
with tarfile.open(fileobj=io.BytesIO(a)) as t:
 for m in t.getmembers():
  resolved=(base/m.name).resolve()
  assert str(resolved).startswith(str(base.resolve())+'/')
  if m.issym():assert str((base/m.name).parent.joinpath(m.linkname).resolve()).startswith(str(base.resolve())+'/')
 t.extractall(base)
runner=o/'baseline-historical-runner.py'
runner.write_text('''import os,sys,pytest,json\nfrom pathlib import Path\nroot=Path("'''+str(root)+'''");base=Path("'''+str(base)+'''")\nos.chdir(root)\nclass Baseline:\n def pytest_collection_modifyitems(self,items):\n  for item in items:\n   if item.module.__name__=="test_gas_original_success":item.module.ROOT=base\nnodes=["validation/tests/gas_transport/test_gas_original_success.py::test_exact_bounded_energy_fallbacks[recovery]"]+["validation/tests/gas_transport/test_gas_original_success.py::test_exact_skipped_face_and_zero_trip_loops["+x+"]" for x in ("convective","diffusion","sst","sst_update","divergence")]+["validation/tests/gas_transport/test_gas_original_success.py::test_exact_courant_fallback_arithmetic"]\nraise SystemExit(pytest.main(["-q",*nodes],plugins=[Baseline()]))\n''')
c=['python3',str(runner)];r=subprocess.run(c,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/'baseline-historical.log').write_bytes(r.stdout);(o/'baseline-historical-command.json').write_text(json.dumps({'command':c,'exit':r.returncode,'calculation_source':'e56461583618e78284cfac8c19c5e5233ea4f0c1'},indent=2));print(r.stdout.decode()[-2500:])
