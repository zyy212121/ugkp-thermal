#include <cuda_runtime.h>
#include <initializer_list>
#include <cstdio>
#include <cstdlib>
#include <new>
void gpuSync(){const auto rc=cudaDeviceSynchronize();if(rc!=cudaSuccess){fprintf(stderr,"CUDA error %d %s\n",int(rc),cudaGetErrorString(rc));std::exit(90);}}
template<class T>T* managed(int n){T*p=nullptr;const auto rc=cudaMallocManaged(&p,n*sizeof(T));if(rc!=cudaSuccess)std::exit(91);for(int i=0;i<n;++i)new(p+i)T{};return p;}
template<class T>T* managedInit(int n,std::initializer_list<T> v){T*p=managed<T>(n);int i=0;for(auto x:v)p[i++]=x;return p;}
// Runs unchanged production device functions serially on a host. Not CUDA execution.
#include <cmath>
using std::isfinite;
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include "GpuPrecisionTypes.H"
#include "CharacteristicMuscl.cuh"
#include "OpenFoamLimitedLinear.cuh"
#include "OpenFoamViscousFlux.cuh"
#include "OpenFoamWallFunctions.cuh"
#include "RiemannBoundaryState.cuh"
#include "RiemannGasFlux.cuh"
#include "GpuSstAlgebra.cuh"
#include "GpuLesAlgebra.cuh"
using Real=GpuReal;
using Time=double;
#define GPU_OPERATOR_REAL Real
#define GPU_OPERATOR_TIME Time
#define GPU_OPERATOR_R GPU_R
#define GPU_OPERATOR_TINY(x) GPU_R(1e-30)

// PTX traps are represented by process failure in this serial host emulator.
constexpr Real OfSmall=GPU_R(2.22044604925031308085e-16);
constexpr Real OfVSmall=GPU_R(1e-30);
constexpr Real OfGreat=GPU_R(1.0)/OfSmall;
struct GasPrimDevice { Real rho,ux,uy,uz,p,T; };
#include "legacy_gas_fixture.hpp"
#ifdef LEGACY_REFERENCE
using DeviceState=LegacyGasFixture;
#else
// No application DeviceState definition: the actual operators must be generic.
#include "gasTransport/GasStateView.H"
#endif
#include "operators/clampMin.cuh"
#include "operators/clampRange.cuh"
#include "operators/linearScheduledValueDevice.cuh"
#include "operators/makeGasPrimDevice.cuh"
#include "operators/riemannFacePrimitiveForGradient.cuh"
#include "operators/computeGasPrimitiveGradientsKernel.cuh"
#include "operators/computeSstGradientsKernel.cuh"
#include "operators/sstVelocityInvariants.cuh"
#include "operators/computeGasHllcAdcSensorKernel.cuh"
#include "operators/updateBarthLimiter.cuh"
#include "operators/computeGasGradientLimiterKernel.cuh"
#include "operators/computeGasEddyViscosityKernel.cuh"
#include "operators/updateWaveTransmissivePressureBoundaryKernel.cuh"
#include "operators/updateLegacyGasBoundaryMirrorKernel.cuh"
#include "operators/gasFaceSubgridTransportProperties.cuh"
#include "operators/computeRiemannGasFaceFluxDevice.cuh"
#include "operators/computeGasInternalFaceFluxKernel.cuh"
#include "operators/computeGasFluxPositivityScaleKernel.cuh"
#include "operators/computeSstFaceFluxKernel.cuh"

#ifdef LEGACY_OPTIONAL_SPECIES
struct TestLegacyGasFixture:LegacyGasFixture{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
#else
using TestLegacyGasFixture=LegacyGasFixture;
#endif

struct State:ugkwp::GasStateView<Real,Time,ugkwp::SstCoefficients>{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
void ck(bool good,const char*message){if(!good){std::fprintf(stderr,"%s\n",message);std::abort();}}
void initialise(State&s){
s.diagnostics=managedInit<ugkp::diagnostics::DeviceContext>( 8, {});
s.Cx=managedInit<Real>( 8, {});
s.Cy=managedInit<Real>( 8, {});
s.Cz=managedInit<Real>( 8, {});
s.Sfx=managedInit<Real>( 8, {});
s.Sfy=managedInit<Real>( 8, {});
s.Sfz=managedInit<Real>( 8, {});
s.Tgas=managedInit<Real>( 8, {});
s.Ux=managedInit<Real>( 8, {});
s.Uy=managedInit<Real>( 8, {});
s.Uz=managedInit<Real>( 8, {});
s.V=managedInit<Real>( 8, {});
s.cellFaceId=managedInit<int>( 8, {});
s.cellLength=managedInit<Real>( 8, {});
s.cellPlaneCount=managedInit<int>( 8, {});
s.cellPlaneStart=managedInit<int>( 8, {});
s.deltaCoeffs=managedInit<Real>( 8, {});
s.faceCx=managedInit<Real>( 8, {});
s.faceCy=managedInit<Real>( 8, {});
s.faceCz=managedInit<Real>( 8, {});
s.faceNeighbour=managedInit<int>( 8, {});
s.faceOwner=managedInit<int>( 8, {});
s.facePeriodicDx=managedInit<Real>( 8, {});
s.facePeriodicDy=managedInit<Real>( 8, {});
s.facePeriodicDz=managedInit<Real>( 8, {});
s.facePeriodicPair=managedInit<int>( 8, {});
s.faceWeight=managedInit<Real>( 8, {});
s.gasBoundaryKind=managedInit<int>( 8, {});
s.gasBoundaryP=managedInit<Real>( 8, {});
s.gasBoundaryPFix=managedInit<int>( 8, {});
s.gasBoundaryPWave=managedInit<int>( 8, {});
s.gasBoundaryPWaveFieldInf=managedInit<Real>( 8, {});
s.gasBoundaryPWaveGamma=managedInit<Real>( 8, {});
s.gasBoundaryPWaveLInf=managedInit<Real>( 8, {});
s.gasBoundaryRho=managedInit<Real>( 8, {});
s.gasBoundaryRhoFix=managedInit<int>( 8, {});
s.gasBoundaryT=managedInit<Real>( 8, {});
s.gasBoundaryTFix=managedInit<int>( 8, {});
s.gasBoundaryUFix=managedInit<int>( 8, {});
s.gasBoundaryUx=managedInit<Real>( 8, {});
s.gasBoundaryUy=managedInit<Real>( 8, {});
s.gasBoundaryUz=managedInit<Real>( 8, {});
s.gasDiffusionNumber=managedInit<Real>( 8, {});
s.gasFluxPositivityScale=managedInit<Real>( 8, {});
s.gasGradientLimiterP=managedInit<Real>( 8, {});
s.gasGradientLimiterRho=managedInit<Real>( 8, {});
s.gasGradientLimiterT=managedInit<Real>( 8, {});
s.gasGradientLimiterUx=managedInit<Real>( 8, {});
s.gasGradientLimiterUy=managedInit<Real>( 8, {});
s.gasGradientLimiterUz=managedInit<Real>( 8, {});
s.gasHllcAdcSensor=managedInit<Real>( 8, {});
s.gasPhiRho=managedInit<Real>( 8, {});
s.gasPhiRhoE=managedInit<Real>( 8, {});
s.gasPhiRhoUx=managedInit<Real>( 8, {});
s.gasPhiRhoUy=managedInit<Real>( 8, {});
s.gasPhiRhoUz=managedInit<Real>( 8, {});
s.gradKX=managedInit<Real>( 8, {});
s.gradKY=managedInit<Real>( 8, {});
s.gradKZ=managedInit<Real>( 8, {});
s.gradOmegaX=managedInit<Real>( 8, {});
s.gradOmegaY=managedInit<Real>( 8, {});
s.gradOmegaZ=managedInit<Real>( 8, {});
s.gradPx=managedInit<Real>( 8, {});
s.gradPy=managedInit<Real>( 8, {});
s.gradPz=managedInit<Real>( 8, {});
s.gradRhoX=managedInit<Real>( 8, {});
s.gradRhoY=managedInit<Real>( 8, {});
s.gradRhoZ=managedInit<Real>( 8, {});
s.gradTX=managedInit<Real>( 8, {});
s.gradTY=managedInit<Real>( 8, {});
s.gradTZ=managedInit<Real>( 8, {});
s.gradUxX=managedInit<Real>( 8, {});
s.gradUxY=managedInit<Real>( 8, {});
s.gradUxZ=managedInit<Real>( 8, {});
s.gradUyX=managedInit<Real>( 8, {});
s.gradUyY=managedInit<Real>( 8, {});
s.gradUyZ=managedInit<Real>( 8, {});
s.gradUzX=managedInit<Real>( 8, {});
s.gradUzY=managedInit<Real>( 8, {});
s.gradUzZ=managedInit<Real>( 8, {});
s.k=managedInit<Real>( 8, {});
s.magSf=managedInit<Real>( 8, {});
s.nut=managedInit<Real>( 8, {});
s.omega=managedInit<Real>( 8, {});
s.p=managedInit<Real>( 8, {});
s.pressureScheduleTimes=managedInit<Time>( 8, {});
s.pressureScheduleValues=managedInit<Real>( 8, {});
s.rho=managedInit<Real>( 8, {});
s.rhoE=managedInit<Real>( 8, {});
s.rhoENext=managedInit<Real>( 8, {});
s.rhoK=managedInit<Real>( 8, {});
s.rhoKInitial=managedInit<Real>( 8, {});
s.rhoNext=managedInit<Real>( 8, {});
s.rhoOmega=managedInit<Real>( 8, {});
s.rhoOmegaInitial=managedInit<Real>( 8, {});
s.rhoUx=managedInit<Real>( 8, {});
s.rhoUxNext=managedInit<Real>( 8, {});
s.rhoUy=managedInit<Real>( 8, {});
s.rhoUyNext=managedInit<Real>( 8, {});
s.rhoUz=managedInit<Real>( 8, {});
s.rhoUzNext=managedInit<Real>( 8, {});
s.riemannBoundaryKind=managedInit<int>( 8, {});
s.riemannBoundaryP=managedInit<Real>( 8, {});
s.riemannBoundaryPFix=managedInit<int>( 8, {});
s.riemannBoundaryPWave=managedInit<int>( 8, {});
s.riemannBoundaryRho=managedInit<Real>( 8, {});
s.riemannBoundaryRhoFix=managedInit<int>( 8, {});
s.riemannBoundaryT=managedInit<Real>( 8, {});
s.riemannBoundaryTFix=managedInit<int>( 8, {});
s.riemannBoundaryUFix=managedInit<int>( 8, {});
s.riemannBoundaryUx=managedInit<Real>( 8, {});
s.riemannBoundaryUy=managedInit<Real>( 8, {});
s.riemannBoundaryUz=managedInit<Real>( 8, {});
s.scheduledInletFaceMask=managedInit<int>( 8, {});
s.sstBoundaryK=managedInit<Real>( 8, {});
s.sstBoundaryKMode=managedInit<int>( 8, {});
s.sstBoundaryOmega=managedInit<Real>( 8, {});
s.sstBoundaryOmegaMode=managedInit<int>( 8, {});
s.sstF1=managedInit<Real>( 8, {});
s.sstF2=managedInit<Real>( 8, {});
s.sstPhiRhoK=managedInit<Real>( 8, {});
s.sstPhiRhoOmega=managedInit<Real>( 8, {});
s.sstSourceNumber=managedInit<Real>( 8, {});
s.sstWallDistance=managedInit<Real>( 8, {});
s.nCells=2;s.nFaces=3;s.nInternalFaces=1;s.gasFluxScheme=1;s.gasReconstruction=0;s.gasLimiter=0;s.gasMu=0;s.gasPrClamped=.7;s.gammaGas=1.4;s.Rgas=287;s.gasCp=1004.5;s.rhoMin=1e-12;s.TgasMin=1e-9;
s.gasSpecies.mode=ugkwp::GasMode::MixtureFrozen;
auto&g=s.gasSpecies;g.rho=managedInit<Real>( 4, {});g.initial=managedInit<Real>( 4, {});g.flux=managedInit<Real>( 6, {});g.gradX=managedInit<Real>( 4, {});g.gradY=managedInit<Real>( 4, {});g.gradZ=managedInit<Real>( 4, {});g.limiter=managedInit<Real>( 2, {});g.boundaryMassFraction=managedInit<Real>( 6, {});g.compositionBoundaryFixed=managedInit<int>( 3, {});g.positivityScale=managedInit<Real>( 4, {});g.soundSpeed=managedInit<Real>( 2, {});g.heatCapacity=managedInit<Real>( 2, {});g.gasConstant=managedInit<Real>( 2, {});g.cellStatus=managedInit<int>( 2, {});g.faceStatus=managedInit<int>( 3, {});
auto*meta=managed<ugkwp::SpeciesThermoData<Real>>(2);auto*coeff=managedInit<Real>( 6, {1000,0,-1e6,1000,0,2e6});g.thermo.species=meta;g.thermo.coefficients=coeff;g.thermo.coefficientCount=6;g.thermoControls.relativeEnergyTolerance=Real(2e-6);g.thermoControls.relativeTemperatureTolerance=Real(2e-6);
for(int k=0;k<2;++k){meta[k].molarMass=.028;meta[k].minTemperature=100;meta[k].maxTemperature=3000;meta[k].referencePressure=101325;meta[k].coefficientOffset=3*k;}
g.rho[0]=.9;g.rho[1]=.1;g.rho[2]=.1;g.rho[3]=.9;
for(int c=0;c<2;++c){s.V[c]=1;s.Cx[c]=c;s.rho[c]=1;Real rhos[2]={g.rho[c],g.rho[2+c]};s.rhoE[c]=ugkwp::mixtureEnergy(rhos,Real(700),g.thermo);s.Tgas[c]=700;s.cellPlaneStart[c]=2*c;s.cellPlaneCount[c]=2;}
s.cellFaceId[0]=0;s.cellFaceId[1]=1;s.cellFaceId[2]=0;s.cellFaceId[3]=2;
for(int f=0;f<3;++f){s.faceOwner[f]=f==2?1:0;s.faceNeighbour[f]=f==0?1:-1;s.facePeriodicPair[f]=-1;s.magSf[f]=1;s.Sfx[f]=f==1?-1:1;s.faceCx[f]=f==0?.5:f==1?-.5:1.5;s.faceWeight[f]=.5;s.deltaCoeffs[f]=f==0?1:2;s.gasBoundaryKind[f]=s.riemannBoundaryKind[f]=f==0?0:1;}

recoverGasPrimitivesKernel<<<1,2>>>(&s);gpuSync();
}

__global__ void boundaryProbe(State* s,int face,Real*result){auto q=riemannFacePrimitiveForGradient(*s,0,face);result[0]=q.rho;result[1]=q.T;}
State* state(){auto s=managed<State>(1);initialise(*s);s->diagnostics=managed<ugkp::diagnostics::DeviceContext>(1);return s;}
void clean(State*s){ck(!ugkp::diagnostics::hasFatal(s->diagnostics)&&s->gasSpecies.cellStatus[0]==0,"unexpected physical/index diagnostic");}
int main(){
 for(bool native:{false,true}){auto s=state();s->faceOwner=nullptr;s->faceNeighbour=nullptr;s->facePeriodicPair=nullptr;s->gasPhiRhoE[0]=2;s->gasPhiRhoE[1]=4;computeGasConvectiveCourantByCellKernel<<<1,1>>>(s,.1,native);gpuSync();clean(s);ck(std::abs(s->gasFluxPositivityScale[0]-.3)<1e-14,"Courant sum");}
 for(int face:{-1,3}){auto s=state();s->cellFaceId[0]=face;s->gasFluxPositivityScale[0]=-99;computeGasConvectiveCourantByCellKernel<<<1,1>>>(s,.1);gpuSync();ck(s->diagnostics->firstFatal.sourceSiteId==30000&&s->gasFluxPositivityScale[0]==-99,"face OOB not protected");}
 {auto s=state();auto q=managed<Real>(2);s->faceOwner=nullptr;s->faceNeighbour=nullptr;boundaryProbe<<<1,1>>>(s,1,q);gpuSync();clean(s);ck(q[0]==s->rho[0]&&q[1]==s->Tgas[0],"local primitive");}
 {auto s=state();auto q=managed<Real>(2);s->faceNeighbour[0]=s->nCells;boundaryProbe<<<1,1>>>(s,0,q);gpuSync();ck(s->diagnostics->firstFatal.sourceSiteId==30002&&std::isnan(q[0]),"enabled cell OOB not protected");}
 for(int kind:{1,3,4}){auto s=state();s->nFaces=1;s->nInternalFaces=0;s->facePeriodicPair[0]=-1;s->sstConfigured=1;s->riemannBoundaryKind[0]=kind;s->faceOwner=nullptr;s->faceNeighbour=nullptr;s->sstPhiRhoK[0]=7;s->sstPhiRhoOmega[0]=9;computeSstFaceFluxKernel<<<1,1>>>(s);gpuSync();clean(s);ck(s->sstPhiRhoK[0]==0&&s->sstPhiRhoOmega[0]==0,"zero SST face");}
 for(int kind:{1,3,4}){auto s=state();s->cellPlaneCount[0]=1;s->cellFaceId[0]=1;s->riemannBoundaryKind[1]=kind;s->faceOwner=nullptr;s->faceNeighbour=nullptr;computeGasDiffusionNumberKernel<<<1,1>>>(s,.1,.7);gpuSync();clean(s);ck(s->gasDiffusionNumber[0]==0,"disabled diffusion");}
 {auto s=state();s->cellPlaneCount[0]=1;s->cellFaceId[0]=1;s->riemannBoundaryKind[1]=0;s->gasMu=.01;s->maxDiffusionNumber=.25;s->faceOwner=nullptr;s->faceNeighbour=nullptr;computeGasDiffusionNumberKernel<<<1,1>>>(s,.1,.7);gpuSync();clean(s);ck(s->gasDiffusionNumber[0]>0&&std::isfinite(s->gasDiffusionNumber[0]),"active local diffusion");}
 for(int limiter:{0,1}){auto s=state();s->cellPlaneCount[0]=1;s->cellFaceId[0]=1;s->faceOwner=nullptr;s->faceNeighbour=nullptr;s->gasLimiter=limiter;computeGasGradientLimiterKernel<<<1,1>>>(s);gpuSync();clean(s);ck(s->gasSpecies.limiter[0]==1&&s->gasGradientLimiterRho[0]==1,"local limiter");}
 for(int kind:{3,4}){auto s=state();s->cellPlaneCount[0]=1;s->cellFaceId[0]=1;s->riemannBoundaryKind[1]=kind;s->sstConfigured=1;s->sstCoefficients=ugkwp::defaultSstCoefficients();s->k[0]=.1;s->omega[0]=3;s->rhoK[0]=.1;s->rhoOmega[0]=3;s->sstKMin=1e-12;s->sstOmegaMin=1e-6;s->sstMaxSourceNumber=.25;s->faceOwner=nullptr;s->faceNeighbour=nullptr;computeSstStabilityNumberKernel<<<1,1>>>(s,.1,.7);gpuSync();clean(s);ck(std::isfinite(s->sstSourceNumber[0]),"disabled SST stability");}
 {auto s=state();s->cellPlaneCount[0]=1;s->cellFaceId[0]=1;s->riemannBoundaryKind[1]=1;s->sstConfigured=1;s->sstWallTreatment=0;s->omega[0]=3;s->faceOwner=nullptr;s->faceNeighbour=nullptr;applySstWallFunctionStateKernel<<<1,1>>>(s);gpuSync();clean(s);ck(s->omega[0]==3,"nonwall classification");}
 puts("real CUDA consumer contracts: 18 cases PASS");return 0;
}
