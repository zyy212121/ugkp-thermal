from pathlib import Path
import subprocess,json,sys
source=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-topology-20261018')
out=Path(__file__).resolve().parent
command=['python3','-m','pytest','-q','validation/tests/test_stencil_consumer_contracts.py','validation/tests/test_diagnostics_core.py::test_cuda_transfer_catalogue_points_to_record_producer','validation/tests/test_diagnostics_core.py::test_production_diagnostic_callsite_ids_are_unique','validation/tests/test_gpu_diagnostic_owner.py','validation/tests/test_final_diagnostic_integration.py']
r=subprocess.run(command,cwd=source,capture_output=True,text=True)
(out/'reproduce-focused.log').write_text(r.stdout+r.stderr)
(out/'reproduce-focused-command.json').write_text(json.dumps({'command':command,'cwd':str(source),'exit':r.returncode},indent=2)+'\n')
print(r.stdout+r.stderr)
raise SystemExit(r.returncode)
