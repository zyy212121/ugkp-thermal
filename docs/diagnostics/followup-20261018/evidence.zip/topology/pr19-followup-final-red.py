from pathlib import Path
import subprocess,json,os,shutil
p=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-topology-20261018');o=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/topology');base=o/'baseline-source'
for name in ['gas_state_probe.cpp','legacy_gas_fixture.hpp','test_mixture_transport.py']:
 dest=base/'validation/tests/gas_transport'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/'validation/tests/gas_transport'/name,dest)
env=dict(os.environ);env['UGKP_SOURCE_ROOT']=str(base)
c=['python3','-m','pytest','-q','validation/tests/test_stencil_consumer_contracts.py']
r=subprocess.run(c,cwd=p,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(o/'red-final-fixtures-baseline.log').write_bytes(r.stdout);(o/'red-final-fixtures-baseline-command.json').write_text(json.dumps({'command':c,'exit':r.returncode,'source_root':str(base),'calculation_source':'e56461583618e78284cfac8c19c5e5233ea4f0c1'},indent=2));print(r.stdout.decode()[-3000:])
