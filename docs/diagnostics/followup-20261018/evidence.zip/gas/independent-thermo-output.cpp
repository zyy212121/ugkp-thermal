#include "gasTransport/MixtureThermo.H"
#include <cassert>
#include <cstring>
#include <limits>
int main(){using namespace ugkwp;SpeciesThermoData<double> sp;sp.molarMass=.028;sp.minTemperature=1;sp.maxTemperature=4000;double coef[]={1000,(std::numeric_limits<double>::max)(),0};SpeciesThermoView<double,1> v;v.species=&sp;v.coefficients=coef;v.coefficientCount=3;
 gasThermoDetail::SpeciesValues<double> output{11,12,13,14,15};const auto before=output;bool evaluated=true;double failed=17;
 assert(gasThermoDetail::evaluateSpecies(0,300.,v,output,&evaluated,&failed)==ThermoStatus::NonFiniteInput);assert(!evaluated&&std::isinf(failed));assert(std::memcmp(&output,&before,sizeof(output))==0);
 failed=17;evaluated=true;assert(gasThermoDetail::evaluateSpecies(-1,300.,v,output,&evaluated,&failed)==ThermoStatus::InvalidModel);assert(!evaluated&&failed==17&&std::memcmp(&output,&before,sizeof(output))==0);
 coef[1]=0;failed=17;assert(gasThermoDetail::evaluateSpecies(0,300.,v,output,&evaluated,&failed)==ThermoStatus::Success);assert(evaluated&&output.cp==1000&&failed==17);
}
