from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-gas-20261018')
E=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/gas')
base='e56461583618e78284cfac8c19c5e5233ea4f0c1'
files=['common/Diagnostics.H','common/DiagnosticsHost.H','common/gasTransport/MixtureThermo.H','common/operators/computeSstFaceFluxKernel.cuh','common/operators/gasFaceSubgridTransportProperties.cuh','validation/tests/gas_transport/test_followup_fraction_and_cp.py']
records=[]
def git(*args):
    cmd=['git','-C',str(R),*args];c=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    records.append({'command':cmd,'exit_code':c.returncode,'output':c.stdout});assert c.returncode==0,c.stdout;return c.stdout.strip()
assert git('rev-parse','HEAD')==base
git('diff','--check')
(E/'repair.patch').write_text(git('diff','--',*files[:5])+'\n')
git('add','--',*files)
git('diff','--cached','--check')
assert set(git('diff','--cached','--name-only').splitlines())==set(files)
git('commit','-m','Preserve nonfinite gas fraction and wall heat-capacity diagnostics')
sha=git('rev-parse','HEAD')
git('diff','--check',base,sha)
status=git('status','--porcelain=v1')
result={'commit':sha,'base':base,'branch':git('branch','--show-current'),'files':{f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files},'status':status,
 'validation':{'red-final':'6 failed, 2 passed; exit1, original production helpers before repair','green-verified':'11 passed, exit0; signed fraction overflow, finite clipping output toggle, linear/NASA7 Cp overflow, Ns2/Ns10 CUDA compile','affected':'45 passed, 4 skipped, 1 catalogue line-offset failure. Parent owns integrated catalogue repair; no helper assertion remains failed.'},'commands':records}
(E/'commit-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(R/files[-1],E/'test_followup_fraction_and_cp.py')
shutil.copy2(Path(__file__),E/Path(__file__).name)
text=f'''PR19气相定点修复：条目2、4

提交：{sha}
基线：{base}
工作区：{R}
仅本地提交；未推送、未改main或正式库。

条目2：recoverGasPrimitiveCell原来先检查分密度和总密度为有限值，却未检查二者相除后的fraction；有限最大分密度除以有限微小正密度可得±Inf，然后被当成有限越界比例截断为0/1。现在在截断前记录NonFinite，实体cell、component=species、quantity=massfraction、observed保留实际±Inf，保留粗状态NonFiniteState，并立即结束该次primitive producer。有限的负舍入量和略大于1的值仍按既有规则截断并warning，不重写守恒分密度，warning输出开关只影响输出。

条目4：evaluateSpecies已有正确的真实非有限计算值，但在返回错误前不发布output；壁面调用方将thermo诊断上下文置空，重新猜测错误值，所有系数仍有限而Cp溢出时只记合成NaN。现在增加可选nonfiniteValue指针，将同一次物性计算得到的真实异常值送给调用者；不重复求值、不改变原计算及错误返回，也不发布失败的物性output。壁面producer以实际面、species、operator26、site2658登记该值；新增quantity13="heat capacity"。线性Cp与NASA7两个真实生产模型均测到actualInf。未恢复回溯、重试或备用计算。

验证：red-final.log/xml/command.json原实现6失败、2正常对照通过；green-verified.log/xml/command.json修复后11项通过。包含ordinary/native两模式、正负无限商、可选详细上下文、有限舍入clip、warning输出开/关结果逐字节一致、error不受warning开关影响、linear/NASA7有限系数导致Cp溢出的真实值/实体/时间元数据、CUDA13.1 sm89下Ns2/Ns10真实producer实例化编译。

受影响既有测试：affected.log/xml共45通过、4跳过、1失败。唯一失败是DiagnosticsCatalogue源行号偏移：本分支未改Catalogue，由父任务统一重算各分支集成后的源行号。catalogue-offsets-for-parent.json逐项列旧行与新行。4跳过来自既有测试的OpenFOAM/CUDA环境/固定工具路径探测，不能当作无GPU；本轮独立NVCC实际编译已通过。没有将这些跳过计为执行通过。新增NASA7测试过程中一次字符串模板误替换造成编译失败，保存在green-final.log，修正模板后green-verified才是最终版本证据。

重现：在独立clone/worktree取base，再仅复制test_followup_fraction_and_cp.py中初始8项测试（去NASA7扩展/CUDA项）可复现red6失败；red-final-tmp保留原实现已编译探针及输入。修复后运行green-verified-command.json中的完整pytest命令。所有执行命令、返回码、原始日志均在本目录；修复差异repair.patch与测试副本一并保留。没有开展全库广泛测试或生产长算。
'''
(E/'gas-fix-report.txt').write_text(text)
print(json.dumps({k:v for k,v in result.items() if k!='commands'},ensure_ascii=False,indent=2))
