source /mnt/d/tempt/ugkp-pr19-followup-20261018/env-final.sh
unset GAS_UGKP_CUDA_BACKEND
strace -f -e trace=execve -o /mnt/d/tempt/ugkp-pr19-followup-20261018/restart-final-execve.log /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-20261018/.review-install/bin/gasUGKP -case /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-20261018/.review-runs/restart004-final
