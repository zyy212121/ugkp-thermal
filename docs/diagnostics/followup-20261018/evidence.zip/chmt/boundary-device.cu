#include "core/AuditArithmetic.H"
__global__ void audit_boundary(double* values){values[2]=chmt::auditAdd(values[0],values[1]);values[3]=chmt::auditProduct(values[0],values[1]);values[4]=chmt::auditDifference(values[0],values[1]);}
