#include "core/AuditArithmetic.H"
#include <cfenv>
#include <cstdio>
#include <cmath>
int main(){volatile double a=std::nextafter(std::numeric_limits<double>::max(),0.),b=std::ldexp(1.5,971);std::feclearexcept(FE_ALL_EXCEPT);volatile double c=chmt::auditAdd(a,b);std::printf("a=%a b=%a c=%a flags=%d\n",double(a),double(b),double(c),std::fetestexcept(FE_OVERFLOW));return std::fetestexcept(FE_OVERFLOW)?1:0;}
