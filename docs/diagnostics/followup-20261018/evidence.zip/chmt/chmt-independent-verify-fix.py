from pathlib import Path
import hashlib,json,os,shutil,subprocess
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018')
E=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt')
P=E/'independent-postfix';P.mkdir(exist_ok=True)
records=[]
def run(cmd,log,env=None):
 c=subprocess.run(cmd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (P/log).write_text(c.stdout);records.append({'command':cmd,'exit_code':c.returncode,'log':log});return c.returncode
for name,src in [('product','independent-arithmetic.cpp'),('add','independent-add-boundary.cpp')]:
 cmd=['g++','-std=c++17','-O2','-DUGKWP_GAS_SPECIES=2','-I'+str(R/'applications/CHMT'),str(E/src),'-o',str(P/name)]
 if run(cmd,name+'-build.log')==0:run([str(P/name)],name+'-run.log')
currentHeader=R/'applications/CHMT/core/AuditArithmetic.H'
shutil.copy2(currentHeader,P/'tested-AuditArithmetic.H')
for name,src in [('product','independent-native.cpp'),('adddiff','independent-add-native.cpp')]:
 t=(E/src).read_text().replace('#include "independent-pre-fix-AuditArithmetic.H"','#include "core/AuditArithmetic.H"')
 (P/(name+'.cpp')).write_text(t)
 initial=json.loads((E/'independent-native-commands.json').read_text())[0]['command']
 cmd=[x.replace('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-20261018',str(R)) for x in initial]
 cmd=[str(P/(name+'.cpp')) if x==str(E/'independent-native.cpp') else str(P/(name+'-native')) if x==str(E/'independent-native') else x for x in cmd]
 if run(cmd,name+'-native-build.log')!=0:continue
 for mode in (['product'] if name=='product' else ['add','difference']):
  for warnings in ['1','0']:
   env=dict(os.environ,FOAM_SIGFPE='1',UGKP_DIAGNOSTIC_WARNINGS=warnings,WM_PROJECT_DIR='/opt/openfoam10',FOAM_ETC='/opt/openfoam10/etc',LD_LIBRARY_PATH='/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib:/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib/openmpi-system')
   run([str(P/(name+'-native')),*([mode] if name!='product' else [])],mode+'-native-warnings-'+warnings+'.log',env)
   records[-1]['environment']={k:env[k] for k in ['FOAM_SIGFPE','UGKP_DIAGNOSTIC_WARNINGS','WM_PROJECT_DIR','FOAM_ETC','LD_LIBRARY_PATH']}
metadata={'source':str(currentHeader),'source_sha256':hashlib.sha256(currentHeader.read_bytes()).hexdigest(),'commands':records}
(P/'commands.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
for p in P.glob('*-run.log'):print(p.name+': '+p.read_text())
