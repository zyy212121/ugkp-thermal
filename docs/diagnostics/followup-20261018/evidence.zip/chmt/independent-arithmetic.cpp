#include "core/AuditArithmetic.H"
#include <cfenv>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <initializer_list>
int main(){
 unsigned long long random=0x123456789abcdefULL;
 const double max=std::numeric_limits<double>::max();
 unsigned productTrap=0,densityFalseNeg=0,densityFalsePos=0;
 for(int i=0;i<1000000;++i){
  random^=random<<13;random^=random>>7;random^=random<<17;
  std::uint64_t bits=0x3ff0000000000000ULL|(random&0x000fffffffffffffULL);
  double b;std::memcpy(&b,&bits,sizeof b);
  volatile double av=max/b,bv=b;
  std::feclearexcept(FE_ALL_EXCEPT);
  volatile double audit=chmt::auditProduct(av,bv);(void)audit;
  if(std::fetestexcept(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO)){
   if(productTrap++<5)std::printf("auditProduct trap a=%a b=%a result=%a\n",double(av),double(bv),double(audit));
  }
  const double volume=b*.5;
  const double threshold=max*volume;
  for(double mass:{std::nextafter(threshold,0.),threshold,std::nextafter(threshold,max)}){
   volatile double m=mass,v=volume;
   const bool predicted=volume<1&&mass>max*volume;
   const double actual=m/v;
   if(!predicted&&std::isinf(actual)){
    if(densityFalseNeg++<5)std::printf("density missedoverflow mass=%a volume=%a threshold=%a actual=%a\n",mass,volume,threshold,actual);
   }
   if(predicted&&std::isfinite(actual)){
    if(densityFalsePos++<5)std::printf("density falseoverflow mass=%a volume=%a threshold=%a actual=%a\n",mass,volume,threshold,actual);
   }
  }
 }
 std::printf("productTraps=%u densityFalseNeg=%u densityFalsePos=%u\n",productTrap,densityFalseNeg,densityFalsePos);
 return productTrap||densityFalseNeg||densityFalsePos?1:0;
}
