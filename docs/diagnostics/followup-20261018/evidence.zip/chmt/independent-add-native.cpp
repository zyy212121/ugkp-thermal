#include "independent-pre-fix-AuditArithmetic.H"
#include "coupling/ExchangeLedger.H"
#include "DiagnosticsFoam.H"
#include "sigFpe.H"
#include <cfenv>
#include <cstdio>
int main(int argc,char** argv){
 Foam::sigFpe trap;trap.set(true);
 if((fegetexcept()&(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))!=(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))return 3;
 volatile double av=0x1.5dbfd0344dbaep+1023,bv=0x1.76c2887c5d2bp+0;
 ugkp::diagnostics::DeviceContext d{};
 chmt::Tolerances t;t.diagnostics=&d;t.absoluteEnergy=0;t.relativeEnergy=av;
 chmt::ExchangePacket p;p.gasCell=p.solidCell=0;
 if(argc!=2)return 2;
 volatile double a=0x1.be208898a7384p+1023,b=0x1.077ddd9d631eep+1021;
 t.relativeEnergy=0;t.absoluteEnergy=0;
 if(argv[1][0]=='a'){p.conductive=a;p.advective=b;p.energy=0;}
 else {p.conductive=a;p.energy=-b;}

 chmt::DeviceStatus status{};
 std::fprintf(stderr,"Before actual validatePacketMath: relative=%a scale=%a\n",double(av),double(bv));std::fflush(stderr);
 const bool ok=chmt::validatePacketMath(p,t,&status);
 std::fprintf(stderr,"After: ok=%d warning=%u fatal=%u\n",ok,d.warnings[0].count,d.fatalClaim);
 return !ok||d.fatalClaim?1:0;
}
