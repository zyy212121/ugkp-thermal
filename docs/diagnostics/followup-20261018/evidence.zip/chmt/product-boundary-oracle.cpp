#include "core/AuditArithmetic.H"
#include <cfenv>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <initializer_list>
bool bitsame(double a,double b){std::uint64_t x,y;std::memcpy(&x,&a,8);std::memcpy(&y,&b,8);return x==y;}
int main(){unsigned long long seed=0x123456789abcdefULL;const double largest=std::numeric_limits<double>::max();unsigned traps=0,finiteChanges=0,wrongInf=0,count=0;
 auto test=[&](double a,double b){volatile double av=a,bv=b;const double direct=av*bv;std::feclearexcept(FE_ALL_EXCEPT);volatile double actual=chmt::auditProduct(av,bv);if(std::fetestexcept(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))++traps;if(std::isfinite(direct)&&!bitsame(direct,actual)){if(finiteChanges++<3)std::printf("finite changed %a * %a => %a vs %a\n",a,b,direct,double(actual));}if(std::isinf(direct)&&(!std::isinf(actual)||std::signbit(direct)!=std::signbit(actual)))++wrongInf;++count;};
 for(int i=0;i<1000000;++i){seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;std::uint64_t bits=0x3ff0000000000000ULL|(seed&0x000fffffffffffffULL);double b;std::memcpy(&b,&bits,8);const double threshold=largest/b;for(double a:{std::nextafter(threshold,0.),threshold,std::nextafter(threshold,largest)}){test(a,b);test(-a,b);}}
 test(largest,1);test(1,largest);test(largest*.5,2);test(0x1.5dbfd0344dbaep+1023,0x1.76c2887c5d2bp+0);
 std::printf("cases=%u traps=%u finiteChanges=%u wrongInf=%u\n",count,traps,finiteChanges,wrongInf);return traps||finiteChanges||wrongInf?1:0;
}
