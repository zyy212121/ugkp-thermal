from pathlib import Path
import json,shutil,subprocess
E=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt')
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-20261018')
src=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work/chmt-independent-add.cpp')
shutil.copy2(src,E/'independent-add-boundary.cpp')
records=[]
for label,cmd in [('build',['g++','-std=c++17','-O2','-DUGKWP_GAS_SPECIES=2','-I'+str(R/'applications/CHMT'),str(E/'independent-add-boundary.cpp'),'-o',str(E/'independent-add-boundary')]),('run',[str(E/'independent-add-boundary')])]:
 c=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(E/('independent-add-'+label+'.log')).write_text(c.stdout)
 records.append({'command':cmd,'exit_code':c.returncode,'log':'independent-add-'+label+'.log'})
 if c.returncode and label=='build':break
(E/'independent-add-commands.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2));print(c.stdout)
