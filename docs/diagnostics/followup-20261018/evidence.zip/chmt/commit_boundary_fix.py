from pathlib import Path
import subprocess,json,hashlib
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018');e=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt');files=['applications/CHMT/core/AuditArithmetic.H','validation/tests/fixtures/chmt_audit_overflow.cpp'];records=[]
for cmd in [['git','diff','--check'],['git','add',*files],['git','commit','-m','Make diagnostic overflow checks exact at binary64 boundaries']]:
 p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);records.append({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,p.stderr
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();(e/'boundary-commit-commands.json').write_text(json.dumps(records,indent=2)+'\n');(e/'boundary-repair-sha.txt').write_text(sha+'\n');(e/'boundary-final-source-identities.json').write_text(json.dumps({'sha':sha,'files':{p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files}},indent=2)+'\n');print(sha);print(records[-1]['stdout'])
