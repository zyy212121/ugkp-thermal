from pathlib import Path
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018');p=r/'validation/tests/fixtures/chmt_audit_overflow.cpp';s=p.read_text().replace('out.temperature==300&&out.thickness==1000','std::abs(out.temperature-300)<1e-10&&std::abs(out.thickness-1000)<1e-10').replace('d.warnings[0].count==0&&out.temperature==300','d.warnings[0].count==0&&std::abs(out.temperature-300)<1e-10');needle='''  ModelConfig model;model.physics=p;HostState state;''';replacement='''  // Both component inventories and physical caloric/density results stay finite;
  // only their optional total-inventory audit exceeds binary64's range.
  auto largePhysics=p;for(auto& species:largePhysics.species){species.R=1e-305;species.cp0=1e-304;}
  GasQ large;large.mass=1e308;large.species[0]=large.species[1]=large.mass;large.energy=5.4e6;GasPrimitive largeOut;
  assert(recoverGas(large,1e308,largePhysics,largeOut,nullptr,3));assert(!d.fatalClaim&&d.warnings[0].count==1);assert(std::abs(largeOut.temperature-300)<1e-10&&largeOut.rho==1);
  reset(d,8,99,4,.25);
  ModelConfig model;model.physics=p;HostState state;'''
assert s.count(needle)==1;s=s.replace(needle,replacement);p.write_text(s)
