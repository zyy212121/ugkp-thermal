from pathlib import Path
import json,os,subprocess
E=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt')
t=(E/'independent-native.cpp').read_text().replace('int main(){','int main(int argc,char** argv){')
t=t.replace('chmt::ExchangePacket p;p.gasCell=p.solidCell=0;p.energy=p.conductive=bv;', '''chmt::ExchangePacket p;p.gasCell=p.solidCell=0;
 if(argc!=2)return 2;
 volatile double a=0x1.be208898a7384p+1023,b=0x1.077ddd9d631eep+1021;
 t.relativeEnergy=0;t.absoluteEnergy=0;
 if(argv[1][0]=='a'){p.conductive=a;p.advective=b;p.energy=0;}
 else {p.conductive=a;p.energy=-b;}
''')
(E/'independent-add-native.cpp').write_text(t)
cmd=json.loads((E/'independent-native-commands.json').read_text())[0]['command']
cmd=[x.replace('/independent-native.cpp','/independent-add-native.cpp').replace('/independent-native','/independent-add-native') for x in cmd]
# The two replacements above keep the source stem unchanged after its suffix replacement.
cmd=[x.replace('independent-add-add-native','independent-add-native') for x in cmd]
records=[]
def run(command,log,env=None):
 c=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
 (E/log).write_text(c.stdout);records.append({'command':command,'exit_code':c.returncode,'log':log});return c.returncode
if run(cmd,'independent-add-native-build.log')==0:
 for mode in ['add','difference']:
  for warnings in ['1','0']:
   env=dict(os.environ,FOAM_SIGFPE='1',UGKP_DIAGNOSTIC_WARNINGS=warnings,WM_PROJECT_DIR='/opt/openfoam10',FOAM_ETC='/opt/openfoam10/etc',LD_LIBRARY_PATH='/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib:/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib/openmpi-system')
   run([str(E/'independent-add-native'),mode],'independent-native-'+mode+'-warnings-'+warnings+'.log',env)
   records[-1]['environment']={k:env[k] for k in ['FOAM_SIGFPE','UGKP_DIAGNOSTIC_WARNINGS','WM_PROJECT_DIR','FOAM_ETC','LD_LIBRARY_PATH']}
(E/'independent-add-native-commands.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
