from pathlib import Path
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018')
p=r/'validation/tests/fixtures/chmt_audit_overflow.cpp';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(r'''#include "coupling/ExchangeLedger.H"
#include "io/CoupledOutput.H"
#include <cassert>
#include <cfenv>
#include <cmath>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#ifdef CHMT_NATIVE_FOAM
#include "DiagnosticsFoam.H"
#include "sigFpe.H"
#endif
using namespace chmt;
using namespace ugkp::diagnostics;
PhysicsConfig physics(DeviceContext& d){PhysicsConfig p;p.diagnostics=&d;p.tolerances.diagnostics=&d;
 for(int s=0;s<Ns;++s){p.species[s].R=287;p.species[s].cp0=1000;p.species[s].Tmin=200;p.species[s].Tmax=4000;}
 p.liquid.rho=1e305;p.liquid.cp0=1e-305;p.liquid.Tmin=1;p.liquid.Tmax=1000;return p;}
void show(DeviceContext& d){
#ifdef CHMT_NATIVE_FOAM
 dispatch(takeSnapshot(d,{{3812,"applications/CHMT/materials/Thermodynamics.H","recoverFilm",1,"film inventory audit"},{4302,"applications/CHMT/coupling/ExchangeLedger.C","validatePacketMath",1,"packet conservation audit"},{3858,"applications/CHMT/materials/Thermodynamics.H","recoverGas",1,"gas physical state"}},"native CHMT helper"),makeFoamSink());
#endif
}
int main(int argc,char** argv){assert(argc==2);const std::string mode=argv[1];
#ifdef CHMT_NATIVE_FOAM
 Foam::sigFpe trap;trap.set(true);assert((fegetexcept()&(FE_OVERFLOW|FE_DIVBYZERO|FE_INVALID))==(FE_OVERFLOW|FE_DIVBYZERO|FE_INVALID));
#endif
 DeviceContext d{};reset(d,8,99,4,.25);auto p=physics(d);DeviceStatus status{};
 if(mode=="film"){
  FilmQ q;q.mass=1e308;q.species[0]=q.species[1]=q.mass;q.enthalpy=3e5;const auto before=q;FilmAux out;
  assert(recoverFilm(q,1,0,p,out,&status,7));assert(out.temperature==300&&out.thickness==1000);assert(!d.fatalClaim&&d.warnings[0].count==1&&status.code==0);assert(q.mass==before.mass&&q.enthalpy==before.enthalpy&&q.species[1]==before.species[1]);show(d);
  reset(d,8,99,4,.25);q.species[1]=0;assert(recoverFilm(q,1,0,p,out,&status,7));assert(!d.fatalClaim&&d.warnings[0].count==0&&out.temperature==300);
  q.species[0]=std::numeric_limits<Real>::infinity();assert(!recoverFilm(q,1,0,p,out,&status,7));
 }else if(mode=="packet"){
  ExchangePacket q;q.gasCell=q.solidCell=0;const Real big=std::numeric_limits<Real>::max()*.75;
  q.conductive=big;q.advective=-big;q.pressureWork=big;q.viscousWork=-big;const auto before=q;
  assert(validatePacketMath(q,p.tolerances,&status));assert(!d.fatalClaim&&d.warnings[0].count==1);assert(q.conductive==before.conductive&&q.advective==before.advective);show(d);
  reset(d,8,99,4,.25);q.conductive=2;q.advective=-2;q.pressureWork=q.viscousWork=0;assert(validatePacketMath(q,p.tolerances,&status));assert(!d.fatalClaim&&d.warnings[0].count==0);
  reset(d,8,99,4,.25);q.conductive=q.advective=big;q.pressureWork=q.viscousWork=-big;assert(validatePacketMath(q,p.tolerances,&status));assert(!d.fatalClaim&&d.warnings[0].count==1);
  reset(d,8,99,4,.25);q.conductive=q.advective=q.pressureWork=q.viscousWork=0;q.species[0]=big;q.species[1]=-big;assert(validatePacketMath(q,p.tolerances,&status));assert(!d.fatalClaim&&d.warnings[0].count==1);
  q.species[0]=std::numeric_limits<Real>::infinity();assert(!validatePacketMath(q,p.tolerances,&status));assert(d.firstFatal.code==Code::NonFinite);
 }else if(mode=="gas"){
  ModelConfig model;model.physics=p;HostState state;state.gas.resize(2);state.gasMesh.volumes={1,1};
  for(auto& q:state.gas){q.mass=1;q.species[0]=1;q.energy=(1000-287)*300;}
  std::ostringstream good;std::string error;assert(chmt::io::writeAcceptedGasFields(good,state,model,error));assert(!d.fatalClaim);
  reset(d,8,99,4,.25);state.gasMesh.volumes[1]=1e-310;std::ostringstream bad;assert(!chmt::io::writeAcceptedGasFields(bad,state,model,error));assert(d.fatalClaim&&d.firstFatal.code==Code::NonFinite);assert(std::isinf(d.firstFatal.observed)&&d.firstFatal.observed>0);assert(d.firstFatal.entityKind==EntityKind::Cell&&d.firstFatal.entityIndex==1&&d.firstFatal.quantityId==Quantity::Density);assert(d.firstFatal.step==4&&d.firstFatal.simulationTime==.25);
#ifdef CHMT_NATIVE_FOAM
 Foam::FatalError.throwExceptions();bool caught=false;try{show(d);}catch(const Foam::error& e){caught=true;assert(e.message().find("observed=inf")!=std::string::npos);assert(e.message().find("entity=1")!=std::string::npos);assert(e.message().find("density")!=std::string::npos);}assert(caught);
#endif
 }else return 2;
 std::cout<<"verified "<<mode<<"\n";
}
''')
p=r/'validation/tests/test_chmt_audit_overflow_followup.py'
p.write_text(r'''"""Real material/caller overflow cases, including OpenFOAM's enabled FPE traps."""
import os
import pathlib
import subprocess
import pytest
from validation.tools.paths import SOURCE_ROOT

@pytest.fixture(scope="module")
def helper(tmp_path_factory):
    folder=tmp_path_factory.mktemp("chmt-audit-helper");exe=folder/"helper"
    cmd=["g++","-std=c++17","-O2","-DUGKWP_GAS_SPECIES=2","-I"+str(SOURCE_ROOT/"applications/CHMT"),"-I"+str(SOURCE_ROOT/"common"),str(SOURCE_ROOT/"validation/tests/fixtures/chmt_audit_overflow.cpp"),"-o",str(exe)]
    subprocess.run(cmd,check=True,capture_output=True,text=True);return exe

@pytest.mark.parametrize("mode",["film","gas","packet"])
def test_real_helper_overflow_and_normal_controls(helper,mode):
    result=subprocess.run([str(helper),mode],capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr

@pytest.fixture(scope="module")
def native(tmp_path_factory):
    project=pathlib.Path(os.environ.get("WM_PROJECT_DIR","/opt/openfoam10"))
    libbin=pathlib.Path(os.environ.get("FOAM_LIBBIN",str(project/"platforms/linux64GccDPInt32Opt/lib")))
    mpi=os.environ.get("FOAM_MPI","openmpi-system")
    if not (project/"src/OpenFOAM/lnInclude/error.H").exists() or not (libbin/"libOpenFOAM.so").exists():
        pytest.skip("native OpenFOAM10 headers/libraries unavailable")
    folder=tmp_path_factory.mktemp("chmt-audit-native");exe=folder/"native"
    cmd=["g++","-std=c++17","-O2","-pthread","-DWM_DP","-DWM_LABEL_SIZE=32","-DUGKWP_GAS_SPECIES=2","-DCHMT_NATIVE_FOAM","-I"+str(SOURCE_ROOT/"applications/CHMT"),"-I"+str(SOURCE_ROOT/"common"),"-I"+str(project/"src/OpenFOAM/lnInclude"),"-I"+str(project/"src/OSspecific/POSIX/lnInclude"),str(SOURCE_ROOT/"validation/tests/fixtures/chmt_audit_overflow.cpp"),"-L"+str(libbin),"-L"+str(libbin/mpi),"-lOpenFOAM","-lPstream","-o",str(exe)]
    subprocess.run(cmd,check=True,capture_output=True,text=True)
    return exe,libbin,mpi

@pytest.mark.parametrize("mode",["film","gas","packet"])
@pytest.mark.parametrize("warnings",["1","0"])
def test_native_foam_fpe_and_dispatch(native,mode,warnings):
    exe,libbin,mpi=native;env=os.environ.copy();env.update(FOAM_SIGFPE="1",UGKP_DIAGNOSTIC_WARNINGS=warnings)
    env["LD_LIBRARY_PATH"]=str(libbin)+":"+str(libbin/mpi)+":"+env.get("LD_LIBRARY_PATH","")
    result=subprocess.run([str(exe),mode],capture_output=True,text=True,env=env)
    assert result.returncode==0,result.stdout+result.stderr
    assert "verified "+mode in result.stdout
    if mode!="gas":
        assert ("historical representative sample" in result.stderr+result.stdout)==(warnings=="1")
''')
'''
'''
print('tests written')
