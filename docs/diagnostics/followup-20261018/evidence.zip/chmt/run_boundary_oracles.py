import pathlib,subprocess,json
r=pathlib.Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018');e=pathlib.Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt');records=[]
for src,label in [('product-boundary-oracle.cpp','boundary-product-green'),('independent-add-boundary.cpp','boundary-add-green'),('independent-arithmetic.cpp','boundary-density-product-green')]:
 cmd=['g++','-std=c++17','-O2','-I'+str(r/'applications/CHMT'),str(e/src),'-o',str(e/label)];p=subprocess.run(cmd,text=True,capture_output=True);records.append({'command':cmd,'exit':p.returncode});assert p.returncode==0,p.stderr;cmd=[str(e/label)];p=subprocess.run(cmd,text=True,capture_output=True);(e/(label+'.log')).write_text(p.stdout+p.stderr);records.append({'command':cmd,'exit':p.returncode});print(label,p.returncode,p.stdout);assert p.returncode==0,p.stdout+p.stderr
(e/'boundary-oracle-commands.json').write_text(json.dumps(records,indent=2)+'\n')
