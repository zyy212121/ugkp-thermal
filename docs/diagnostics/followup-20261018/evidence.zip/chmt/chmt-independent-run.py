from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-20261018')
E=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt')
W=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work')
shutil.copy2(W/'chmt-independent-native.cpp',E/'independent-native.cpp')
header=R/'applications/CHMT/core/AuditArithmetic.H'
shutil.copy2(header,E/'independent-pre-fix-AuditArithmetic.H')
cmd=['g++','-std=c++17','-O2','-g','-pthread','-DWM_DP','-DWM_LABEL_SIZE=32','-DUGKWP_GAS_SPECIES=2',
 '-I'+str(E),'-I'+str(R/'applications/CHMT'),'-I'+str(R/'applications/CHMT/core'),'-I'+str(R/'common'),
 '-I/opt/openfoam10/src/OpenFOAM/lnInclude','-I/opt/openfoam10/src/OSspecific/POSIX/lnInclude',str(E/'independent-native.cpp'),
 '-L/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib','-L/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib/openmpi-system',
 '-lOpenFOAM','-lPstream','-o',str(E/'independent-native')]
records=[]
def execute(cmd,log,env=None):
    c=subprocess.run(cmd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (E/log).write_text(c.stdout);records.append({'command':cmd,'exit_code':c.returncode,'log':log});return c.returncode
code=execute(cmd,'independent-native-build.log')
if code==0:
 for warnings in ['1','0']:
  env=dict(os.environ,FOAM_SIGFPE='1',UGKP_DIAGNOSTIC_WARNINGS=warnings,WM_PROJECT_DIR='/opt/openfoam10',FOAM_ETC='/opt/openfoam10/etc',LD_LIBRARY_PATH='/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib:/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib/openmpi-system')
  execute([str(E/'independent-native')],'independent-native-warnings-'+warnings+'.log',env)
  records[-1]['environment']={k:env[k] for k in ['FOAM_SIGFPE','UGKP_DIAGNOSTIC_WARNINGS','WM_PROJECT_DIR','FOAM_ETC','LD_LIBRARY_PATH']}
records.append({'captured_pre_fix_AuditArithmetic_sha256':hashlib.sha256((E/'independent-pre-fix-AuditArithmetic.H').read_bytes()).hexdigest()})
(E/'independent-native-commands.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2));print('\n'.join((E/'independent-native-warnings-1.log').read_text().splitlines()[-18:]) if code==0 else (E/'independent-native-build.log').read_text())
