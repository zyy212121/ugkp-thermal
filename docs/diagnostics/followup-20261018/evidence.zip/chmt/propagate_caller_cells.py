from pathlib import Path
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018')
p=r/'applications/CHMT/ablation/WallClosureHost.H';s=p.read_text().replace('recoverGas(state.gas[c],state.gasMesh.volumes[c],p,w)','recoverGas(state.gas[c],state.gasMesh.volumes[c],p,w,nullptr,c)');p.write_text(s)
p=r/'applications/CHMT/gpu/SharedMixtureStorage.H';s=p.read_text().replace('recoverGas(q,volume,validated.physics,primitive)','recoverGas(q,volume,validated.physics,primitive,nullptr,static_cast<int>(c))');p.write_text(s)
