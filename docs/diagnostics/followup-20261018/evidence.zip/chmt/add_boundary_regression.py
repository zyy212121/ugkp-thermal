from pathlib import Path
p=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018/validation/tests/fixtures/chmt_audit_overflow.cpp');s=p.read_text();needle='''  q.species[0]=std::numeric_limits<Real>::infinity();assert(!validatePacketMath(q,p.tolerances,&status));assert(d.firstFatal.code==Code::NonFinite);''';replacement='''  // Rounded max/b and max-b bounds are insufficient at the last ULP.
  reset(d,8,99,4,.25);q=ExchangePacket{};q.gasCell=q.solidCell=0;q.energy=q.conductive=0x1.76c2887c5d2bp+0;auto boundary=p.tolerances;boundary.absoluteEnergy=0;boundary.relativeEnergy=0x1.5dbfd0344dbaep+1023;
  assert(validatePacketMath(q,boundary,&status));assert(!d.fatalClaim&&d.warnings[0].count==1);
  const Real largest=std::numeric_limits<Real>::max();assert(auditProduct(largest/2,2)==largest);assert(auditProduct(1,largest)==largest);assert(auditProduct(largest,1)==largest);
  reset(d,8,99,4,.25);q.energy=largest;q.conductive=0x1.ea667e2e0c0d1p+1020;q.advective=0x1.c2b3303a3e7e5p+1023;
  assert(validatePacketMath(q,p.tolerances,&status));assert(!d.fatalClaim&&d.warnings[0].count==0);
  reset(d,8,99,4,.25);q.energy=0;q.conductive=std::nextafter(largest,0.);q.advective=std::ldexp(1.5,971);
  assert(validatePacketMath(q,p.tolerances,&status));assert(!d.fatalClaim&&d.warnings[0].count==1);
  assert(auditAdd(-0x1.ea667e2e0c0d1p+1020,-0x1.c2b3303a3e7e5p+1023)==-largest);
  assert(auditDifference(0x1.ea667e2e0c0d1p+1020,-0x1.c2b3303a3e7e5p+1023)==largest);
  q.species[0]=std::numeric_limits<Real>::infinity();assert(!validatePacketMath(q,p.tolerances,&status));assert(d.firstFatal.code==Code::NonFinite);''';assert s.count(needle)==1;s=s.replace(needle,replacement);p.write_text(s)
