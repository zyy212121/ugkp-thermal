#include <cmath>
#include <cstdio>
#include <limits>
#include <cstdint>
#include <cstring>
#include <cfenv>
#include <initializer_list>
int main(){
 const double max=std::numeric_limits<double>::max();unsigned falseNegative=0,falsePositive=0,count=0;
 auto check=[&](double volume){
  const double threshold=max*volume;
  for(double mass:{std::nextafter(threshold,0.),threshold,std::nextafter(threshold,max)}){
   volatile double m=mass,v=volume;const bool predicted=volume<1&&mass>max*volume;
   std::feclearexcept(FE_ALL_EXCEPT);volatile double actual=m/v;
   const bool traps=std::fetestexcept(FE_OVERFLOW|FE_DIVBYZERO|FE_INVALID)!=0;
   if(!predicted&&(!std::isfinite(actual)||traps)){
    if(falseNegative++<5)std::printf("density falseNegative mass=%a volume=%a threshold=%a actual=%a traps=%d\n",mass,volume,threshold,double(actual),traps);
   }
   if(predicted&&std::isfinite(actual)){
    if(falsePositive++<5)std::printf("density falsePositive mass=%a volume=%a threshold=%a actual=%a\n",mass,volume,threshold,double(actual));
   }
   ++count;
  }
 };
 std::uint64_t random=0x2873976578abcdefULL;
 for(int i=0;i<1000000;++i){
  random^=random<<13;random^=random>>7;random^=random<<17;
  std::uint64_t bits=((random%1023ULL)<<52)|(random&0x000fffffffffffffULL);
  double volume;std::memcpy(&volume,&bits,8);if(volume>0)check(volume);
 }
 for(double volume:{std::numeric_limits<double>::denorm_min(),std::numeric_limits<double>::min(),.5,std::nextafter(1.,0.),.25,1e-310,1e-300})check(volume);
 std::printf("roundMode=%d FE_TONEAREST=%d densityBoundaryCases=%u falseNegative=%u falsePositive=%u\n",std::fegetround(),FE_TONEAREST,count,falseNegative,falsePositive);
 return falseNegative||falsePositive?1:0;
}
