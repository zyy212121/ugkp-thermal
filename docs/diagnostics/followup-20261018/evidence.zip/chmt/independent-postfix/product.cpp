#include "core/AuditArithmetic.H"
#include "coupling/ExchangeLedger.H"
#include "DiagnosticsFoam.H"
#include "sigFpe.H"
#include <cfenv>
#include <cstdio>
int main(){
 Foam::sigFpe trap;trap.set(true);
 if((fegetexcept()&(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))!=(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))return 3;
 volatile double av=0x1.5dbfd0344dbaep+1023,bv=0x1.76c2887c5d2bp+0;
 ugkp::diagnostics::DeviceContext d{};
 chmt::Tolerances t;t.diagnostics=&d;t.absoluteEnergy=0;t.relativeEnergy=av;
 chmt::ExchangePacket p;p.gasCell=p.solidCell=0;p.energy=p.conductive=bv;
 chmt::DeviceStatus status{};
 std::fprintf(stderr,"Before actual validatePacketMath: relative=%a scale=%a\n",double(av),double(bv));std::fflush(stderr);
 const bool ok=chmt::validatePacketMath(p,t,&status);
 std::fprintf(stderr,"After: ok=%d warning=%u fatal=%u\n",ok,d.warnings[0].count,d.fatalClaim);
 return !ok||d.fatalClaim?1:0;
}
