from pathlib import Path
import subprocess,json,hashlib
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018');e=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt');files=['applications/CHMT/core/AuditArithmetic.H','applications/CHMT/coupling/ExchangeLedger.C','applications/CHMT/materials/Thermodynamics.H','applications/CHMT/io/CoupledOutput.H','applications/CHMT/ablation/WallClosureHost.H','applications/CHMT/gpu/SharedMixtureStorage.H','validation/tests/fixtures/chmt_audit_overflow.cpp','validation/tests/test_chmt_audit_overflow_followup.py'];commands=[]
for cmd in [['git','diff','--check'],['git','diff','--stat']]:
 p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);commands.append({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,p.stderr
(e/'final.patch').write_text(subprocess.check_output(['git','diff'],cwd=r,text=True));manifest={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};(e/'precommit-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
cmd=['git','add',*files];p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);commands.append({'command':cmd,'exit':p.returncode});assert p.returncode==0,p.stderr
cmd=['git','commit','-m','Fix CHMT diagnostic overflow and gas density error provenance'];p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);commands.append({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,p.stderr
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();(e/'commit-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(e/'repair-sha.txt').write_text(sha+'\n');print(sha);print(p.stdout)
