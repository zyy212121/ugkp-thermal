#include "core/AuditArithmetic.H"
#include <cfenv>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <initializer_list>
bool bitsame(double a,double b){std::uint64_t x,y;std::memcpy(&x,&a,8);std::memcpy(&y,&b,8);return x==y;}
int main(){
 unsigned long long random=0x2873976578abcdefULL;
 const double max=std::numeric_limits<double>::max();
 unsigned addTrap=0,differenceTrap=0,finiteChanged=0,total=0;
 auto test=[&](double a,double b){
  volatile double av=a,bv=b;
  const double direct=av+bv;
  std::feclearexcept(FE_ALL_EXCEPT);
  volatile double sum=chmt::auditAdd(av,bv);
  if(std::fetestexcept(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO)){
   if(addTrap++<5)std::printf("auditAdd trap a=%a b=%a result=%a\n",a,b,double(sum));
  }
  if(std::isfinite(direct)&&!bitsame(direct,sum)){
   if(finiteChanged++<5)std::printf("auditAdd finite changed a=%a b=%a direct=%a audit=%a\n",a,b,direct,double(sum));
  }
  std::feclearexcept(FE_ALL_EXCEPT);
  volatile double difference=chmt::auditDifference(av,-bv);
  if(std::fetestexcept(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO)){
   if(differenceTrap++<5)std::printf("auditDifference trap a=%a b=%a result=%a\n",a,-b,double(difference));
  }
  if(std::isfinite(direct)&&!bitsame(direct,difference)){
   if(finiteChanged++<5)std::printf("auditDifference finite changed a=%a b=%a direct=%a audit=%a\n",a,-b,direct,double(difference));
  }
  ++total;
 };
 for(int i=0;i<1000000;++i){
  random^=random<<13;random^=random>>7;random^=random<<17;
  std::uint64_t bits=(random%2047ULL)<<52|(random&0x000fffffffffffffULL);
  double b;std::memcpy(&b,&bits,sizeof b);
  const double threshold=max-b;
  for(double a:{std::nextafter(threshold,0.),threshold,std::nextafter(threshold,max)}){
   test(a,b);test(-a,-b);
  }
 }
 const double halfUlp=std::ldexp(1.,970);
 for(double b:{std::nextafter(halfUlp,0.),halfUlp,std::nextafter(halfUlp,max),halfUlp*.5,halfUlp*2,max}){
  test(max,b);test(-max,-b);test(max-b,b);test(-max+b,-b);
 }
 test(std::nextafter(max,0.),1.5*std::ldexp(1.,971));
 for(double a:{double(INFINITY),double(-INFINITY),double(NAN),0.})for(double b:{double(INFINITY),double(-INFINITY),double(NAN),0.}){
  // Only audit arithmetic: generated unrepresentable-marker combinations.
  std::feclearexcept(FE_ALL_EXCEPT);volatile double sum=chmt::auditAdd(a,b);(void)sum;
  if(std::fetestexcept(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))++addTrap;
  std::feclearexcept(FE_ALL_EXCEPT);volatile double difference=chmt::auditDifference(a,b);(void)difference;
  if(std::fetestexcept(FE_OVERFLOW|FE_INVALID|FE_DIVBYZERO))++differenceTrap;
 }
 std::printf("totalFiniteBoundaryPairs=%u addTraps=%u differenceTraps=%u finiteResultChanges=%u\n",total,addTrap,differenceTrap,finiteChanged);
 return addTrap||differenceTrap||finiteChanged?1:0;
}
