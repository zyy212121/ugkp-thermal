from pathlib import Path
import json,shutil,subprocess
E=Path('/mnt/d/tempt/ugkp-pr19-followup-20261018/chmt');P=E/'independent-postfix'
W=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-16/1-uniform-work-accepted-source-manifest/work')
R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018')
shutil.copy2(W/'chmt-independent-density.cpp',P/'density-boundary.cpp')
records=[]
for name,source in [('density',P/'density-boundary.cpp'),('product-finite-bits',E/'product-boundary-oracle.cpp')]:
 command=['g++','-std=c++17','-O2','-DUGKWP_GAS_SPECIES=2','-I'+str(R/'applications/CHMT'),str(source),'-o',str(P/name)]
 for label,cmd in [('build',command),('run',[str(P/name)])]:
  c=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(P/(name+'-'+label+'.log')).write_text(c.stdout)
  records.append({'command':cmd,'exit_code':c.returncode,'log':name+'-'+label+'.log'})
  if c.returncode and label=='build':break
print(json.dumps(records,indent=2))
(P/'extended-commands.json').write_text(json.dumps(records,indent=2)+'\n')
print((P/'density-run.log').read_text());print((P/'product-finite-bits-run.log').read_text())
