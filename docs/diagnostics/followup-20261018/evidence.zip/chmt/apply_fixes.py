from pathlib import Path
r=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-followup-chmt-20261018')
p=r/'applications/CHMT/core/AuditArithmetic.H';p.write_text('''#ifndef CHMT_CORE_AUDITARITHMETIC_H
#define CHMT_CORE_AUDITARITHMETIC_H
#include "Types.H"
namespace chmt {
// Diagnostic reductions must not raise OpenFOAM's enabled overflow/invalid traps.
// An infinity/NaN here describes an unrepresentable audit, never a repaired state.
CHMT_HD inline Real auditAdd(Real a,Real b) {
    const Real bound=std::numeric_limits<Real>::max();
    if(!finite(a)||!finite(b)) {
        if(a!=a||b!=b||(!finite(a)&&!finite(b)&&((a<0)!=(b<0))))return undefinedValue();
        return !finite(a)?a:b;
    }
    if(b>0&&a>bound-b)return std::numeric_limits<Real>::infinity();
    if(b<0&&a<-bound-b)return -std::numeric_limits<Real>::infinity();
    return a+b;
}
CHMT_HD inline Real auditDifference(Real a,Real b) { return auditAdd(a,-b); }
CHMT_HD inline Real auditProduct(Real a,Real b) {
    if(!finite(a)||!finite(b))return undefinedValue();
    const Real aa=absValue(a),bb=absValue(b);
    if(bb>1&&aa>std::numeric_limits<Real>::max()/bb)
        return ((a<0)!=(b<0))?-std::numeric_limits<Real>::infinity():std::numeric_limits<Real>::infinity();
    return a*b;
}
CHMT_HD inline Real auditTolerance(Real absolute,Real relative,Real scale) {
    return auditAdd(absolute,auditProduct(relative,scale));
}
}
#endif
''')
p=r/'applications/CHMT/materials/Thermodynamics.H';s=p.read_text();s=s.replace('#include "core/Configuration.H"','#include "core/Configuration.H"\n#include "core/AuditArithmetic.H"');s=s.replace('const Real residual=a-b,tolerance=absolute+relative*maxValue(absValue(a),absValue(b));','const Real residual=auditDifference(a,b),tolerance=auditTolerance(absolute,relative,maxValue(absValue(a),absValue(b)));');s=s.replace('    if(!finite(q.mass)||q.mass<=0)return physicalFailure(q.mass,-1,ugkp::diagnostics::Quantity::Unspecified);','    if(!finite(q.mass)||q.mass<=0)return physicalFailure(q.mass,-1,ugkp::diagnostics::Quantity::Unspecified);\n    // Diagnose a true density overflow before executing the trapping division.\n    if(volume<1&&q.mass>std::numeric_limits<Real>::max()*volume)\n        return physicalFailure(std::numeric_limits<Real>::infinity(),-1,ugkp::diagnostics::Quantity::Density);');s=s.replace('sum+=m;if(m==0)continue;','sum=auditAdd(sum,m);if(m==0)continue;',1);s=s.replace('    if(!finite(sum))return failStatus(status,ErrorCode::Nonfinite,index,sum,ErrorLocation::Cell);\n','',1);s=s.replace('3811,sum-q.mass,0','3811,auditDifference(sum,q.mass),0');s=s.replace('    if(!finite(candidate.rho)||!finite(candidate.pressure)||!finite(candidate.soundSpeed))\n        return failStatus(status,ErrorCode::Nonfinite,index,T,ErrorLocation::Cell);','    if(!finite(candidate.rho))return physicalFailure(candidate.rho,-1,ugkp::diagnostics::Quantity::Density);\n    if(!finite(candidate.pressure))return physicalFailure(candidate.pressure,-1,ugkp::diagnostics::Quantity::Pressure);\n    if(!finite(candidate.soundSpeed))return physicalFailure(candidate.soundSpeed,-1,ugkp::diagnostics::Quantity::Velocity);');s=s.replace('            sum+=q.mass*fraction;\n        }else sum+=q.species[s];','            sum=auditAdd(sum,q.mass*fraction);\n        }else sum=auditAdd(sum,q.species[s]);');s=s.replace('    if(!finite(sum))return failStatus(status,ErrorCode::Nonfinite,index,sum,ErrorLocation::Face);\n','',1);s=s.replace('3812,sum-q.mass,0','3812,auditDifference(sum,q.mass),0');p.write_text(s)
p=r/'applications/CHMT/coupling/ExchangeLedger.C';s=p.read_text().replace('#include "ExchangeLedger.H"','#include "ExchangeLedger.H"\n#include "core/AuditArithmetic.H"');s=s.replace('const Real residual=value-target;','const Real residual=auditDifference(value,target);').replace('const Real tolerance=absolute+relative*maxValue(scale,maxValue(absValue(value),absValue(target)));','const Real tolerance=auditTolerance(absolute,relative,maxValue(scale,maxValue(absValue(value),absValue(target))));');s=s.replace('sum+=p.species[s];scale+=absValue(p.species[s]);donor+=p.pore[s];donorScale+=absValue(p.pore[s]);','sum=auditAdd(sum,p.species[s]);scale=auditAdd(scale,absValue(p.species[s]));donor=auditAdd(donor,p.pore[s]);donorScale=auditAdd(donorScale,absValue(p.pore[s]));');s=s.replace('donor+=p.condensed[c];donorScale+=absValue(p.condensed[c]);','donor=auditAdd(donor,p.condensed[c]);donorScale=auditAdd(donorScale,absValue(p.condensed[c]));');s=s.replace('const Real parts=p.conductive+p.advective+p.pressureWork+p.viscousWork+p.radiation;','const Real parts=auditAdd(auditAdd(auditAdd(auditAdd(p.conductive,p.advective),p.pressureWork),p.viscousWork),p.radiation);');s=s.replace('const Real partScale=absValue(p.conductive)+absValue(p.advective)+absValue(p.pressureWork)+absValue(p.viscousWork)+absValue(p.radiation);','const Real partScale=auditAdd(auditAdd(auditAdd(auditAdd(absValue(p.conductive),absValue(p.advective)),absValue(p.pressureWork)),absValue(p.viscousWork)),absValue(p.radiation));');s=s.replace('sum+=q.species[s];','sum=auditAdd(sum,q.species[s]);');s=s.replace('mass+=q.condensed[c];','mass=auditAdd(mass,q.condensed[c]);').replace('mass+=q.pore[s];','mass=auditAdd(mass,q.pore[s]);');p.write_text(s)
p=r/'applications/CHMT/io/CoupledOutput.H';s=p.read_text().replace('recoverGas(state.gas[c],state.gasMesh.volumes[c],model.physics,primitive[c])','recoverGas(state.gas[c],state.gasMesh.volumes[c],model.physics,primitive[c],nullptr,static_cast<int>(c))');p.write_text(s)
print('CHMT scoped fixes applied')
