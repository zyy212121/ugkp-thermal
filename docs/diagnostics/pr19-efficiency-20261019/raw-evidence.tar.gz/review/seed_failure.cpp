
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

#include "common/gasTransport/GasBoundaryLayerModelState.H"
#include <thread>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <iomanip>
struct Barrier {
 std::mutex mutex;std::condition_variable cv;int size,arrived=0,generation=0;
 explicit Barrier(int n):size(n){}
 void wait(){std::unique_lock<std::mutex> lock(mutex);const int g=generation;
  if(++arrived==size){arrived=0;++generation;cv.notify_all();}else cv.wait(lock,[&]{return generation!=g;});}
};
struct TeamStorage {Barrier barrier;bool flags[32]{},flag=false;double scalar=0;explicit TeamStorage(int n):barrier(n){}};
struct CpuTeam {
 TeamStorage& storage;int lane,lanes;
 int rank()const{return lane;}int size()const{return lanes;}bool leader()const{return lane==0;}
 void sync()const{storage.barrier.wait();}
 bool broadcast(bool v)const{if(leader())storage.flag=v;sync();v=storage.flag;sync();return v;}
 double broadcast(double v)const{if(leader())storage.scalar=v;sync();v=storage.scalar;sync();return v;}
 bool all(bool v)const{storage.flags[lane]=v;sync();if(leader()){storage.flag=true;for(int i=0;i<lanes;++i)storage.flag=storage.flag&&storage.flags[i];}sync();v=storage.flag;sync();return v;}
};

#include <cstring>
int main(){
 using namespace ugkwp::gaswall::detail;
 Model m; double coef[28]{};
 for(int species=0;species<2;++species){m.sp[species].model=SpeciesThermoModel::NASA7;m.sp[species].coefficientOffset=14*species;m.sp[species].midTemperature=1000;
  for(int branch=0;branch<2;++branch){double* b=coef+14*species+7*branch;b[0]=159000;b[1]=-800;b[2]=1;}}
 m.in.model.thermo.coefficients=coef;m.in.model.thermo.coefficientCount=28;
 m.in.matching.k=.5;m.in.matching.omega=200;m.in.integrateOwnerKSource=false;
 WallModelConfig<double> c;c.nodes=7;c.stretch=1;c.enableSst=true;
 LayerContext<double,2> ctx;assert(makeContext(m.in,c,ctx));
 WallWorkspace<double,2,7> original;
 for(int i=0;i<7;++i){double f=double(i)/6;original.y[i]=m.in.matchingDistance*f;
  original.state[i][0]=f*ctx.edgeU[0];original.state[i][1]=f*ctx.edgeU[1];original.state[i][2]=200*f;original.state[i][3]=.3;
  original.state[i][4]=std::sqrt(.5)*f;original.state[i][5]=f/std::sqrt(200.);
  for(int j=0;j<8;++j)original.seed[i][j]=-777;}
 auto serial=original,parallel=original;
 const bool reference=seedSstLayer(m.in,c,ctx,serial);
 TeamStorage storage(7);std::vector<std::thread> threads;bool success[7]{};
 for(int lane=0;lane<7;++lane)threads.emplace_back([&,lane]{success[lane]=seedSstLayer(m.in,c,ctx,parallel,CpuTeam{storage,lane,7});});
 for(auto& t:threads)t.join();
 assert(!reference);for(bool ok:success)assert(!ok);
 assert(std::memcmp(serial.state,parallel.state,sizeof serial.state)==0);
 std::cout<<"seed failure: all lanes false; state bitwise equal; changed coefficient nodes:";
 for(int i=0;i<7;++i)if(std::memcmp(serial.seed[i],parallel.seed[i],sizeof serial.seed[i])!=0)std::cout<<' '<<i;
 std::cout<<'\n';

 WallWorkspace<double,2,7> sw,pw;WallOutput<double,2> so,po;WallStatus ss,ps;
 std::memset(&so,0xA5,sizeof so);std::memset(&po,0xA5,sizeof po);const auto saved=so;
 ugkp::diagnostics::DeviceContext sd{},pd{};
 auto sin=m.in,pin=m.in;sin.diagnostics=&sd;pin.diagnostics=&pd;
 const bool sok=evaluateReactingWallLayerImpl(sin,c,sw,so,ss);
 TeamStorage publicStorage(7);threads.clear();
 for(int lane=0;lane<7;++lane)threads.emplace_back([&,lane]{success[lane]=evaluateReactingWallLayerImpl(pin,c,pw,po,ps,CpuTeam{publicStorage,lane,7});});
 for(auto& t:threads)t.join();
 assert(!sok);for(bool ok:success)assert(!ok);
 assert(std::memcmp(&so,&saved,sizeof so)==0&&std::memcmp(&po,&saved,sizeof po)==0);
 assert(std::memcmp(sw.state,pw.state,sizeof sw.state)==0);
 assert(sd.fatalClaim&&pd.fatalClaim&&sd.firstFatal.code==pd.firstFatal.code&&sd.firstFatal.sourceSiteId==pd.firstFatal.sourceSiteId&&sd.firstFatal.observed==pd.firstFatal.observed);
 std::cout<<"public layer: all lanes false; output unchanged; state bitwise equal; fatal site="<<pd.firstFatal.sourceSiteId<<" observed="<<pd.firstFatal.observed<<'\n';
}
