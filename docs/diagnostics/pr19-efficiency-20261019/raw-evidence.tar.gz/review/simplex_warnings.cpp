
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <limits>
using namespace ugkwp;
std::uint64_t rstate=0x19c0ffee;
double randomUnit(){rstate^=rstate<<13;rstate^=rstate>>7;rstate^=rstate<<17;return double(rstate>>11)/9007199254740992.;}
template<class R,int N> void probe(){
 SpeciesThermoData<R> species[N];R coef[3*N]{},grad[N]{},diff[N]{},flux[N]{};
 ugkp::diagnostics::DeviceContext diagnostics{};SpeciesThermoView<R,N> thermo;
 thermo.species=species;thermo.coefficients=coef;thermo.coefficientCount=3*N;thermo.diagnostics=&diagnostics;
 for(int j=0;j<N;++j){species[j].coefficientOffset=3*j;species[j].molarMass=R(.028);coef[3*j]=1000;diff[j]=R(1e-5);}
 R prior[N]{};prior[N-1]=1;double worst=0;
 for(int it=0;it<20000;++it){R state[N+4]{},Y[N],sum=0,enthalpy=0;
  for(int j=0;j<N-1;++j){state[3+j]=R(4*randomUnit()-2);if(it<8)state[3+j]=R((it%2?1:-1)*std::numeric_limits<R>::max()/R(2+it%3))*R(randomUnit());}
  assert((ugkwp::gaswall::detail::feasibleLayerComposition<R,N>(state)));
  for(int j=0;j<N-1;++j){assert(state[3+j]>=0&&state[3+j]<=1);sum+=state[3+j];Y[j]=state[3+j];}
  Y[N-1]=R(1)-sum;assert(Y[N-1]>=0&&Y[N-1]<=1);
  R mid[N];sum=0;for(int j=0;j<N;++j){mid[j]=(Y[j]+prior[j])/R(2);sum+=mid[j];prior[j]=Y[j];}
  worst=std::max(worst,double(std::abs(sum-R(1)))/std::numeric_limits<R>::epsilon());
  assert(correctedSpeciesDiffusion(mid,grad,R(1),diff,R(0),R(.8),R(300),thermo,flux,enthalpy));
 }
 assert(!diagnostics.fatalClaim);for(auto warning:diagnostics.warnings)assert(!warning.count);
 std::cout<<"N="<<N<<" bytes="<<sizeof(R)<<" samples=20000 max_sum_error_eps="<<worst<<" warnings=0\n";
}
int main(){probe<double,2>();probe<double,3>();probe<double,8>();probe<double,32>();probe<float,2>();probe<float,3>();probe<float,8>();probe<float,32>();}
