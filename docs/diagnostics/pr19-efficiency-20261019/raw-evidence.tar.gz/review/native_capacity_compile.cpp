// Runs unchanged production device functions serially on a host. Not CUDA execution.
#include <cmath>
using std::isfinite;
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include "GpuPrecisionTypes.H"
#include "CharacteristicMuscl.cuh"
#include "OpenFoamLimitedLinear.cuh"
#include "OpenFoamViscousFlux.cuh"
#include "OpenFoamWallFunctions.cuh"
#include "RiemannBoundaryState.cuh"
#include "RiemannGasFlux.cuh"
#include "GpuSstAlgebra.cuh"
#include "GpuLesAlgebra.cuh"
using Real=GpuReal;
using Time=double;
#define GPU_OPERATOR_REAL Real
#define GPU_OPERATOR_TIME Time
#define GPU_OPERATOR_R GPU_R
#define GPU_OPERATOR_TINY(x) GPU_R(1e-30)
#define __host__
#define __global__
#define __device__
#define __forceinline__ inline
// PTX traps are represented by process failure in this serial host emulator.
#define asm(...) std::abort()
struct ThreadIndex { int x=0; } blockIdx, threadIdx, blockDim;
constexpr Real OfSmall=GPU_R(2.22044604925031308085e-16);
constexpr Real OfVSmall=GPU_R(1e-30);
constexpr Real OfGreat=GPU_R(1.0)/OfSmall;
struct GasPrimDevice { Real rho,ux,uy,uz,p,T; };
#include "legacy_gas_fixture.hpp"
#ifdef LEGACY_REFERENCE
using DeviceState=LegacyGasFixture;
#else
// No application DeviceState definition: the actual operators must be generic.
#include "gasTransport/GasStateView.H"
#endif
#include "operators/clampMin.cuh"
#include "operators/clampRange.cuh"
#include "operators/linearScheduledValueDevice.cuh"
#include "operators/makeGasPrimDevice.cuh"
#include "operators/riemannFacePrimitiveForGradient.cuh"
#include "operators/computeGasPrimitiveGradientsKernel.cuh"
#include "operators/computeSstGradientsKernel.cuh"
#include "operators/sstVelocityInvariants.cuh"
#include "operators/computeGasHllcAdcSensorKernel.cuh"
#include "operators/updateBarthLimiter.cuh"
#include "operators/computeGasGradientLimiterKernel.cuh"
#include "operators/computeGasEddyViscosityKernel.cuh"
#include "operators/updateWaveTransmissivePressureBoundaryKernel.cuh"
#include "operators/updateLegacyGasBoundaryMirrorKernel.cuh"
#include "operators/gasFaceSubgridTransportProperties.cuh"
#include "operators/computeRiemannGasFaceFluxDevice.cuh"
#include "operators/computeGasInternalFaceFluxKernel.cuh"
#include "operators/computeGasFluxPositivityScaleKernel.cuh"
#include "operators/computeSstFaceFluxKernel.cuh"

#ifdef LEGACY_OPTIONAL_SPECIES
struct TestLegacyGasFixture:LegacyGasFixture{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
#else
using TestLegacyGasFixture=LegacyGasFixture;
#endif

struct State:ugkwp::GasStateView<Real,Time,ugkwp::SstCoefficients>{ugkwp::GasSpeciesState<Real,2> gasSpecies;};
void ck(bool a,const char*m){if(!a){std::fprintf(stderr,"%s\n",m);std::abort();}}
void near(Real a,Real b,const char*m){if(std::abs(a-b)>Real(128)*std::numeric_limits<Real>::epsilon()*std::max(Real(1),std::abs(b))){std::fprintf(stderr,"%s: %.17g != %.17g\n",m,double(a),double(b));std::abort();}}
void initialise(State&s){
s.diagnostics=new ugkp::diagnostics::DeviceContext[8]{};
s.Cx=new Real[8]{};
s.Cy=new Real[8]{};
s.Cz=new Real[8]{};
s.Sfx=new Real[8]{};
s.Sfy=new Real[8]{};
s.Sfz=new Real[8]{};
s.Tgas=new Real[8]{};
s.Ux=new Real[8]{};
s.Uy=new Real[8]{};
s.Uz=new Real[8]{};
s.V=new Real[8]{};
s.cellFaceId=new int[8]{};
s.cellLength=new Real[8]{};
s.cellPlaneCount=new int[8]{};
s.cellPlaneStart=new int[8]{};
s.deltaCoeffs=new Real[8]{};
s.faceCx=new Real[8]{};
s.faceCy=new Real[8]{};
s.faceCz=new Real[8]{};
s.faceNeighbour=new int[8]{};
s.faceOwner=new int[8]{};
s.facePeriodicDx=new Real[8]{};
s.facePeriodicDy=new Real[8]{};
s.facePeriodicDz=new Real[8]{};
s.facePeriodicPair=new int[8]{};
s.faceWeight=new Real[8]{};
s.gasBoundaryKind=new int[8]{};
s.gasBoundaryP=new Real[8]{};
s.gasBoundaryPFix=new int[8]{};
s.gasBoundaryPWave=new int[8]{};
s.gasBoundaryPWaveFieldInf=new Real[8]{};
s.gasBoundaryPWaveGamma=new Real[8]{};
s.gasBoundaryPWaveLInf=new Real[8]{};
s.gasBoundaryRho=new Real[8]{};
s.gasBoundaryRhoFix=new int[8]{};
s.gasBoundaryT=new Real[8]{};
s.gasBoundaryTFix=new int[8]{};
s.gasBoundaryUFix=new int[8]{};
s.gasBoundaryUx=new Real[8]{};
s.gasBoundaryUy=new Real[8]{};
s.gasBoundaryUz=new Real[8]{};
s.gasDiffusionNumber=new Real[8]{};
s.gasFluxPositivityScale=new Real[8]{};
s.gasGradientLimiterP=new Real[8]{};
s.gasGradientLimiterRho=new Real[8]{};
s.gasGradientLimiterT=new Real[8]{};
s.gasGradientLimiterUx=new Real[8]{};
s.gasGradientLimiterUy=new Real[8]{};
s.gasGradientLimiterUz=new Real[8]{};
s.gasHllcAdcSensor=new Real[8]{};
s.gasPhiRho=new Real[8]{};
s.gasPhiRhoE=new Real[8]{};
s.gasPhiRhoUx=new Real[8]{};
s.gasPhiRhoUy=new Real[8]{};
s.gasPhiRhoUz=new Real[8]{};
s.gradKX=new Real[8]{};
s.gradKY=new Real[8]{};
s.gradKZ=new Real[8]{};
s.gradOmegaX=new Real[8]{};
s.gradOmegaY=new Real[8]{};
s.gradOmegaZ=new Real[8]{};
s.gradPx=new Real[8]{};
s.gradPy=new Real[8]{};
s.gradPz=new Real[8]{};
s.gradRhoX=new Real[8]{};
s.gradRhoY=new Real[8]{};
s.gradRhoZ=new Real[8]{};
s.gradTX=new Real[8]{};
s.gradTY=new Real[8]{};
s.gradTZ=new Real[8]{};
s.gradUxX=new Real[8]{};
s.gradUxY=new Real[8]{};
s.gradUxZ=new Real[8]{};
s.gradUyX=new Real[8]{};
s.gradUyY=new Real[8]{};
s.gradUyZ=new Real[8]{};
s.gradUzX=new Real[8]{};
s.gradUzY=new Real[8]{};
s.gradUzZ=new Real[8]{};
s.k=new Real[8]{};
s.magSf=new Real[8]{};
s.nut=new Real[8]{};
s.omega=new Real[8]{};
s.p=new Real[8]{};
s.pressureScheduleTimes=new Time[8]{};
s.pressureScheduleValues=new Real[8]{};
s.rho=new Real[8]{};
s.rhoE=new Real[8]{};
s.rhoENext=new Real[8]{};
s.rhoK=new Real[8]{};
s.rhoKInitial=new Real[8]{};
s.rhoNext=new Real[8]{};
s.rhoOmega=new Real[8]{};
s.rhoOmegaInitial=new Real[8]{};
s.rhoUx=new Real[8]{};
s.rhoUxNext=new Real[8]{};
s.rhoUy=new Real[8]{};
s.rhoUyNext=new Real[8]{};
s.rhoUz=new Real[8]{};
s.rhoUzNext=new Real[8]{};
s.riemannBoundaryKind=new int[8]{};
s.riemannBoundaryP=new Real[8]{};
s.riemannBoundaryPFix=new int[8]{};
s.riemannBoundaryPWave=new int[8]{};
s.riemannBoundaryRho=new Real[8]{};
s.riemannBoundaryRhoFix=new int[8]{};
s.riemannBoundaryT=new Real[8]{};
s.riemannBoundaryTFix=new int[8]{};
s.riemannBoundaryUFix=new int[8]{};
s.riemannBoundaryUx=new Real[8]{};
s.riemannBoundaryUy=new Real[8]{};
s.riemannBoundaryUz=new Real[8]{};
s.scheduledInletFaceMask=new int[8]{};
s.sstBoundaryK=new Real[8]{};
s.sstBoundaryKMode=new int[8]{};
s.sstBoundaryOmega=new Real[8]{};
s.sstBoundaryOmegaMode=new int[8]{};
s.sstF1=new Real[8]{};
s.sstF2=new Real[8]{};
s.sstPhiRhoK=new Real[8]{};
s.sstPhiRhoOmega=new Real[8]{};
s.sstSourceNumber=new Real[8]{};
s.sstWallDistance=new Real[8]{};
s.nCells=2;s.nFaces=3;s.nInternalFaces=1;s.gasFluxScheme=1;s.gasReconstruction=0;s.gasLimiter=0;s.gammaGas=1.4;s.Rgas=287;s.gasCp=1004.5;s.gasMu=0;s.gasPrClamped=.7;s.rhoMin=1e-12;s.TgasMin=1e-9;s.maxDiffusionNumber=.25;

s.sstCoefficients=ugkwp::defaultSstCoefficients();s.sstKMin=1e-12;s.sstOmegaMin=1e-9;s.sstMaxSourceNumber=.25;s.turbulentPrandtl=.9;
for(int c=0;c<2;++c){s.V[c]=1;s.Cx[c]=c;s.cellLength[c]=1;s.rho[c]=2;s.p[c]=100000;s.Tgas[c]=s.p[c]/(s.rho[c]*s.Rgas);s.rhoE[c]=s.p[c]/(s.gammaGas-1);s.cellPlaneStart[c]=2*c;s.cellPlaneCount[c]=2;s.k[c]=3;s.omega[c]=4;s.rhoK[c]=6;s.rhoOmega[c]=8;s.sstWallDistance[c]=.5;}
s.cellFaceId[0]=0;s.cellFaceId[1]=1;s.cellFaceId[2]=0;s.cellFaceId[3]=2;
for(int f=0;f<3;++f){s.faceOwner[f]=f==2?1:0;s.faceNeighbour[f]=f==0?1:-1;s.facePeriodicPair[f]=-1;s.magSf[f]=1;s.Sfx[f]=f==1?-1:1;s.faceCx[f]=f==0?.5:f==1?-.5:1.5;s.faceWeight[f]=.5;s.deltaCoeffs[f]=f==0?1:2;s.gasBoundaryKind[f]=s.riemannBoundaryKind[f]=f==0?0:1;s.gasHllcAdcSensor[f]=1;}
blockDim.x=1;blockIdx.x=threadIdx.x=0;
}
void moving(State&s,Real*oldV,Real*newV,Real*sweeps,Real dt){s.gasGeometry.enabled=true;s.gasGeometry.oldVolume=oldV;s.gasGeometry.newVolume=newV;s.gasGeometry.faceSweptVolume=sweeps;s.gasGeometry.interval=dt;s.gasGeometry.absoluteGeometryTolerance=Real(16)*std::numeric_limits<Real>::epsilon();s.gasGeometry.relativeGeometryTolerance=Real(16)*std::numeric_limits<Real>::epsilon();}
void flux(State&s,double dt){for(int c=0;c<2;++c){threadIdx.x=c;computeGasPrimitiveGradientsKernel(&s);computeGasGradientLimiterKernel(&s);computeGasEddyViscosityKernel(&s);}for(int f=0;f<3;++f){threadIdx.x=f;computeGasInternalFaceFluxKernel<false>(&s,dt);}for(int c=0;c<2;++c){threadIdx.x=c;computeGasFluxPositivityScaleKernel(&s,dt);}for(int f=0;f<3;++f){threadIdx.x=f;applyGasFluxPositivityScaleKernel(&s);}}

#include "applications/gasUGKP/gpu/GpuBackendApi.H"
#include "common/gasTransport/GasBuildConfig.H"
#include "common/gasTransport/GasStateView.H"
#include "common/gasTransport/GasCapabilities.H"
#include "common/gasTransport/GasMechanismIO.H"
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
static int allocations=0,failAfter=-1,copyFailAfter=-1,syncFailAfter=-1,hostCopyFailAfter=-1,syncFailures=0;
using cudaError_t=int;
const int cudaSuccess=0,cudaMemcpyHostToDevice=1,cudaMemcpyDeviceToDevice=2;
int cudaFree(void*p){if(p){--allocations;std::free(p);}return 0;}
int cudaMemcpy(void*d,const void*s,std::size_t n,int){if(syncFailures){if(syncFailures--==2 && n)std::memcpy(d,s,n-1);return 1;}if(syncFailAfter==0){syncFailAfter=-1;if(n)std::memcpy(d,s,n/2);return 1;}if(syncFailAfter>0)--syncFailAfter;std::memcpy(d,s,n);return 0;}
int cudaMemset(void*d,int v,std::size_t n){std::memset(d,v,n);return 0;}
std::string last;
void setLastErrorText(const char*s){last=s;}
void setLastError(const char*s,int){last=s;}
template<class T> int allocate(T*&p,std::size_t n,const char*){p=nullptr;if(!n)return 0;if(failAfter==0)return 1;if(failAfter>0)--failAfter;p=static_cast<T*>(std::malloc(n*sizeof(T)));if(!p)return 1;++allocations;return 0;}
template<class T> int copyToDevice(T*d,const T*s,std::size_t n,const char*){if(copyFailAfter==0){copyFailAfter=-1;if(n)std::memcpy(d,s,sizeof(T));return 1;}if(copyFailAfter>0)--copyFailAfter;if(n)std::memcpy(d,s,n*sizeof(T));return 0;}
template<class T> int copyToHost(T*d,const T*s,std::size_t n,const char*){if(hostCopyFailAfter==0){hostCopyFailAfter=-1;if(n)std::memcpy(d,s,sizeof(T));return 1;}if(hostCopyFailAfter>0)--hostCopyFailAfter;if(n)std::memcpy(d,s,n*sizeof(T));return 0;}


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <type_traits>

constexpr int cudaStreamCaptureModeThreadLocal=0,cudaGraphNodeTypeKernel=0;
using cudaStream_t=void*; using cudaGraph_t=void*; using cudaGraphExec_t=void*;
using cudaGraphNode_t=int; using cudaGraphNodeType=int;
struct cudaKernelNodeParams { void* func=nullptr; void** kernelParams=nullptr; void** extra=nullptr; };
std::vector<std::string> trace;
int launchCount=0,failLaunch=0;
bool expectedNativeOwner=false;int ownerChecks=0;
void checkNativeOwner(bool value){++ownerChecks;if(value!=expectedNativeOwner)std::abort();}
int cudaGetLastError(){return ++launchCount==failLaunch?91:0;}
int cudaGraphExecDestroy(cudaGraphExec_t){return 0;} int cudaGraphDestroy(cudaGraph_t){return 0;}
int cudaStreamCreate(cudaStream_t*s){*s=reinterpret_cast<void*>(1);return 0;}
int cudaStreamDestroy(cudaStream_t){return 0;}
int cudaStreamBeginCapture(cudaStream_t,int){return 0;}
int cudaStreamEndCapture(cudaStream_t,cudaGraph_t*g){*g=reinterpret_cast<void*>(2);return 0;}
std::vector<cudaKernelNodeParams> graphNodes;
int cudaGraphGetNodes(cudaGraph_t,cudaGraphNode_t*nodes,std::size_t*n){if(nodes){for(std::size_t j=0;j<*n;++j)nodes[j]=int(j);}else *n=graphNodes.size();return 0;}
int cudaGraphNodeGetType(cudaGraphNode_t,cudaGraphNodeType*t){*t=cudaGraphNodeTypeKernel;return 0;}
int cudaGraphKernelNodeGetParams(cudaGraphNode_t n,cudaKernelNodeParams*p){*p=graphNodes[n];return 0;}
int cudaGraphInstantiate(cudaGraphExec_t*e,cudaGraph_t,void*,void*,int){*e=reinterpret_cast<void*>(3);return 0;}
void*expectedDevice=nullptr;double expectedTime=0;
int cudaGraphExecKernelNodeSetParams(cudaGraphExec_t,cudaGraphNode_t,cudaKernelNodeParams*p){if(*static_cast<void**>(p->kernelParams[0])!=expectedDevice||*static_cast<double*>(p->kernelParams[1])!=expectedTime)std::abort();trace.push_back("graph-time");return 0;}
int cudaGraphLaunch(cudaGraphExec_t,void*){trace.push_back("graph-launch");return 0;}
#include "common/gasTransport/GasBoundaryLayerModelState.H"
#include "applications/gasUGKP/private_backend/SharedGasTrialFields.H"

struct DeviceState;
template<bool Capture> int launchBoundaryLayer(DeviceState*);
namespace sharedGasTrialDetail {
template<bool Capture,class State> int snapshotWallRecords(State*,SharedGasTrialSnapshot&,bool);
}
struct DeviceState:State{
 int (*gasBoundaryLayerLaunch)(DeviceState*)=&launchBoundaryLayer<false>;
 int (*gasBoundaryLayerSnapshot)(DeviceState*,SharedGasTrialSnapshot&,bool)=
     &sharedGasTrialDetail::snapshotWallRecords<false,DeviceState>;

 ugkwp::GasSpeciesState<double,2> gasRejectedView;
 ugkwp::GasBoundaryLayerModelState<double,2> gasBoundaryLayerModel;
 SharedGasTrialStorage gasTrial;
 bool gasModelPoisoned=false,gasInitialFieldsUploaded=false,gasSpeciesUploaded=false,hostGravityActive=false,particlesMayBePresent=false;
 DeviceState*deviceState=this;int particleCapacity=0,gasTimeIntegrator=1,nBoundarySources=0;
 int fixedCellBlockThreads=4,fixedFaceBlockThreads=4,hostGasTimeIntegrator=1,hostTurbulenceModel=0,hostGasFluxScheme=1,hostGasReconstruction=0,hostGasLimiter=0,hasPeriodicFaces=0;
 double gasBoundaryLayerStageTime=0,gravityX=0,gravityY=0,gravityZ=0;
 int*particleCountDevice=nullptr,*pCellId=nullptr,*pStatus=nullptr;double*px=nullptr,*py=nullptr,*pz=nullptr,*pux=nullptr,*puy=nullptr,*puz=nullptr,*puxOld=nullptr,*puyOld=nullptr,*puzOld=nullptr,*pT=nullptr,*pTheta=nullptr,*pd=nullptr,*pm=nullptr;
 cudaStream_t gasCaptureStream=nullptr;cudaGraph_t gasGraph=nullptr;cudaGraphExec_t gasGraphExec=nullptr;double gasGraphDt=-1;
 std::vector<cudaGraphNode_t>gasGraphTimeNodes;std::vector<cudaKernelNodeParams>gasGraphTimeParams;
};
DeviceState* asState(void*p){return static_cast<DeviceState*>(p);}
int validateState(DeviceState*s,const char*){return s && !s->gasModelPoisoned?0:1;}
#include "applications/gasUGKP/private_backend/SharedGasStorage.cuh"
#include "applications/gasUGKP/private_backend/SharedGasAdapter.cuh"

int cudaDeviceSynchronize(){return 0;}
template<class F>void emulateLaunch(F f,int grid,int block){blockDim.x=block;for(blockIdx.x=0;blockIdx.x<grid;++blockIdx.x)for(threadIdx.x=0;threadIdx.x<block;++threadIdx.x)f();}
int tuneFixedWorkBlockThreads(DeviceState*,double,double){return 0;}
__device__ GPU_OPERATOR_REAL sqr3(const GPU_OPERATOR_REAL x, const GPU_OPERATOR_REAL y, const GPU_OPERATOR_REAL z)
{
    return x*x + y*y + z*z;
}
#include "GpuGravityUpdate.cuh"
#include "operators/advanceGasChemistryKernel.cuh"
template<class S,class T>void advanceGasChemistryKernel(S*s,T dt,const Real*v,bool nativeRefinement=false){int c=blockIdx.x*blockDim.x+threadIdx.x;if(c<s->nCells)ugkwp::advanceGasChemistryCell(*s,c,dt,v[c],nativeRefinement);}
#include "operators/evaluateGasBoundaryLayerKernel.cuh"

template<bool Capture,class GasState> void evaluateGasBoundaryLayerTeamKernel(GasState* state){
 if(threadIdx.x)return;
 const int worker=blockIdx.x,workers=state->gasBoundaryLayerModel.workspaceCount;
 if(worker>=workers || !ugkwp::gasBoundaryLayerEnabled(*state))return;
 for(int slot=worker;slot<state->gasBoundaryLayer.count;slot+=workers)
  ugkwp::evaluateGasBoundaryLayerSlot<Capture>(*state,slot,worker);
}
template<bool Capture> int launchBoundaryLayer(DeviceState* s)
{
        const bool analytic=s->gasBoundaryLayerModel.config.model==ugkwp::gaswall::BoundaryLayerModel::ConstantTransport;
        const int workers=analytic?s->gasBoundaryLayer.count:s->gasBoundaryLayerModel.workspaceCount,block=32;
        if(workers<=0){setLastErrorText("boundaryLayer scratch pool is empty");return 1;}
        if(analytic)
            emulateLaunch([&](){evaluateGasBoundaryLayerKernel<Capture>(s->deviceState);},(workers+block-1)/block,block);
        else
        {
#define LAUNCH_WALL_CAPACITY(N) case N: emulateLaunch([&](){evaluateGasBoundaryLayerTeamKernel<Capture,N>(s->deviceState);},workers,ugkwp::gaswall::detail::wallWarpWidth);break
            switch(s->gasBoundaryLayerModel.workspaceCapacity)
            {
                LAUNCH_WALL_CAPACITY(24);
                LAUNCH_WALL_CAPACITY(48);
                LAUNCH_WALL_CAPACITY(128);
                emulateLaunch([&](){default:evaluateGasBoundaryLayerTeamKernel<Capture>(s->deviceState);},workers,ugkwp::gaswall::detail::wallWarpWidth);
            }
#undef LAUNCH_WALL_CAPACITY
        }
        const auto error=cudaGetLastError();
        if(error!=cudaSuccess){setLastError("prepare sparse boundaryLayer profiles",error);return 1;}
        return 0;
}__global__ void applyGasGravitySourceKernel(DeviceState* sp, const double dt)
{
    const int c=blockIdx.x*blockDim.x+threadIdx.x;
    if(c<sp->nCells) applyGasGravityCell<false>(*sp,c,dt);
}
int applyGasGravitySource
(
    DeviceState* s,
    const int grid,
    const int block,
    const double dt,
    const bool nativeRefinement=false
)
{
    if (!s->hostGravityActive)
    {
        return 0;
    }

    emulateLaunch([&](){applyGasGravitySourceKernel(s->deviceState, dt);},grid, block);
    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("applyGasGravitySourceKernel launch", err);
        return 1;
    }

                                                                             
                                                                       
    emulateLaunch([&](){recoverGasPrimitivesKernel(s->deviceState,nativeRefinement);},grid, block);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("recoverGasPrimitivesKernel post-gravity launch", err);
        return 1;
    }
    return 0;
}
#include "applications/gasUGKP/private_backend/SharedGasTrialPolicy.cuh"
#include "GpuGasHostPolicy.cuh"
struct GasHostPolicy:GasHostWithoutWallEnergy<double,double>
{
    template<class HostState> static int prepareBoundaryLayer(HostState* s,double,double stageTime)
    {
        if(!s->gasBoundaryLayer.enabled)return 0;
        s->gasBoundaryLayerStageTime=stageTime;
        return s->gasBoundaryLayerLaunch(s);
    }
};
#pragma once
#include <type_traits>
#include "gasTransport/GasStateView.H"
#include "gasTransport/GasBoundaryLayerHost.H"
#include "operators/advanceGasChemistryKernel.cuh"

// Shared Euler/RK, boundary-finalisation and graph-capture host protocol.
// Requires a gas host state, GasHostPolicy, all gas kernels and error helpers.
// The host state owns launch/graph resources and a deviceState pointer. That
// pointer may name a gas-only view; no particle storage is required here.
// GasHostPolicy owns only time/weight types and the optional wall-energy ledger;
// launches, streams, error checks and their ordering are owned here.

template<class GasHostState>
int advanceGasEulerSubstage(GasHostState* s, const GasHostPolicy::Time dt, const GasHostPolicy::Time ledgerDt, const GasHostPolicy::Time stageTime, const bool nativeRefinement=false)
{
    const int cellBlock = s->fixedCellBlockThreads;
    const int faceBlock = s->fixedFaceBlockThreads;
    const int cellGrid = (s->nCells + cellBlock - 1)/cellBlock;
    const int faceGrid = (s->nFaces + faceBlock - 1)/faceBlock;
    cudaError_t err = cudaSuccess;
    const bool preparedBoundaryLayer=ugkwp::gasBoundaryLayerPreparationReusable(*s,dt,stageTime);

    emulateLaunch([&](){recoverGasPrimitivesKernel(s->deviceState,nativeRefinement);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("recoverGasPrimitivesKernel gas stage", err);
        return 1;
    }
    if (s->hostTurbulenceModel == 3)
    {
        emulateLaunch([&](){recoverSstPrimitivesKernel(s->deviceState,nativeRefinement);},cellGrid, cellBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("recoverSstPrimitivesKernel gas stage", err);
            return 1;
        }
    }
    if (faceGrid > 0 && !preparedBoundaryLayer)
    {
        emulateLaunch([&](){updateRiemannBoundaryMirrorKernel(s->deviceState);},faceGrid, faceBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("updateRiemannBoundaryMirrorKernel gas stage", err);
            return 1;
        }
    }
    if(ugkwp::prepareGasBoundaryLayerStage<GasHostPolicy>(s,dt,stageTime,false)!=0)
    {setLastErrorText("boundaryLayer stage preparation failed");return 1;}
    if (s->hostTurbulenceModel == 3 && !preparedBoundaryLayer)
    {
        emulateLaunch([&](){applySstWallFunctionStateKernel(s->deviceState,false,nativeRefinement);},cellGrid, cellBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("applySstWallFunctionStateKernel gas stage", err);
            return 1;
        }
    }
    if (s->hostGasFluxScheme == 7 && !ugkwp::mixtureGasActive(*s))
    {
        emulateLaunch([&](){computeGasHllcAdcSensorKernel(s->deviceState);},cellGrid, cellBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("computeGasHllcAdcSensorKernel launch", err);
            return 1;
        }
    }
    emulateLaunch([&](){computeGasPrimitiveGradientsKernel(s->deviceState,false,nativeRefinement);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("computeGasPrimitiveGradientsKernel launch", err);
        return 1;
    }
    emulateLaunch([&](){computeGasGradientLimiterKernel(s->deviceState,nativeRefinement);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("computeGasGradientLimiterKernel launch", err);
        return 1;
    }
    emulateLaunch([&](){computeGasEddyViscosityKernel(s->deviceState);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("computeGasEddyViscosityKernel launch", err);
        return 1;
    }
    if (faceGrid <= 0)
    {
        return 0;
    }
    if (s->hostTurbulenceModel == 0)
    {
        emulateLaunch([&](){computeGasInternalFaceFluxKernel<false>(
            s->deviceState,
            dt,nativeRefinement);},faceGrid, faceBlock);
    }
    else
    {
        emulateLaunch([&](){computeGasInternalFaceFluxKernel<true>(
            s->deviceState,
            dt,nativeRefinement);},faceGrid, faceBlock);
    }
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("computeGasInternalFaceFluxKernel launch", err);
        return 1;
    }
    if (s->hasPeriodicFaces != 0)
    {
        emulateLaunch([&](){enforcePeriodicGasFluxAntisymmetryKernel(
            s->deviceState,nativeRefinement);},faceGrid, faceBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("enforcePeriodicGasFluxAntisymmetryKernel launch", err);
            return 1;
        }
    }
    // Coupled applications may replace complete 5+Ns boundary fluxes here.
    // Positivity and accepted RK-weighted ledgers still belong to this pipeline.
    if (GasHostPolicy::applyFaceSources(s, dt, stageTime) != 0) return 1;
    emulateLaunch([&](){computeGasFluxPositivityScaleKernel(s->deviceState, dt);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("computeGasFluxPositivityScaleKernel launch", err);
        return 1;
    }
    emulateLaunch([&](){applyGasFluxPositivityScaleKernel(
        s->deviceState,nativeRefinement);},faceGrid, faceBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("applyGasFluxPositivityScaleKernel launch", err);
        return 1;
    }
    if (GasHostPolicy::accumulateWallEnergy(s, ledgerDt) != 0) return 1;
    if (s->hasPeriodicFaces != 0)
    {
        emulateLaunch([&](){enforcePeriodicGasFluxAntisymmetryKernel(
            s->deviceState,nativeRefinement);},faceGrid, faceBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError
            (
                "enforcePeriodicGasFluxAntisymmetryKernel post-scale launch",
                err
            );
            return 1;
        }
    }
    if (s->hostTurbulenceModel == 3)
    {
        emulateLaunch([&](){computeSstGradientsKernel(s->deviceState);},cellGrid, cellBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("computeSstGradientsKernel launch", err);
            return 1;
        }
    }
    if (s->hostTurbulenceModel == 3)
    {
        emulateLaunch([&](){computeSstFaceFluxKernel(s->deviceState);},faceGrid, faceBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("computeSstFaceFluxKernel launch", err);
            return 1;
        }
        if (s->hasPeriodicFaces != 0)
        {
            emulateLaunch([&](){enforcePeriodicSstFluxAntisymmetryKernel(
                s->deviceState
            );},faceGrid, faceBlock);
            err = cudaGetLastError();
            if (err != cudaSuccess)
            {
                setLastError("enforcePeriodicSstFluxAntisymmetryKernel launch", err);
                return 1;
            }
        }
        emulateLaunch([&](){applySstFluxAndSourceKernel(
            s->deviceState,
            dt,nativeRefinement);},cellGrid, cellBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("applySstFluxAndSourceKernel launch", err);
            return 1;
        }
    }
    emulateLaunch([&](){applyGasFluxDivergenceByCellKernel(s->deviceState, dt, nativeRefinement);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("applyGasFluxDivergenceByCellKernel launch", err);
        return 1;
    }
    emulateLaunch([&](){recoverGasPrimitivesKernel(s->deviceState,nativeRefinement);},cellGrid, cellBlock);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("recoverGasPrimitivesKernel post-gas launch", err);
        return 1;
    }
    if (s->hostTurbulenceModel == 3)
    {
        emulateLaunch([&](){recoverSstPrimitivesKernel(s->deviceState,nativeRefinement);},cellGrid, cellBlock);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("recoverSstPrimitivesKernel post-gas launch", err);
            return 1;
        }
    }
    return 0;
}

template<class GasHostState>
int blendGasRungeKuttaStage
(
    GasHostState* s,
    const double initialWeight,
    const double stageWeight,
    const bool nativeRefinement=false
)
{
    const int block = s->fixedCellBlockThreads;
    const int cellGrid = (s->nCells + block - 1)/block;
    emulateLaunch([&](){blendGasConservativeStateKernel(
        s->deviceState,
        initialWeight,
        stageWeight, nativeRefinement
    );},cellGrid, block);
    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("blendGasConservativeStateKernel launch", err);
        return 1;
    }
    emulateLaunch([&](){recoverGasPrimitivesKernel(s->deviceState,nativeRefinement);},cellGrid, block);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("recoverGasPrimitivesKernel after RK blend", err);
        return 1;
    }
    if (s->hostTurbulenceModel == 3)
    {
        emulateLaunch([&](){recoverSstPrimitivesKernel(s->deviceState,nativeRefinement);},cellGrid, block);
        err = cudaGetLastError();
        if (err != cudaSuccess)
        {
            setLastError("recoverSstPrimitivesKernel after RK blend", err);
            return 1;
        }
    }
    return 0;
}

template<class GasHostState>
int advanceGasFluxStage(GasHostState* s, const GasHostPolicy::Time dt, const GasHostPolicy::Time simulationTime, const bool nativeRefinement=false)
{

    const int preparationCellBlock = s->fixedCellBlockThreads;
    const int preparationFaceBlock = s->fixedFaceBlockThreads;
    const int preparationCellGrid =
        (s->nCells + preparationCellBlock - 1)/preparationCellBlock;
    const int preparationFaceGrid =
        (s->nFaces + preparationFaceBlock - 1)/preparationFaceBlock;
    emulateLaunch([&](){recoverGasPrimitivesKernel(
        s->deviceState,nativeRefinement);},preparationCellGrid, preparationCellBlock);
    cudaError_t preparationError = cudaGetLastError();
    if (preparationError != cudaSuccess)
    {
        setLastError
        (
            "recoverGasPrimitivesKernel before gas advance",
            preparationError
        );
        return 1;
    }
    if (preparationFaceGrid > 0
        && !ugkwp::gasBoundaryLayerPreparationReusable(*s,dt,simulationTime))
    {
        emulateLaunch([&](){updateLegacyGasBoundaryMirrorKernel(s->deviceState, simulationTime);},preparationFaceGrid, preparationFaceBlock);
        preparationError = cudaGetLastError();
        if (preparationError != cudaSuccess)
        {
            setLastError
            (
                "updateLegacyGasBoundaryMirrorKernel before gas advance",
                preparationError
            );
            return 1;
        }
    }

    if (s->hostGasTimeIntegrator == 1)
    {
        return advanceGasEulerSubstage(s, dt, dt, simulationTime, nativeRefinement);
    }

    const int block = s->fixedCellBlockThreads;
    const int cellGrid = (s->nCells + block - 1)/block;
    emulateLaunch([&](){saveGasConservativeStateKernel(s->deviceState);},cellGrid, block);
    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError("saveGasConservativeStateKernel launch", err);
        return 1;
    }

    const GasHostPolicy::Time firstLedgerDt = GasHostPolicy::firstLedgerDt(s, dt);
    if (advanceGasEulerSubstage(s, dt, firstLedgerDt, simulationTime, nativeRefinement) != 0)
    {
        return 1;
    }
    if (advanceGasEulerSubstage(s, dt, firstLedgerDt, simulationTime+dt, nativeRefinement) != 0)
    {
        return 1;
    }

    if (s->hostGasTimeIntegrator == 2)
    {

        return blendGasRungeKuttaStage(s, static_cast<double>(0.5), static_cast<double>(0.5), nativeRefinement);
    }
    if (s->hostGasTimeIntegrator != 3)
    {
        setLastErrorText("invalid resident gas time-integrator selector");
        return 1;
    }

    if (blendGasRungeKuttaStage(s, static_cast<double>(0.75), static_cast<double>(0.25), nativeRefinement) != 0)
    {
        return 1;
    }
    if (advanceGasEulerSubstage(s, dt, GasHostPolicy::finalLedgerDt(dt), simulationTime+dt*GasHostPolicy::Time(0.5), nativeRefinement) != 0)
    {
        return 1;
    }
    return blendGasRungeKuttaStage
    (
        s,
        static_cast<double>(1.0)/static_cast<double>(3.0),
        static_cast<double>(2.0)/static_cast<double>(3.0),
        nativeRefinement
    );
}

template<class GasHostState>
int finaliseGasBoundaryStage(GasHostState* s, const GasHostPolicy::Time dt, const GasHostPolicy::Time simulationTime)
{
    const int block = s->fixedFaceBlockThreads;
    const int allFaceGrid = (s->nFaces + block - 1)/block;
    if (allFaceGrid <= 0)
    {
        return 0;
    }

    emulateLaunch([&](){updateLegacyGasBoundaryMirrorKernel(
        s->deviceState,
        simulationTime
    );},allFaceGrid, block);
    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError
        (
            "updateLegacyGasBoundaryMirrorKernel final gas boundary",
            err
        );
        return 1;
    }

    emulateLaunch([&](){updateRiemannBoundaryMirrorKernel(
        s->deviceState
    );},allFaceGrid, block);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError
        (
            "updateRiemannBoundaryMirrorKernel final gas boundary",
            err
        );
        return 1;
    }

    emulateLaunch([&](){updateWaveTransmissivePressureBoundaryKernel(
        s->deviceState,
        dt
    );},allFaceGrid, block);
    err = cudaGetLastError();
    if (err != cudaSuccess)
    {
        setLastError
        (
            "updateWaveTransmissivePressureBoundaryKernel final gas boundary",
            err
        );
        return 1;
    }
    return 0;
}

template<class GasHostState>
int advancePureGasGraph(GasHostState* s, const GasHostPolicy::Time dt, const GasHostPolicy::Time simulationTime)
{
    if (s->gasGraphExec == nullptr || s->gasGraphDt != dt)
    {
        cudaError_t err = cudaSuccess;
        if (s->gasGraphExec)
        {
            err = cudaGraphExecDestroy(s->gasGraphExec);
            if (err != cudaSuccess) { setLastError("gas graph destroy executable", err); return 1; }
            s->gasGraphExec = nullptr;
        }
        if (s->gasGraph)
        {
            err = cudaGraphDestroy(s->gasGraph);
            if (err != cudaSuccess) { setLastError("gas graph destroy", err); return 1; }
            s->gasGraph = nullptr;
        }
        s->gasGraphTimeNodes.clear();
        s->gasGraphTimeParams.clear();
        err = cudaStreamCreate(&s->gasCaptureStream);
        if (err != cudaSuccess) { setLastError("gas graph stream create", err); return 1; }
        err = cudaStreamBeginCapture(s->gasCaptureStream, cudaStreamCaptureModeThreadLocal);
        if (err != cudaSuccess)
        {
            cudaStreamDestroy(s->gasCaptureStream);
            s->gasCaptureStream = nullptr;
            setLastError("gas graph capture begin", err);
            return 1;
        }
        int status = advanceGasFluxStage(s, dt, simulationTime);
        if (status == 0) status = finaliseGasBoundaryStage(s, dt, simulationTime);
        err = cudaStreamEndCapture(s->gasCaptureStream, &s->gasGraph);
        const cudaError_t streamError = cudaStreamDestroy(s->gasCaptureStream);
        s->gasCaptureStream = nullptr;
        if (status != 0) return status;
        if (err != cudaSuccess) { setLastError("gas graph capture end", err); return 1; }
        if (streamError != cudaSuccess) { setLastError("gas graph stream destroy", streamError); return 1; }
        size_t nodeCount = 0;
        err = cudaGraphGetNodes(s->gasGraph, nullptr, &nodeCount);
        if (err != cudaSuccess) { setLastError("gas graph node count", err); return 1; }
        std::vector<cudaGraphNode_t> nodes(nodeCount);
        err = cudaGraphGetNodes(s->gasGraph, nodes.data(), &nodeCount);
        if (err != cudaSuccess) { setLastError("gas graph nodes", err); return 1; }
        for (const auto node : nodes)
        {
            cudaGraphNodeType type;
            err = cudaGraphNodeGetType(node, &type);
            if (err != cudaSuccess) { setLastError("gas graph node type", err); return 1; }
            if (type != cudaGraphNodeTypeKernel) continue;
            cudaKernelNodeParams params{};
            err = cudaGraphKernelNodeGetParams(node, &params);
            if (err != cudaSuccess) { setLastError("gas graph kernel parameters", err); return 1; }
            using GasDeviceState = typename std::remove_pointer<decltype(s->deviceState)>::type;
            if (params.func == reinterpret_cast<void*>(updateLegacyGasBoundaryMirrorKernel<GasDeviceState>))
            {
                s->gasGraphTimeNodes.push_back(node);
                params.kernelParams = nullptr;
                params.extra = nullptr;
                s->gasGraphTimeParams.push_back(params);
            }
        }
        if (s->nFaces > 0 && s->gasGraphTimeNodes.size() != 2)
        {
            setLastErrorText("gas graph requires both scheduled boundary time nodes");
            return 1;
        }
        err = cudaGraphInstantiate(&s->gasGraphExec, s->gasGraph, nullptr, nullptr, 0);
        if (err != cudaSuccess) { setLastError("gas graph instantiate", err); return 1; }
        s->gasGraphDt = dt;
    }
    auto* device = s->deviceState;
    GasHostPolicy::Time currentTime = simulationTime;
    void* args[] = {&device, &currentTime};
    for (size_t i = 0; i < s->gasGraphTimeNodes.size(); ++i)
    {
        cudaKernelNodeParams params = s->gasGraphTimeParams[i];
        params.kernelParams = args;
        const cudaError_t err = cudaGraphExecKernelNodeSetParams
        (
            s->gasGraphExec, s->gasGraphTimeNodes[i], &params
        );
        if (err != cudaSuccess) { setLastError("gas graph time update", err); return 1; }
    }
    const cudaError_t err = cudaGraphLaunch(s->gasGraphExec, nullptr);
    if (err != cudaSuccess) { setLastError("gas graph launch", err); return 1; }
    return 0;
}



template<class Policy,class State>
auto validateGasTrialState(State* s,bool nativeRefinement,int)
    -> decltype(Policy::validate(s,nativeRefinement))
{return Policy::validate(s,nativeRefinement);}
template<class Policy,class State>
int validateGasTrialState(State* s,bool,long)
{return Policy::validate(s);}

template<class Policy,class State,class Time>
auto applyGasTrialSources(State* s,Time dt,bool nativeRefinement,int)
    -> decltype(Policy::applySources(s,dt,nativeRefinement))
{return Policy::applySources(s,dt,nativeRefinement);}
template<class Policy,class State,class Time>
int applyGasTrialSources(State* s,Time dt,bool,long)
{return Policy::applySources(s,dt);}


// Shared source composition: chemistry always uses explicit stage volumes.
template<class TrialPolicy,class GasHostState>
int prepareGasTrialTransport(GasHostState* s,const GasHostPolicy::Time dt,
    const GasHostPolicy::Time simulationTime=GasHostPolicy::Time(0),
    const bool nativeRefinement=false)
{
    if constexpr (ugkwp::GasStateTraits<GasHostState>::speciesCount > 0)
    {
        {
            const int block=s->fixedCellBlockThreads,grid=(s->nCells+block-1)/block;
            const bool chemistry=s->gasSpecies.mode==ugkwp::GasMode::MixtureChemistry;
            if(chemistry)
            {
                emulateLaunch([&](){advanceGasChemistryKernel(s->deviceState,dt*GasHostPolicy::Time(0.5),TrialPolicy::stageVolumes(s,false),nativeRefinement);},grid,block);
                const auto error=cudaGetLastError();
                if(error!=cudaSuccess){setLastError("pre-transport gas chemistry",error);return 1;}
            }
            emulateLaunch([&](){recoverGasPrimitivesKernel(s->deviceState,nativeRefinement);},grid,block);
            const auto recoveryError=cudaGetLastError();
            if(recoveryError!=cudaSuccess){setLastError("pre-transport mixture recovery",recoveryError);return 1;}
            if(ugkwp::gasBoundaryLayerEnabled(*s))
            {
                // The first chemistry half-step has completed. Refresh only the
                // selected family's current boundary input and prepare once;
                // the first Euler stage consumes this exact state/phase cache.
                if(s->hostTurbulenceModel==3)
                {
                    emulateLaunch([&](){recoverSstPrimitivesKernel(s->deviceState,nativeRefinement);},grid,block);
                    const auto error=cudaGetLastError();
                    if(error!=cudaSuccess){setLastError("wall preflight SST recovery",error);return 1;}
                }
                const int faceBlock=s->fixedFaceBlockThreads,faceGrid=(s->nFaces+faceBlock-1)/faceBlock;
                if(faceGrid>0)
                {
                    emulateLaunch([&](){updateLegacyGasBoundaryMirrorKernel(s->deviceState,simulationTime);},faceGrid,faceBlock);
                    auto error=cudaGetLastError();
                    if(error!=cudaSuccess){setLastError("wall preflight boundary time",error);return 1;}
                    emulateLaunch([&](){updateRiemannBoundaryMirrorKernel(s->deviceState);},faceGrid,faceBlock);
                    error=cudaGetLastError();
                    if(error!=cudaSuccess){setLastError("wall preflight boundary state",error);return 1;}
                }
                if(ugkwp::prepareGasBoundaryLayerStage<GasHostPolicy>(s,dt,simulationTime,true)!=0)
                {setLastErrorText("boundaryLayer preflight preparation failed");return 1;}
                if(s->hostTurbulenceModel==3)
                {
                    emulateLaunch([&](){applySstWallFunctionStateKernel(s->deviceState,false,nativeRefinement);},grid,block);
                    const auto error=cudaGetLastError();
                    if(error!=cudaSuccess){setLastError("wall preflight owner omega",error);return 1;}
                }
            }
            if(validateGasTrialState<TrialPolicy>(s,nativeRefinement,0)!=0)return 1;


        }
    }
    return 0;
}

template<class TrialPolicy,class GasHostState>
int finaliseGasTrialSources(GasHostState* s,const GasHostPolicy::Time dt,
    const bool nativeRefinement=false)
{
    if constexpr (ugkwp::GasStateTraits<GasHostState>::speciesCount > 0)
    {
        if(ugkwp::mixtureGasActive(*s))
        {
            const int block=s->fixedCellBlockThreads,grid=(s->nCells+block-1)/block;
            const bool chemistry=s->gasSpecies.mode==ugkwp::GasMode::MixtureChemistry;
            if(chemistry)
            {
                emulateLaunch([&](){advanceGasChemistryKernel(s->deviceState,dt*GasHostPolicy::Time(0.5),TrialPolicy::stageVolumes(s,true),nativeRefinement);},grid,block);
                const auto error=cudaGetLastError();
                if(error!=cudaSuccess){setLastError("post-transport gas chemistry",error);return 1;}
            }
            emulateLaunch([&](){recoverGasPrimitivesKernel(s->deviceState,nativeRefinement);},grid,block);
            const auto error=cudaGetLastError();
            if(error!=cudaSuccess){setLastError("post-source mixture recovery",error);return 1;}
            if(validateGasTrialState<TrialPolicy>(s,nativeRefinement,0)!=0)return 1;
        }
    }
    return 0;
}




template<class TrialPolicy, class GasHostState>
int advanceGasTrial
(
    GasHostState* s,
    const GasHostPolicy::Time dt,
    const GasHostPolicy::Time simulationTime,
    const bool nativeRefinement=false
)
{
    ugkwp::invalidateGasBoundaryLayerPreparation(*s);
    if (TrialPolicy::begin(s) != 0)
    { ugkwp::invalidateGasBoundaryLayerPreparation(*s); return 1; }
    if (prepareGasTrialTransport<TrialPolicy>(s,dt,simulationTime,nativeRefinement) != 0
        || advanceGasFluxStage(s, dt, simulationTime,nativeRefinement) != 0
        || (!nativeRefinement && validateGasTrialState<TrialPolicy>(s,nativeRefinement,0) != 0)
        || applyGasTrialSources<TrialPolicy>(s,dt,nativeRefinement,0) != 0
        || finaliseGasTrialSources<TrialPolicy>(s,dt,nativeRefinement) != 0
        || finaliseGasBoundaryStage(s, dt, simulationTime+dt) != 0
        || validateGasTrialState<TrialPolicy>(s,nativeRefinement,0) != 0
        || TrialPolicy::commit(s) != 0)
    { ugkwp::invalidateGasBoundaryLayerPreparation(*s); return 1; }
    return 0;
}

template<class Time>
struct GasRequestedIntervalControls
{
    // Compatibility token: the requested interval has no retry budget.
};




template<class TrialPolicy, class GasHostState>
int advanceGasRequestedInterval
(
    GasHostState* s,
    const GasHostPolicy::Time requestedDt,
    const GasHostPolicy::Time simulationTime,
    const GasRequestedIntervalControls<GasHostPolicy::Time>& controls
)
{
    (void)controls;
    if (TrialPolicy::beginInterval(s) != 0) return 1;
    if (advanceGasTrial<TrialPolicy>(s,requestedDt,simulationTime,false) != 0) return 1;
    return TrialPolicy::commitInterval(s);
}
int syncSstConfiguration(DeviceState* s, const char* name, bool retainConstants=false)
{
    const size_t first = offsetof(DeviceState, sstConfigured);


    const size_t last = retainConstants ? offsetof(DeviceState, sstJayatillekeP)
        : offsetof(DeviceState, sstThermalYPlus) + sizeof(s->sstThermalYPlus);
    const cudaError_t err = cudaMemcpy
    (
        reinterpret_cast<unsigned char*>(s->deviceState) + first,
        reinterpret_cast<const unsigned char*>(s) + first,
        last - first,
        cudaMemcpyHostToDevice
    );
    if (err != cudaSuccess)
    {
        setLastError(name, err);
        return 1;
    }
    return 0;
}
extern "C" int ugkwpGpuResidentStrictConfigureSst
(
    void* handle,
    double alphaK1,
    double alphaK2,
    double alphaOmega1,
    double alphaOmega2,
    double beta1,
    double beta2,
    double betaStar,
    double gamma1,
    double gamma2,
    double a1,
    double b1,
    double c1,
    double kMin,
    double omegaMin,
    double maxSourceNumber,
    int wallTreatment,
    double wallKappa,
    double wallE,
    double wallCmu,
    const double* k,
    const double* omega,
    const double* wallDistance,
    const int* boundaryKMode,
    const int* boundaryOmegaMode,
    const double* boundaryK,
    const double* boundaryOmega
)
{
    DeviceState* s = asState(handle);
    if (validateState(s, "configure SST") != 0)
    {
        return 1;
    }
    if (s->gasSpecies.mode != ugkwp::GasMode::SingleLegacy)
    {
        const auto capability=ugkwp::validateGasCapabilities
            (sharedGasCapabilityRequest(s,s->gasSpecies.mode,wallTreatment));
        if(!capability){setLastErrorText(capability.message);return 1;}
    }
    if
    (
        k == nullptr
     || omega == nullptr
     || wallDistance == nullptr
     || boundaryKMode == nullptr
     || boundaryOmegaMode == nullptr
     || boundaryK == nullptr
     || boundaryOmega == nullptr
    )
    {
        setLastErrorText("null SST configuration array");
        return 1;
    }
    if(wallTreatment<0 || wallTreatment>2)
    {setLastErrorText("unavailable SST wall operator");return 1;}
    for (int f = 0; f < s->nFaces; ++f)
    {
        if
        (
            boundaryKMode[f] < 0 || boundaryKMode[f] > 2
         || boundaryOmegaMode[f] < 0 || boundaryOmegaMode[f] > 2
        )
        {
            setLastErrorText("invalid SST boundary mode or value");
            return 1;
        }
    }

    const int previousConfigured=s->sstConfigured;
    const double previousKappa=s->sstWallKappa,previousE=s->sstWallE;
    const bool retainInventory=s->gasSpecies.mode!=ugkwp::GasMode::SingleLegacy&&previousConfigured;
    const bool updateConstants=previousKappa!=wallKappa||previousE!=wallE;
    const auto configurationFailed=[&](){


        s->sstConfigured=previousConfigured;
        s->sstWallKappa=previousKappa;s->sstWallE=previousE;
        return 1;
    };
    s->sstCoefficients = ugkwp::SstCoefficients
    {
        alphaK1,
        alphaK2,
        alphaOmega1,
        alphaOmega2,
        beta1,
        beta2,
        betaStar,
        gamma1,
        gamma2,
        a1,
        b1,
        c1
    };
    s->sstKMin = kMin;
    s->sstOmegaMin = omegaMin;
    s->sstMaxSourceNumber = maxSourceNumber;
    s->sstWallTreatment = wallTreatment;
    s->sstWallKappa = wallKappa;
    s->sstWallE = wallE;
    s->sstWallCmu = wallCmu;
    s->sstConfigured = 1;

    int rc = 0;
    const size_t nc = static_cast<size_t>(s->nCells);
    const size_t nf = static_cast<size_t>(s->nFaces);
    if(!retainInventory){
        rc |= copyToDevice(s->k, k, nc, "cudaMemcpy SST k");
        rc |= copyToDevice(s->omega, omega, nc, "cudaMemcpy SST omega");
    }
    rc |= copyToDevice
    (
        s->sstWallDistance,
        wallDistance,
        nc,
        "cudaMemcpy SST wallDistance"
    );
    rc |= copyToDevice
    (
        s->sstBoundaryKMode,
        boundaryKMode,
        nf,
        "cudaMemcpy SST boundaryKMode"
    );
    rc |= copyToDevice
    (
        s->sstBoundaryOmegaMode,
        boundaryOmegaMode,
        nf,
        "cudaMemcpy SST boundaryOmegaMode"
    );
    rc |= copyToDevice(s->sstBoundaryK, boundaryK, nf, "cudaMemcpy SST boundaryK");
    rc |= copyToDevice
    (
        s->sstBoundaryOmega,
        boundaryOmega,
        nf,
        "cudaMemcpy SST boundaryOmega"
    );
    if (rc != 0 || syncSstConfiguration(s, "cudaMemcpy SST configuration", retainInventory) != 0)
    {
        return configurationFailed();
    }

    invalidateSharedGasConfiguration(s);
    if(retainInventory&&!updateConstants)return 0;
    const int block = retainInventory ? 1 : s->fixedCellBlockThreads;
    const int grid = retainInventory ? 1 : (s->nCells + block - 1)/block;
    emulateLaunch([&](){initialiseSstConservativeStateKernel(s->deviceState, !retainInventory);},grid, block);
    cudaError_t err = cudaGetLastError();
    if (err == cudaSuccess)
    {
        err = cudaDeviceSynchronize();
    // Reuse this pre-existing completion point; do not add a synchronization.
    if(err==cudaSuccess) {
        err=s->diagnosticOwner->observeCompletedWork();
        if(s->diagnosticOwner->dispatchPending())return 1;
    }
    }
    if (err != cudaSuccess)
    {
        setLastError("initialiseSstConservativeStateKernel", err);
        return configurationFailed();
    }
    return 0;
}extern "C" int ugkwpGpuResidentStrictAdvanceGasOnly
(
    void* handle,
    double dt,
    double simulationTime
)
{
    DeviceState* s = asState(handle);
    if (validateState(s, "pure-gas advance") != 0)
    {
        return 1;
    }
    if (s->gasSpecies.mode == ugkwp::GasMode::SingleLegacy
        && tuneFixedWorkBlockThreads(s, dt, simulationTime) != 0)
    {
        return 1;
    }

    if (s->gasSpecies.mode != ugkwp::GasMode::SingleLegacy)
    {
        if (!s->gasSpeciesUploaded)
        {
            setLastErrorText("mixture advance requires initialized species state");
            return 1;
        }
        const GasRequestedIntervalControls<double> controls;
        return advanceGasRequestedInterval<SharedGasTrialPolicy>(s, dt, simulationTime, controls);
    }
std::abort();}

int main(){return 0;}
