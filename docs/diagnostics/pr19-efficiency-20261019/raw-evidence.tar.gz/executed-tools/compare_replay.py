from pathlib import Path
import json,hashlib,struct,math
W=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/perf-efficiency-20261019')
result={}
for label in ['homogeneous','heterogeneous']:
 for suffix in ['.csv','.csv.state.bin','.csv.profile.bin']:
  a=(W/'replay-current'/(label+suffix)).read_bytes();b=(W/'replay-candidate'/(label+suffix)).read_bytes()
  row={'bitwise_equal':a==b,'before_sha256':hashlib.sha256(a).hexdigest(),'after_sha256':hashlib.sha256(b).hexdigest()}
  if suffix.endswith('bin'):
   x=struct.unpack('d'*(len(a)//8),a);y=struct.unpack('d'*(len(b)//8),b)
   row['values']=len(x);row['max_absolute_difference']=max([abs(v-w) for v,w in zip(x,y) if math.isfinite(v) and math.isfinite(w)] or [0])
  result[label+suffix]=row
(W/'replay-equivalence.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
