from pathlib import Path
import subprocess,json,time
W=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/perf-efficiency-20261019');results=[]
for tool in ['memcheck','racecheck','synccheck']:
 d=W/'normal-sanitizers'/tool;start=time.monotonic()
 with (d/'run.log').open('w') as f:q=subprocess.run(['bash',str(d/'run.sh')],stdout=f,stderr=subprocess.STDOUT,timeout=600)
 row={'tool':tool,'command':['bash',str(d/'run.sh')],'exit':q.returncode,'elapsed_seconds':time.monotonic()-start,'summaries':[]}
 for log in d.glob('sanitizer-*.log'):
  row['summaries'] += [{'file':str(log),'summary':s} for s in log.read_text().splitlines() if 'SUMMARY' in s]
 results.append(row);(W/'normal-sanitizers/results.json').write_text(json.dumps(results,indent=2));print(row,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
