from pathlib import Path
import shutil,json,hashlib,subprocess
T=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');W=T/'perf-efficiency-20261019';E=T/'perf-regression-20261019'
source=Path('/home/lss/ARC3696-runs/manual/M0p55/pr19-merged-20261018T212224/baseline-mhx4dmqp')
manifest={}
for name,binaries in [('main',E/'old/bin'),('current',E/'current/bin'),('candidate',W/'install/bin')]:
 d=W/'normal-ab'/name;d.mkdir(parents=True,exist_ok=False)
 for part in ['0','constant','system']:shutil.copytree(source/part,d/'case'/part)
 for part in ['bin','lib','tmp','cache']:(d/part).mkdir()
 for binary in ['gasUGKP','gasUGKPCudaBackend']:shutil.copy2(binaries/binary,d/'bin'/binary)
 control=d/'case/system/controlDict';s=control.read_text().replace('endTime 0.05772685217891481;','endTime 0.0001;').replace('writeInterval 0.0005;','writeInterval 0.0001;').replace('logInterval 1000;','logInterval 1;');control.write_text(s)
 script='''#!/bin/bash
source /opt/openfoam10/etc/bashrc
set -eo pipefail
ulimit -s 65536
export RUN_ROOT="'''+str(d)+'''"
export FOAM_USER_APPBIN="$RUN_ROOT/bin" FOAM_USER_LIBBIN="$RUN_ROOT/lib"
export CUDA_HOME=/usr/local/cuda-13.1 CUDA_CACHE_PATH="$RUN_ROOT/cache/cuda" XDG_CACHE_HOME="$RUN_ROOT/cache" TMPDIR="$RUN_ROOT/tmp"
export PATH="$FOAM_USER_APPBIN:$FOAM_APPBIN:$CUDA_HOME/bin:/usr/bin:/bin:$WM_PROJECT_DIR/wmake"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN/dummy:$CUDA_HOME/lib64"
unset GAS_UGKP_CUDA_BACKEND UGKP_GAS_BUDGET_OUTPUT
exec "$FOAM_USER_APPBIN/gasUGKP" -case "$RUN_ROOT/case"
'''
 (d/'run.sh').write_text(script)
 manifest[name]={'source_case':str(source),'command':['bash',str(d/'run.sh')],
 'inputs':{p.relative_to(d/'case').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (d/'case').rglob('*') if p.is_file()},
 'binaries':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (d/'bin').iterdir()}}
assert manifest['main']['inputs']==manifest['current']['inputs']==manifest['candidate']['inputs']
(W/'normal-ab/manifest.json').write_text(json.dumps(manifest,indent=2))
print('prepared normal startTime=0 three-way comparison,',len(manifest['main']['inputs']),'identical files')
