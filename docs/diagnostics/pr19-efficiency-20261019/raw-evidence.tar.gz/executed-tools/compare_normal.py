from pathlib import Path
import json,re,hashlib
W=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/perf-efficiency-20261019');D=W/'normal-ab';result={};steps={}
for version in ['main','current','candidate']:
 s=(D/version/'run.log').read_text();assert s.rstrip().endswith('End')
 rows=[{'step':int(m[0]),'time':m[1],'dt':m[2],'elapsed':int(m[3])} for m in re.findall(r'UGKP_REPRO step=(\d+) time=([^ ]+) dt=([^ ]+) elapsed=(\d+)',s)];steps[version]=rows
 by={r['step']:r for r in rows};result[version]={'steps':len(rows),'final':rows[-1],'interval_100_224_seconds':by[224]['elapsed']-by[100]['elapsed'],'interval_100_224_seconds_per_step':(by[224]['elapsed']-by[100]['elapsed'])/124,'interval_50_224_seconds_per_step':(by[224]['elapsed']-by[50]['elapsed'])/174}
result['current_candidate_time_dt_exact']=all((a['step'],a['time'],a['dt'])==(b['step'],b['time'],b['dt']) for a,b in zip(steps['current'],steps['candidate']))
result['fields']={}
a=D/'current/case/0.0001';b=D/'candidate/case/0.0001'
for p in a.rglob('*'):
 if p.is_file():
  rel=p.relative_to(a);x=p.read_bytes();y=(b/rel).read_bytes()
  result['fields'][str(rel)]={'equal':x==y,'current_sha256':hashlib.sha256(x).hexdigest(),'candidate_sha256':hashlib.sha256(y).hexdigest(),'bytes':len(x)}
result['all_fields_equal']=all(v['equal'] for v in result['fields'].values())
(D/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='fields'},indent=2));print('fields',len(result['fields']),'different',[k for k,v in result['fields'].items() if not v['equal']])
