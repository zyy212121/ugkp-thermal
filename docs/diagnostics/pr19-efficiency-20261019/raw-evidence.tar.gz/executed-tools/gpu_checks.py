from pathlib import Path
import subprocess,json,sys
T=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');R=T/'pr19-efficiency-20261019';W=T/'perf-efficiency-20261019';D=W/'gpu-checks';D.mkdir(exist_ok=True)
work=Path(__file__).resolve().parent
records=[]
for name in ['pool','sst_globalization','wall_trial_storage','wall_composition']:
 source=work/'pool_gpu.cu' if name=='pool' else R/'validation/tests/gas_wall/fixtures'/(name+'_gpu.cu')
 cmd=['/usr/local/cuda-13.1/bin/nvcc','-std=c++17','-O3','-lineinfo','--fmad=true','-arch=sm_89','-I'+str(R),str(source),'-o',str(D/name)]
 with (D/(name+'-build.log')).open('w') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 records.append({'name':name,'build':cmd,'exit':q.returncode});print(name,'build',q.returncode,flush=True)
 if q.returncode:break
 for tool in ['run','memcheck','racecheck','synccheck']:
  cmd=[str(D/name)] if tool=='run' else ['/usr/local/cuda-13.1/bin/compute-sanitizer','--tool',tool,'--error-exitcode','99',str(D/name)]
  with (D/(name+'-'+tool+'.log')).open('w') as f:q=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  records.append({'name':name,'tool':tool,'command':cmd,'exit':q.returncode});print(name,tool,q.returncode,flush=True)
  (D/'results.json').write_text(json.dumps(records,indent=2))
  if q.returncode:sys.exit(q.returncode)
print('all checks completed',flush=True)
