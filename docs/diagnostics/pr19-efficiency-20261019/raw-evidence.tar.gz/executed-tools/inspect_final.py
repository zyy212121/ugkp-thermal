from pathlib import Path
import re,json,subprocess,hashlib,struct,math,csv,collections
W=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/perf-efficiency-20261019');D=W/'final-replay'
equivalence={}
for group in ['homogeneous','heterogeneous']:
 for suffix in ['.csv','.csv.state.bin','.csv.profile.bin']:
  reference=(D/('current-'+group+'-0'+suffix)).read_bytes()
  for round in range(3):
   v=(D/('candidate-'+group+'-'+str(round)+suffix)).read_bytes()
   equivalence[f'{group}-{round}{suffix}']={'bitwise_equal':v==reference,'sha256':hashlib.sha256(v).hexdigest()}
assert all(v['bitwise_equal'] for v in equivalence.values())
(D/'equivalence.json').write_text(json.dumps(equivalence,indent=2))
work={}
for group in ['homogeneous','heterogeneous']:
 for version in ['main','current','candidate']:
  rows=list(csv.DictReader((D/f'{version}-{group}-0.csv').open()));iters=[int(r['iterations']) for r in rows]
  work[version+'-'+group]={'faces':len(rows),'iterations_sum':sum(iters),'iterations_histogram':dict(sorted(collections.Counter(iters).items())),'iterations_max':max(iters),'residual_max':max(float(r['residual']) for r in rows),'heat_min':min(float(r['heat']) for r in rows),'heat_max':max(float(r['heat']) for r in rows)}
(D/'mathematical-work.json').write_text(json.dumps(work,indent=2))
lines=(W/'capacity-variant/build.log').read_text().splitlines();entry='';records=[]
for i,line in enumerate(lines):
 if 'Compiling entry function' in line:entry=line
 if 'Function properties for ' in line:
  symbol=line.split('Function properties for ')[1];demangled=subprocess.check_output(['c++filt',symbol],text=True).strip()
  if any(x in demangled for x in ['evaluateGasBoundaryLayerTeamKernel','assembleJacobianNode','seedSstLayer','applyLayerNewtonUpdate','publishLayer']):
   records.append({'entry':entry,'function':demangled,'spill':lines[i+1]})
(W/'wall-resource-context.json').write_text(json.dumps(records,indent=2))
print('final replay all three rounds bitwise equal; work:',json.dumps(work,indent=2))
for row in records:
 if 'Lb1ELi24E' in row['entry']:print(row['function'][:120],row['spill'])
