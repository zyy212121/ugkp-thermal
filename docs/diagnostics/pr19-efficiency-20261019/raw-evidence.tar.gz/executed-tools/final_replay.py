from pathlib import Path
import subprocess,json,time,hashlib,statistics,re
T=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');W=T/'perf-efficiency-20261019';E=Path('/mnt/d/tempt/ugkp-pr19-gas-performance-regression-20261019');D=W/'final-replay';D.mkdir(exist_ok=True)
records=[]
for round,names in enumerate([['main','current','candidate'],['candidate','main','current'],['current','candidate','main']]):
 for label,inp in [('homogeneous','captured004-homogeneous336.csv'),('heterogeneous','actual-wall-input-first-restart-step.csv')]:
  for name in names:
   exe=W/('replay-'+name)/'replay';out=D/(name+'-'+label+'-'+str(round)+'.csv');cmd=[str(exe),str(E/inp),str(out)]
   q=subprocess.run(cmd,capture_output=True,text=True);log=q.stdout+q.stderr;(D/(out.stem+'.log')).write_text(log)
   row={'name':name,'label':label,'round':round,'command':cmd,'exit':q.returncode,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'stdout':q.stdout,'stderr':q.stderr}
   if q.returncode:raise RuntimeError(row)
   row['median_ms']=float(re.search(r'median_ms=([\d.]+)',q.stdout)[1]);row['samples_ms']=[float(x) for x in re.search(r'samples_ms=([^\n]+)',q.stdout)[1].strip(',').split(',')]
   records.append(row);(D/'runs.json').write_text(json.dumps(records,indent=2));print(name,label,round,row['median_ms'],flush=True)
summary={}
for label in ['homogeneous','heterogeneous']:
 for name in ['main','current','candidate']:
  values=[v for r in records if r['label']==label and r['name']==name for v in r['samples_ms']]
  summary[name+'-'+label]={'median_ms':statistics.median(values),'min_ms':min(values),'max_ms':max(values),'samples':len(values)}
(D/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
