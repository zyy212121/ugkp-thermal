#!/bin/bash
source /opt/openfoam10/etc/bashrc
set -eo pipefail
ulimit -s 65536
export RUN_ROOT="/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/perf-efficiency-20261019/normal-sanitizers/synccheck"
export FOAM_USER_APPBIN="$RUN_ROOT/bin" FOAM_USER_LIBBIN="$RUN_ROOT/lib"
export CUDA_HOME=/usr/local/cuda-13.1 CUDA_CACHE_PATH="$RUN_ROOT/cache/cuda" XDG_CACHE_HOME="$RUN_ROOT/cache" TMPDIR="$RUN_ROOT/tmp"
export PATH="$FOAM_USER_APPBIN:$FOAM_APPBIN:$CUDA_HOME/bin:/usr/bin:/bin:$WM_PROJECT_DIR/wmake"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN/dummy:$CUDA_HOME/lib64"
unset GAS_UGKP_CUDA_BACKEND UGKP_GAS_BUDGET_OUTPUT
exec /usr/local/cuda-13.1/bin/compute-sanitizer --tool synccheck --target-processes all --error-exitcode 99 --log-file "/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/perf-efficiency-20261019/normal-sanitizers/synccheck/sanitizer-%p.log" "$FOAM_USER_APPBIN/gasUGKP" -case "$RUN_ROOT/case"
