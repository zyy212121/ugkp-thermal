exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
P=T/'perf-efficiency-20261019'
items=[('normal-ab/baseline','normal-ab/candidate',P/'install'),('normal-ab/candidate','normal-ab/candidate',W/'install')]
items += [('normal-sanitizers/'+tool,'normal-sanitizers/'+tool,W/'install') for tool in ['memcheck','racecheck','synccheck']]
manifest={}
for target,origin,install in items:
 to=W/target;src=P/origin;to.mkdir(parents=True,exist_ok=True)
 for part in ['0','constant','system']:shutil.copytree(W/'normal-original-input'/part,to/'case'/part,dirs_exist_ok=True)
 for part in ['tmp','cache','lib']:(to/part).mkdir(exist_ok=True)
 (to/'bin').symlink_to(install/'bin',target_is_directory=True) if not (to/'bin').is_symlink() else None
 script=(src/'run.sh').read_text().replace(str(src),str(to));(to/'run.sh').write_text(script)
 if target.startswith('normal-sanitizers/'):
  cp=to/'case/system/controlDict';cp.write_text(cp.read_text().replace('endTime 0.0001;', 'endTime 3e-7;').replace('adjustTimeStep true;', 'adjustTimeStep false;'))
 manifest[target]={str(p.relative_to(to/'case')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (to/'case').rglob('*') if p.is_file()}
assert manifest['normal-ab/baseline']==manifest['normal-ab/candidate']
(W/'normal-inputs.json').write_text(json.dumps(manifest,indent=2));print('normal A/B identical inputs',len(manifest['normal-ab/baseline']))
