exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
import datetime
variant=sys.argv[1];source=B if variant=='baseline' else R
paths=['validation/tests/gas_wall','validation/tests/gas_transport','validation/tests/test_diagnostics_core.py','validation/tests/test_diagnostic_ipc_transport.py','validation/tests/test_final_diagnostic_integration.py','validation/tests/test_sst_courant_mass_flux.py','validation/tests/test_sst_internal_diffusion.py','validation/tests/test_sst_flux_consistency.py']
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','common','applications','validation/tests'],cwd=source,text=True).splitlines()
def hashes():return {p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in files if (source/p).is_file()}
before=hashes();cmd=['python3','-m','pytest','--assert=plain','-q',*paths]
record={'variant':variant,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'command':cmd,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_hashes':before}
(W/(variant+'-full-tests-manifest.json')).write_text(json.dumps(record,indent=2))
with (W/(variant+'-full-tests.log')).open('w') as f:q=subprocess.run(cmd,cwd=source,stdout=f,stderr=subprocess.STDOUT)
after=hashes();record.update(exit=q.returncode,ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_fixed=before==after)
(W/(variant+'-full-tests-manifest.json')).write_text(json.dumps(record,indent=2));print({k:v for k,v in record.items() if k!='source_hashes'},flush=True)
assert before==after
