exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
label=sys.argv[1];S=W/label;S.mkdir(exist_ok=True)
source=B if label=='baseline' else R
cmd=['python3',str(D/'tools/reproduce.py'),'--source',str(source),'--out',str(S),'--rounds','1']
(S/'source.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--','common','applications'],cwd=source))
for name in ['common/gasWall/ReactingWallLayer.H','common/gasTransport/MixtureThermo.H']:
 shutil.copyfile(source/name,S/Path(name).name)
q=subprocess.run(cmd,capture_output=True,text=True);(S/'driver.log').write_text(q.stdout+q.stderr)
print(label,q.returncode,q.stdout[-2600:],q.stderr[-1000:],flush=True)
q.check_returncode()
if label!='baseline':
 comparisons={}
 for kind in ['homogeneous','heterogeneous']:
  for ext in ['.csv','.csv.state.bin','.csv.profile.bin']:
   name=kind+'-0'+ext
   comparisons[name]=(S/name).read_bytes()==(W/'baseline'/name).read_bytes()
 (S/'comparison.json').write_text(json.dumps(comparisons,indent=2));print(comparisons,flush=True)
