from pathlib import Path
import subprocess,json,csv,hashlib
T=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test')
R=T/'pr19-math-merged-20261018';W=T/'perf-wall-reuse-20261019';D=W/'scan';D.mkdir(exist_ok=True)
src=Path('/mnt/d/tempt/ugkp-pr19-math-fixes-20261018/wallchem/wall-probe.cpp')
cmd=['g++','-std=c++17','-O2','-ffp-contract=off','-I'+str(R),str(src),'-o',str(D/'scan')]
(D/'command.json').write_text(json.dumps(cmd,indent=2))
q=subprocess.run(cmd,capture_output=True,text=True);(D/'build.log').write_text(q.stdout+q.stderr)
assert q.returncode==0,q.stderr
with (D/'output.csv').open('w') as out,(D/'input.csv').open('w') as err:
 q=subprocess.run([str(D/'scan'),'1000'],stdout=out,stderr=err)
base=Path('/mnt/d/tempt/ugkp-pr19-state-unique-fixes-20261018/wall/scan-final.csv')
summary={'exit':q.returncode,'rows':len((D/'output.csv').read_text().splitlines()),'same_output':base.read_bytes()==(D/'output.csv').read_bytes(),
         'same_inputs':(D/'input.csv').read_bytes()==base.with_name('scan-final-input.csv').read_bytes()}
(D/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
