exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
S=W/'gpu-checks';S.mkdir(exist_ok=True);records=[]
fixtures=['sst_globalization','wall_composition','wall_trial_storage','wall_workspace_pool']
for name in fixtures:
 cmd=['/usr/local/cuda-13.1/bin/nvcc','-std=c++17','-O3','-lineinfo','--fmad=true','-arch=sm_89','-Xptxas=-v','-I'+str(R),str(R/'validation/tests/gas_wall/fixtures'/(name+'_gpu.cu')),'-o',str(S/name)]
 q=subprocess.run(cmd,capture_output=True,text=True);(S/(name+'-build.log')).write_text(q.stdout+q.stderr);records.append({'name':name,'operation':'build','command':cmd,'exit':q.returncode});q.check_returncode()
 for tool in ['run','memcheck','racecheck','synccheck']:
  cmd=[str(S/name)] if tool=='run' else ['/usr/local/cuda-13.1/bin/compute-sanitizer','--tool',tool,'--error-exitcode','99',str(S/name)]
  q=subprocess.run(cmd,capture_output=True,text=True,timeout=600);(S/(name+'-'+tool+'.log')).write_text(q.stdout+q.stderr)
  records.append({'name':name,'operation':tool,'command':cmd,'exit':q.returncode,'summaries':[x for x in (q.stdout+q.stderr).splitlines() if 'SUMMARY' in x]});(S/'results.json').write_text(json.dumps(records,indent=2));print(name,tool,q.returncode,flush=True);q.check_returncode()
old=T/'perf-efficiency-20261019/gpu-checks/pool'
q=subprocess.run([str(old)],capture_output=True,text=True);q.check_returncode();(S/'pool-baseline.log').write_text(q.stdout+q.stderr)
same=(S/'pool-baseline.log').read_bytes()==(S/'wall_workspace_pool-run.log').read_bytes();assert same
for tool in ['memcheck','racecheck','synccheck']:
 cmd=['/usr/local/cuda-13.1/bin/compute-sanitizer','--tool',tool,'--error-exitcode','99',str(W/'courant/probe')]
 q=subprocess.run(cmd,capture_output=True,text=True,timeout=600);(S/('courant-'+tool+'.log')).write_text(q.stdout+q.stderr)
 records.append({'name':'courant','operation':tool,'command':cmd,'exit':q.returncode,'summaries':[x for x in (q.stdout+q.stderr).splitlines() if 'SUMMARY' in x]});(S/'results.json').write_text(json.dumps(records,indent=2));print('courant',tool,q.returncode,flush=True);q.check_returncode()
print('Pool full output bitwise identical',same,flush=True)
