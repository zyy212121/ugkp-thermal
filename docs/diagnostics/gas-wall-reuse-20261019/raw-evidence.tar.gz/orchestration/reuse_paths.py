from pathlib import Path
import subprocess,json,sys,hashlib,shutil,statistics,re
T=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test');R=T/'pr19-math-merged-20261018';B=T/'pr19-efficiency-20261019';W=T/'perf-wall-reuse-20261019'
D=R/'docs/diagnostics/pr19-efficiency-20261019'
