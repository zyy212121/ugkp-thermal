exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
S=W/'grid-experiment';S.mkdir(exist_ok=True);shutil.copytree(R/'common',S/'common',dirs_exist_ok=True)
p=S/'common/gasWall/ReactingWallLayer.H';s=p.read_text();assert s.count('::pow(eta,c.stretch)')==1;s=s.replace('::pow(eta,c.stretch)','::experimentGridValue(i,eta,c.stretch)');p.write_text(s)
prefix='''#include <cuda_runtime.h>
#include <cmath>
__device__ double experimentGrid[128];
__host__ __device__ inline double experimentGridValue(int i,double eta,double stretch){
#if defined(__CUDA_ARCH__)
 return experimentGrid[i];
#else
 return ::pow(eta,stretch);
#endif
}
__global__ void prepareExperimentGrid(int nodes,double stretch){int i=threadIdx.x;if(i<nodes)experimentGrid[i]=::pow(double(i)/double(nodes-1),stretch);}
'''
s=prefix+(D/'tools/wall_replay.cu').read_text();s=s.replace('std::vector<Input> hostIn(count,capture.input);','prepareExperimentGrid<<<1,128>>>(capture.config.nodes,capture.config.stretch);check(cudaGetLastError());\nstd::vector<Input> hostIn(count,capture.input);');(S/'replay.cu').write_text(s)
cmd=['/usr/local/cuda-13.1/bin/nvcc','-std=c++17','-O3','-lineinfo','--fmad=true','-arch=sm_89','-Xptxas=-v','-I'+str(S),'-I'+str(R),str(S/'replay.cu'),'-o',str(S/'replay')]
q=subprocess.run(cmd,capture_output=True,text=True);(S/'build.log').write_text(q.stdout+q.stderr);q.check_returncode();print('grid experiment compiled')
