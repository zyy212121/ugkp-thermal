exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
label=sys.argv[1]
if label=='grid':variants=['wall-final','grid-experiment'];kinds=['homogeneous']
else:variants=['baseline','velocity-pair','pair-cph','seed-thermo','wall-final'];kinds=['homogeneous','heterogeneous']
out=W/('timing-'+label);out.mkdir(exist_ok=True);rows=[]
for round in range(3):
 for variant in variants[::1 if round%2==0 else -1]:
  for kind in kinds:
   inp=D/'inputs'/('captured004-homogeneous336.csv' if kind=='homogeneous' else 'actual-wall-input-first-restart-step.csv')
   target=out/f'{variant}-{kind}-{round}.csv'
   q=subprocess.run([str(W/variant/'replay'),str(inp),str(target)],capture_output=True,text=True);q.check_returncode()
   target.with_suffix('.log').write_text(q.stdout+q.stderr)
   samples=[float(v) for v in re.search(r'samples_ms=([^\n]+)',q.stdout)[1].strip(',').split(',')]
   same=all(target.with_name(target.name+ext).read_bytes()==(W/'baseline'/(kind+'-0.csv'+ext)).read_bytes() for ext in ['', '.state.bin','.profile.bin'])
   assert same
   rows.append({'variant':variant,'kind':kind,'round':round,'samples':samples,'same_bits':same});(out/'runs.json').write_text(json.dumps(rows,indent=2))
   print(variant,kind,round,statistics.median(samples),flush=True)
summary={}
for v in variants:
 for k in kinds:
  samples=sum((r['samples'] for r in rows if r['variant']==v and r['kind']==k),[])
  summary[v+'-'+k]={'median':statistics.median(samples),'min':min(samples),'max':max(samples),'n':len(samples)}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
