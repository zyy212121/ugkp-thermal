exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
import time,datetime,csv,collections
scripts=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work')
while 'ended' not in json.loads((W/'candidate-full-tests-manifest.json').read_text()):time.sleep(5)
def test_result(name):
 s=(W/(name+'-full-tests.log')).read_text();lines=s.splitlines()
 summary=next(x for x in reversed(lines) if re.search(r'\d+ passed',x) and ' in ' in x)
 failures=sorted({x.split(' - ')[0] for x in lines if x.startswith(('FAILED ','ERROR '))})
 assert json.loads((W/(name+'-full-tests-manifest.json')).read_text())['source_fixed']
 return {'summary':summary,'failures':failures}
a=test_result('baseline');b=test_result('candidate');comparison={'baseline':a,'candidate':b,'new_failures':sorted(set(b['failures'])-set(a['failures'])),'removed_failures':sorted(set(a['failures'])-set(b['failures']))}
(W/'test-comparison.json').write_text(json.dumps(comparison,indent=2));print('TEST COMPARISON',json.dumps({k:v for k,v in comparison.items() if k not in ['baseline','candidate']}),a['summary'],b['summary'],flush=True)
assert not comparison['new_failures']
subprocess.run(['python3',str(scripts/'reuse_runs.py'),'final'],check=True)
(W/'timing-grid').rename(W/'timing-grid-initial')
subprocess.run(['python3',str(scripts/'reuse_runs.py'),'grid'],check=True)
S=W/'boundary-gpu';(S/'results.csv').rename(S/'results-during-tests.csv')
q=subprocess.run([str(S/'benchmark')],capture_output=True,text=True);q.check_returncode();(S/'results.csv').write_text(q.stdout);print('BOUNDARY',q.stdout,flush=True)
for i in range(3):
 q=subprocess.run([str(W/'courant/probe')],capture_output=True,text=True);q.check_returncode();(W/'courant'/f'idle-{i}.log').write_text(q.stdout);print('COURANT',i,q.stdout,flush=True)
normal=[]
for name in ['baseline','candidate']:
 d=W/'normal-ab'/name;started=time.monotonic()
 with (d/'run.log').open('w') as f:q=subprocess.run(['bash',str(d/'run.sh')],stdout=f,stderr=subprocess.STDOUT,timeout=600)
 normal.append({'variant':name,'exit':q.returncode,'seconds':time.monotonic()-started,'command':['bash',str(d/'run.sh')]});(W/'normal-ab/runs.json').write_text(json.dumps(normal,indent=2));print('NORMAL',normal[-1],flush=True);q.check_returncode()
result={};steps={}
for name in ['baseline','candidate']:
 s=(W/'normal-ab'/name/'run.log').read_text();assert s.rstrip().endswith('End')
 rows=[{'step':int(m[0]),'time':m[1],'dt':m[2],'elapsed':int(m[3])} for m in re.findall(r'UGKP_REPRO step=(\d+) time=([^ ]+) dt=([^ ]+) elapsed=(\d+)',s)];steps[name]=rows;by={r['step']:r for r in rows}
 result[name]={'steps':len(rows),'final':rows[-1],'interval_100_224_seconds':by[224]['elapsed']-by[100]['elapsed'],'seconds_per_step_100_224':(by[224]['elapsed']-by[100]['elapsed'])/124}
result['time_dt_exact']=len(steps['baseline'])==len(steps['candidate']) and all((a['step'],a['time'],a['dt'])==(b['step'],b['time'],b['dt']) for a,b in zip(steps['baseline'],steps['candidate']))
result['fields']={};a=W/'normal-ab/baseline/case/0.0001';b=W/'normal-ab/candidate/case/0.0001'
for p in a.rglob('*'):
 if p.is_file():
  rel=p.relative_to(a);x=p.read_bytes();y=(b/rel).read_bytes();result['fields'][str(rel)]={'equal':x==y,'baseline_sha256':hashlib.sha256(x).hexdigest(),'candidate_sha256':hashlib.sha256(y).hexdigest()}
result['all_fields_equal']=bool(result['fields']) and all(x['equal'] for x in result['fields'].values());(W/'normal-ab/comparison.json').write_text(json.dumps(result,indent=2))
assert result['time_dt_exact'] and result['all_fields_equal']
print('NORMAL COMPARISON',json.dumps({k:v for k,v in result.items() if k!='fields'}),'fields',len(result['fields']),flush=True)
work={}
for kind in ['homogeneous','heterogeneous']:
 for name in ['baseline','wall-final']:
  rows=list(csv.DictReader((W/'timing-final'/f'{name}-{kind}-0.csv').open()));iters=[int(r['iterations']) for r in rows]
  work[name+'-'+kind]={'faces':len(rows),'iterations_sum':sum(iters),'iterations_histogram':dict(sorted(collections.Counter(iters).items())),'iterations_max':max(iters),'residual_max':max(float(r['residual']) for r in rows),'heat_min':min(float(r['heat']) for r in rows),'heat_max':max(float(r['heat']) for r in rows)}
(W/'mathematical-work.json').write_text(json.dumps(work,indent=2))
