exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
sys.path.insert(0,str(R));from validation.tests.gas_transport.test_boundary_launch_range import test_boundary_local_indices_preserve_all_three_operators
S=W/'boundary-gpu';S.mkdir(exist_ok=True);test_boundary_local_indices_preserve_all_three_operators(S)
s=(S/'boundary.cpp').read_text().split('int main(){')[0]
s=s.replace('#define __global__','').replace('struct Index{int x=0;}blockIdx,blockDim,threadIdx;','')
for name in ['double clampMin','double finiteOr','bool scheduledInletFaceDevice','double scheduledPressureDevice','int coupledFaceNeighbour']:s=s.replace(name,'__device__ '+name)
s=s.replace('std::isfinite(a)','isfinite(a)').replace('[101]{}','[1048576]')
fields=re.findall(r'(int|double) (\w+)\[1048576\]',s)
initial='\n'.join(' a.'+name+'[i]='+('i%7' if name=='faceOwner' else '0' if typ=='int' and name not in ['gasBoundaryPWave','riemannBoundaryPWave'] else '1')+';' for typ,name in fields)
comparison='||'.join('a->'+name+'[i]!=b->'+name+'[i]' for typ,name in fields)
s='#include <cuda_runtime.h>\n#include <cstdio>\n'+s+'''
void check(cudaError_t e){if(e!=cudaSuccess){fprintf(stderr,"%s\\n",cudaGetErrorString(e));exit(1);}}
__global__ void initialize(State* sp,int n,int internal){auto& a=*sp;int i=blockIdx.x*blockDim.x+threadIdx.x;
 if(i==0){a.nFaces=n;a.nInternalFaces=internal;a.nCells=7;a.scheduledInletTemperature=300;a.TgasMin=1;a.rhoMin=1e-9;a.Rgas=287;}
 if(i<n){
'''+initial+'''
 }}
__global__ void compare(const State* a,const State* b,int n,int* mismatch){int i=blockIdx.x*blockDim.x+threadIdx.x;
 if(i<n&&('''+comparison+'''))atomicAdd(mismatch,1);
}
void launch(State* p,int faces,int boundary,bool optimized){int grid=((optimized?boundary:faces)+127)/128;if(!grid)return;
 if(optimized){updateLegacyGasBoundaryMirrorKernel<<<grid,128>>>(p,.3);updateRiemannBoundaryMirrorKernel<<<grid,128>>>(p);updateWaveTransmissivePressureBoundaryKernel<<<grid,128>>>(p,.01);}
 else{reference_updateLegacyGasBoundaryMirrorKernel<<<grid,128>>>(p,.3);reference_updateRiemannBoundaryMirrorKernel<<<grid,128>>>(p);reference_updateWaveTransmissivePressureBoundaryKernel<<<grid,128>>>(p,.01);}
}
int main(){State *a,*b;int *m;check(cudaMalloc(&a,sizeof(State)));check(cudaMalloc(&b,sizeof(State)));check(cudaMalloc(&m,sizeof(int)));
 cudaEvent_t begin,end;check(cudaEventCreate(&begin));check(cudaEventCreate(&end));
 puts("faces,boundary,old_threads,new_threads,old_ms,new_ms,equal");
 for(int n:{4096,65536,1048576})for(int boundary:{0,1,336,4096}){
  initialize<<<(n+127)/128,128>>>(a,n,n-boundary);initialize<<<(n+127)/128,128>>>(b,n,n-boundary);
  float elapsed[2];for(int variant=0;variant<2;++variant){for(int i=0;i<4;++i)launch(variant?b:a,n,boundary,variant);
   check(cudaEventRecord(begin));for(int i=0;i<100;++i)launch(variant?b:a,n,boundary,variant);check(cudaEventRecord(end));check(cudaEventSynchronize(end));check(cudaEventElapsedTime(&elapsed[variant],begin,end));}
  check(cudaMemset(m,0,sizeof(int)));compare<<<(n+127)/128,128>>>(a,b,n,m);int mismatch=0;check(cudaMemcpy(&mismatch,m,sizeof(int),cudaMemcpyDeviceToHost));assert(mismatch==0);
  printf("%d,%d,%d,%d,%.9g,%.9g,1\\n",n,boundary,3*((n+127)/128)*128,3*((boundary+127)/128)*128,elapsed[0]/100,elapsed[1]/100);
 }
 check(cudaFree(a));check(cudaFree(b));check(cudaFree(m));
}
'''
(S/'benchmark.cu').write_text(s)
cmd=['/usr/local/cuda-13.1/bin/nvcc','-std=c++17','-O3','-arch=sm_89',str(S/'benchmark.cu'),'-o',str(S/'benchmark')]
q=subprocess.run(cmd,capture_output=True,text=True);(S/'build.log').write_text(q.stdout+q.stderr);q.check_returncode()
q=subprocess.run([str(S/'benchmark')],capture_output=True,text=True);(S/'results.csv').write_text(q.stdout);(S/'run-error.log').write_text(q.stderr);print(q.stdout,q.stderr,flush=True);q.check_returncode()
