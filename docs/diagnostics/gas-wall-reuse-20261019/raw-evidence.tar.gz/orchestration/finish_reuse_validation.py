exec(open('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work/reuse_paths.py').read())
scripts=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-19/ugkp-thermal-pr19-pr-https-github/work')
cmd=['python3','-m','pytest','--assert=plain','-q','validation/tests/gas_wall/test_wall_finite_publication.py::test_signed_seed_delta_preserves_original_internal_rejection','validation/tests/gas_wall/test_wall_shared_evaluation.py','validation/tests/gas_transport/test_postreview_algebra_diagnostics.py','validation/tests/gas_transport/test_boundary_launch_range.py']
with (W/'final-changed-path-tests.log').open('w') as f:q=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
print((W/'final-changed-path-tests.log').read_text(),flush=True);q.check_returncode()
import time,datetime,csv,collections
text=(scripts/'reuse_final_validation.py').read_text()
exec(text[text.index("subprocess.run(['python3',str(scripts/'reuse_runs.py'),'final']"):])
for suffix in ['.log','-manifest.json']:
 (W/('candidate-full-tests'+suffix)).rename(W/('pre-probe-fix-candidate-full-tests'+suffix))
subprocess.run(['python3',str(scripts/'reuse_full_tests.py'),'candidate'],check=True)
exec(text[text.index('def test_result('):text.index("subprocess.run(['python3',str(scripts/'reuse_runs.py'),'final']")])
