#include <cuda_runtime.h>
#include <cstdio>
#include <initializer_list>

#include <cmath>
#include <cstring>
#include <cassert>

#define GPU_OPERATOR_REAL double
#define GPU_OPERATOR_TIME double
#define GPU_OPERATOR_R(x) (x)
#define GPU_OPERATOR_TINY(x) (x)

constexpr double OfSmall=1e-15,OfVSmall=1e-300;
__device__ double clampMin(double a,double b){return a<b?b:a;}
__device__ double finiteOr(double a,double b){return isfinite(a)?a:b;}
struct State{int nInternalFaces=0,nFaces=0,nCells=7;double scheduledInletTemperature=300,TgasMin=1,rhoMin=1e-9,Rgas=287;
double Sfx[1048576];
double Sfy[1048576];
double Sfz[1048576];
double Tgas[1048576];
double Ux[1048576];
double Uy[1048576];
double Uz[1048576];
double deltaCoeffs[1048576];
int faceOwner[1048576];
int gasBoundaryKind[1048576];
double gasBoundaryP[1048576];
int gasBoundaryPFix[1048576];
int gasBoundaryPWave[1048576];
double gasBoundaryPWaveFieldInf[1048576];
double gasBoundaryPWaveGamma[1048576];
double gasBoundaryPWaveLInf[1048576];
double gasBoundaryRho[1048576];
int gasBoundaryRhoFix[1048576];
double gasBoundaryT[1048576];
int gasBoundaryTFix[1048576];
int gasBoundaryUFix[1048576];
double gasBoundaryUx[1048576];
double gasBoundaryUy[1048576];
double gasBoundaryUz[1048576];
double magSf[1048576];
double p[1048576];
double rho[1048576];
int riemannBoundaryKind[1048576];
double riemannBoundaryP[1048576];
int riemannBoundaryPFix[1048576];
int riemannBoundaryPWave[1048576];
double riemannBoundaryRho[1048576];
int riemannBoundaryRhoFix[1048576];
double riemannBoundaryT[1048576];
int riemannBoundaryTFix[1048576];
int riemannBoundaryUFix[1048576];
double riemannBoundaryUx[1048576];
double riemannBoundaryUy[1048576];
double riemannBoundaryUz[1048576];};
__device__ bool scheduledInletFaceDevice(const State&,int f){return f%11==0;}
__device__ double scheduledPressureDevice(const State&,double t){return 100000+t;}
__device__ int coupledFaceNeighbour(const State&,int f){return (f+1)%7;}
#pragma once
// One operator implementation; scalar/time adapters are compile-time only.
template<class GasState>
__global__ void reference_updateLegacyGasBoundaryMirrorKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME simulationTime
)
{
    GasState& s = *sp;
    const int f = blockIdx.x*blockDim.x + threadIdx.x;
    if (f < s.nInternalFaces || f >= s.nFaces)
    {
        return;
    }

    if (scheduledInletFaceDevice(s, f))
    {
        const GPU_OPERATOR_REAL temperature = clampMin
        (
            finiteOr(s.scheduledInletTemperature, s.TgasMin),
            s.TgasMin
        );
        const GPU_OPERATOR_REAL pressure = clampMin
        (
            finiteOr(scheduledPressureDevice(s, simulationTime), OfSmall),
            s.rhoMin*s.Rgas*temperature
        );
        const GPU_OPERATOR_REAL density = pressure/clampMin(s.Rgas*temperature, OfSmall);
        s.gasBoundaryP[f] = pressure;
        s.gasBoundaryRho[f] = density;
        s.gasBoundaryT[f] = temperature;
        s.riemannBoundaryP[f] = pressure;
        s.riemannBoundaryRho[f] = density;
        s.riemannBoundaryT[f] = temperature;
        return;
    }

    const int kind = s.gasBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.gasBoundaryRhoFix[f] == 0)
    {
        s.gasBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.gasBoundaryUFix[f] == 0)
    {
        s.gasBoundaryUx[f] = s.Ux[mirrorCell];
        s.gasBoundaryUy[f] = s.Uy[mirrorCell];
        s.gasBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.gasBoundaryTFix[f] == 0)
    {
        s.gasBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if (s.gasBoundaryPFix[f] == 0 && s.gasBoundaryPWave[f] == 0)
    {
        s.gasBoundaryP[f] = s.p[mirrorCell];
    }
}

template<class GasState>
__global__ void reference_updateRiemannBoundaryMirrorKernel(GasState* sp)
{
    GasState& s = *sp;
    const int f = blockIdx.x*blockDim.x + threadIdx.x;
    if (f < s.nInternalFaces || f >= s.nFaces)
    {
        return;
    }

    const int kind = s.riemannBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.riemannBoundaryRhoFix[f] == 0)
    {
        s.riemannBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.riemannBoundaryUFix[f] == 0)
    {
        s.riemannBoundaryUx[f] = s.Ux[mirrorCell];
        s.riemannBoundaryUy[f] = s.Uy[mirrorCell];
        s.riemannBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.riemannBoundaryTFix[f] == 0)
    {
        s.riemannBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if
    (
        s.riemannBoundaryPFix[f] == 0
     && s.riemannBoundaryPWave[f] == 0
    )
    {
        s.riemannBoundaryP[f] = s.p[mirrorCell];
    }
}

#pragma once
template<class GasState>
__global__ void reference_updateWaveTransmissivePressureBoundaryKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME dt
)
{
    GasState& s = *sp;
    const int f = blockIdx.x*blockDim.x + threadIdx.x;
    if (f < s.nInternalFaces || f >= s.nFaces || s.gasBoundaryPWave[f] == 0)
    {
        return;
    }

    const int own = s.faceOwner[f];
    if (own < 0 || own >= s.nCells)
    {
        return;
    }

    const GPU_OPERATOR_REAL area = clampMin(s.magSf[f], GPU_OPERATOR_TINY(1.0e-300));
    GPU_OPERATOR_REAL boundaryUx = s.gasBoundaryUx[f];
    GPU_OPERATOR_REAL boundaryUy = s.gasBoundaryUy[f];
    GPU_OPERATOR_REAL boundaryUz = s.gasBoundaryUz[f];
    if (s.gasBoundaryUFix[f] == 2)
    {
        const GPU_OPERATOR_REAL ownerOutwardVelocity =
            s.Ux[own]*s.Sfx[f]
          + s.Uy[own]*s.Sfy[f]
          + s.Uz[own]*s.Sfz[f];
        if (ownerOutwardVelocity >= GPU_OPERATOR_R(0.0))
        {
            boundaryUx = s.Ux[own];
            boundaryUy = s.Uy[own];
            boundaryUz = s.Uz[own];
        }
    }
    const GPU_OPERATOR_REAL phip =
        boundaryUx*s.Sfx[f]
      + boundaryUy*s.Sfy[f]
      + boundaryUz*s.Sfz[f];
    const GPU_OPERATOR_REAL psi =
        s.gasBoundaryRho[f]
       /clampMin(s.gasBoundaryP[f], OfSmall);
    GPU_OPERATOR_REAL w =
        phip/area
      + sqrt(clampMin(s.gasBoundaryPWaveGamma[f]/clampMin(psi, OfSmall), GPU_OPERATOR_R(0.0)));
    w = w > GPU_OPERATOR_R(0.0) ? w : GPU_OPERATOR_R(0.0);

    const GPU_OPERATOR_REAL alpha = w*dt*s.deltaCoeffs[f];
    const GPU_OPERATOR_REAL lInf = s.gasBoundaryPWaveLInf[f];
    const bool hasRelaxation = lInf > GPU_OPERATOR_TINY(1.0e-300);
    const GPU_OPERATOR_REAL k = hasRelaxation ? w*dt/lInf : GPU_OPERATOR_R(0.0);
    const GPU_OPERATOR_REAL oldBoundaryP = s.gasBoundaryP[f];
    const GPU_OPERATOR_REAL refValue = hasRelaxation
      ? (oldBoundaryP + k*s.gasBoundaryPWaveFieldInf[f])/(GPU_OPERATOR_R(1.0) + k)
      : oldBoundaryP;
    const GPU_OPERATOR_REAL valueFraction = hasRelaxation
      ? (GPU_OPERATOR_R(1.0) + k)/(GPU_OPERATOR_R(1.0) + alpha + k)
      : GPU_OPERATOR_R(1.0)/(GPU_OPERATOR_R(1.0) + alpha);
    const GPU_OPERATOR_REAL boundaryP =
        valueFraction*refValue
      + (GPU_OPERATOR_R(1.0) - valueFraction)*s.p[own];

    const GPU_OPERATOR_REAL updatedPressure =
        clampMin(finiteOr(boundaryP, s.p[own]), OfVSmall);
    s.gasBoundaryP[f] = updatedPressure;
    s.riemannBoundaryP[f] = updatedPressure;
}
#pragma once
// One operator implementation; scalar/time adapters are compile-time only.
template<class GasState>
__global__ void updateLegacyGasBoundaryMirrorKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME simulationTime
)
{
    GasState& s = *sp;
    const int f = s.nInternalFaces + blockIdx.x*blockDim.x + threadIdx.x;
    if (f >= s.nFaces)
    {
        return;
    }

    if (scheduledInletFaceDevice(s, f))
    {
        const GPU_OPERATOR_REAL temperature = clampMin
        (
            finiteOr(s.scheduledInletTemperature, s.TgasMin),
            s.TgasMin
        );
        const GPU_OPERATOR_REAL pressure = clampMin
        (
            finiteOr(scheduledPressureDevice(s, simulationTime), OfSmall),
            s.rhoMin*s.Rgas*temperature
        );
        const GPU_OPERATOR_REAL density = pressure/clampMin(s.Rgas*temperature, OfSmall);
        s.gasBoundaryP[f] = pressure;
        s.gasBoundaryRho[f] = density;
        s.gasBoundaryT[f] = temperature;
        s.riemannBoundaryP[f] = pressure;
        s.riemannBoundaryRho[f] = density;
        s.riemannBoundaryT[f] = temperature;
        return;
    }

    const int kind = s.gasBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.gasBoundaryRhoFix[f] == 0)
    {
        s.gasBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.gasBoundaryUFix[f] == 0)
    {
        s.gasBoundaryUx[f] = s.Ux[mirrorCell];
        s.gasBoundaryUy[f] = s.Uy[mirrorCell];
        s.gasBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.gasBoundaryTFix[f] == 0)
    {
        s.gasBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if (s.gasBoundaryPFix[f] == 0 && s.gasBoundaryPWave[f] == 0)
    {
        s.gasBoundaryP[f] = s.p[mirrorCell];
    }
}

template<class GasState>
__global__ void updateRiemannBoundaryMirrorKernel(GasState* sp)
{
    GasState& s = *sp;
    const int f = s.nInternalFaces + blockIdx.x*blockDim.x + threadIdx.x;
    if (f >= s.nFaces)
    {
        return;
    }

    const int kind = s.riemannBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.riemannBoundaryRhoFix[f] == 0)
    {
        s.riemannBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.riemannBoundaryUFix[f] == 0)
    {
        s.riemannBoundaryUx[f] = s.Ux[mirrorCell];
        s.riemannBoundaryUy[f] = s.Uy[mirrorCell];
        s.riemannBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.riemannBoundaryTFix[f] == 0)
    {
        s.riemannBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if
    (
        s.riemannBoundaryPFix[f] == 0
     && s.riemannBoundaryPWave[f] == 0
    )
    {
        s.riemannBoundaryP[f] = s.p[mirrorCell];
    }
}

#pragma once
template<class GasState>
__global__ void updateWaveTransmissivePressureBoundaryKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME dt
)
{
    GasState& s = *sp;
    const int f = s.nInternalFaces + blockIdx.x*blockDim.x + threadIdx.x;
    if (f >= s.nFaces || s.gasBoundaryPWave[f] == 0)
    {
        return;
    }

    const int own = s.faceOwner[f];
    if (own < 0 || own >= s.nCells)
    {
        return;
    }

    const GPU_OPERATOR_REAL area = clampMin(s.magSf[f], GPU_OPERATOR_TINY(1.0e-300));
    GPU_OPERATOR_REAL boundaryUx = s.gasBoundaryUx[f];
    GPU_OPERATOR_REAL boundaryUy = s.gasBoundaryUy[f];
    GPU_OPERATOR_REAL boundaryUz = s.gasBoundaryUz[f];
    if (s.gasBoundaryUFix[f] == 2)
    {
        const GPU_OPERATOR_REAL ownerOutwardVelocity =
            s.Ux[own]*s.Sfx[f]
          + s.Uy[own]*s.Sfy[f]
          + s.Uz[own]*s.Sfz[f];
        if (ownerOutwardVelocity >= GPU_OPERATOR_R(0.0))
        {
            boundaryUx = s.Ux[own];
            boundaryUy = s.Uy[own];
            boundaryUz = s.Uz[own];
        }
    }
    const GPU_OPERATOR_REAL phip =
        boundaryUx*s.Sfx[f]
      + boundaryUy*s.Sfy[f]
      + boundaryUz*s.Sfz[f];
    const GPU_OPERATOR_REAL psi =
        s.gasBoundaryRho[f]
       /clampMin(s.gasBoundaryP[f], OfSmall);
    GPU_OPERATOR_REAL w =
        phip/area
      + sqrt(clampMin(s.gasBoundaryPWaveGamma[f]/clampMin(psi, OfSmall), GPU_OPERATOR_R(0.0)));
    w = w > GPU_OPERATOR_R(0.0) ? w : GPU_OPERATOR_R(0.0);

    const GPU_OPERATOR_REAL alpha = w*dt*s.deltaCoeffs[f];
    const GPU_OPERATOR_REAL lInf = s.gasBoundaryPWaveLInf[f];
    const bool hasRelaxation = lInf > GPU_OPERATOR_TINY(1.0e-300);
    const GPU_OPERATOR_REAL k = hasRelaxation ? w*dt/lInf : GPU_OPERATOR_R(0.0);
    const GPU_OPERATOR_REAL oldBoundaryP = s.gasBoundaryP[f];
    const GPU_OPERATOR_REAL refValue = hasRelaxation
      ? (oldBoundaryP + k*s.gasBoundaryPWaveFieldInf[f])/(GPU_OPERATOR_R(1.0) + k)
      : oldBoundaryP;
    const GPU_OPERATOR_REAL valueFraction = hasRelaxation
      ? (GPU_OPERATOR_R(1.0) + k)/(GPU_OPERATOR_R(1.0) + alpha + k)
      : GPU_OPERATOR_R(1.0)/(GPU_OPERATOR_R(1.0) + alpha);
    const GPU_OPERATOR_REAL boundaryP =
        valueFraction*refValue
      + (GPU_OPERATOR_R(1.0) - valueFraction)*s.p[own];

    const GPU_OPERATOR_REAL updatedPressure =
        clampMin(finiteOr(boundaryP, s.p[own]), OfVSmall);
    s.gasBoundaryP[f] = updatedPressure;
    s.riemannBoundaryP[f] = updatedPressure;
}


void check(cudaError_t e){if(e!=cudaSuccess){fprintf(stderr,"%s\n",cudaGetErrorString(e));exit(1);}}
__global__ void initialize(State* sp,int n,int internal){auto& a=*sp;int i=blockIdx.x*blockDim.x+threadIdx.x;
 if(i==0){a.nFaces=n;a.nInternalFaces=internal;a.nCells=7;a.scheduledInletTemperature=300;a.TgasMin=1;a.rhoMin=1e-9;a.Rgas=287;}
 if(i<n){
 a.Sfx[i]=1;
 a.Sfy[i]=1;
 a.Sfz[i]=1;
 a.Tgas[i]=1;
 a.Ux[i]=1;
 a.Uy[i]=1;
 a.Uz[i]=1;
 a.deltaCoeffs[i]=1;
 a.faceOwner[i]=i%7;
 a.gasBoundaryKind[i]=0;
 a.gasBoundaryP[i]=1;
 a.gasBoundaryPFix[i]=0;
 a.gasBoundaryPWave[i]=1;
 a.gasBoundaryPWaveFieldInf[i]=1;
 a.gasBoundaryPWaveGamma[i]=1;
 a.gasBoundaryPWaveLInf[i]=1;
 a.gasBoundaryRho[i]=1;
 a.gasBoundaryRhoFix[i]=0;
 a.gasBoundaryT[i]=1;
 a.gasBoundaryTFix[i]=0;
 a.gasBoundaryUFix[i]=0;
 a.gasBoundaryUx[i]=1;
 a.gasBoundaryUy[i]=1;
 a.gasBoundaryUz[i]=1;
 a.magSf[i]=1;
 a.p[i]=1;
 a.rho[i]=1;
 a.riemannBoundaryKind[i]=0;
 a.riemannBoundaryP[i]=1;
 a.riemannBoundaryPFix[i]=0;
 a.riemannBoundaryPWave[i]=1;
 a.riemannBoundaryRho[i]=1;
 a.riemannBoundaryRhoFix[i]=0;
 a.riemannBoundaryT[i]=1;
 a.riemannBoundaryTFix[i]=0;
 a.riemannBoundaryUFix[i]=0;
 a.riemannBoundaryUx[i]=1;
 a.riemannBoundaryUy[i]=1;
 a.riemannBoundaryUz[i]=1;
 }}
__global__ void compare(const State* a,const State* b,int n,int* mismatch){int i=blockIdx.x*blockDim.x+threadIdx.x;
 if(i<n&&(a->Sfx[i]!=b->Sfx[i]||a->Sfy[i]!=b->Sfy[i]||a->Sfz[i]!=b->Sfz[i]||a->Tgas[i]!=b->Tgas[i]||a->Ux[i]!=b->Ux[i]||a->Uy[i]!=b->Uy[i]||a->Uz[i]!=b->Uz[i]||a->deltaCoeffs[i]!=b->deltaCoeffs[i]||a->faceOwner[i]!=b->faceOwner[i]||a->gasBoundaryKind[i]!=b->gasBoundaryKind[i]||a->gasBoundaryP[i]!=b->gasBoundaryP[i]||a->gasBoundaryPFix[i]!=b->gasBoundaryPFix[i]||a->gasBoundaryPWave[i]!=b->gasBoundaryPWave[i]||a->gasBoundaryPWaveFieldInf[i]!=b->gasBoundaryPWaveFieldInf[i]||a->gasBoundaryPWaveGamma[i]!=b->gasBoundaryPWaveGamma[i]||a->gasBoundaryPWaveLInf[i]!=b->gasBoundaryPWaveLInf[i]||a->gasBoundaryRho[i]!=b->gasBoundaryRho[i]||a->gasBoundaryRhoFix[i]!=b->gasBoundaryRhoFix[i]||a->gasBoundaryT[i]!=b->gasBoundaryT[i]||a->gasBoundaryTFix[i]!=b->gasBoundaryTFix[i]||a->gasBoundaryUFix[i]!=b->gasBoundaryUFix[i]||a->gasBoundaryUx[i]!=b->gasBoundaryUx[i]||a->gasBoundaryUy[i]!=b->gasBoundaryUy[i]||a->gasBoundaryUz[i]!=b->gasBoundaryUz[i]||a->magSf[i]!=b->magSf[i]||a->p[i]!=b->p[i]||a->rho[i]!=b->rho[i]||a->riemannBoundaryKind[i]!=b->riemannBoundaryKind[i]||a->riemannBoundaryP[i]!=b->riemannBoundaryP[i]||a->riemannBoundaryPFix[i]!=b->riemannBoundaryPFix[i]||a->riemannBoundaryPWave[i]!=b->riemannBoundaryPWave[i]||a->riemannBoundaryRho[i]!=b->riemannBoundaryRho[i]||a->riemannBoundaryRhoFix[i]!=b->riemannBoundaryRhoFix[i]||a->riemannBoundaryT[i]!=b->riemannBoundaryT[i]||a->riemannBoundaryTFix[i]!=b->riemannBoundaryTFix[i]||a->riemannBoundaryUFix[i]!=b->riemannBoundaryUFix[i]||a->riemannBoundaryUx[i]!=b->riemannBoundaryUx[i]||a->riemannBoundaryUy[i]!=b->riemannBoundaryUy[i]||a->riemannBoundaryUz[i]!=b->riemannBoundaryUz[i]))atomicAdd(mismatch,1);
}
void launch(State* p,int faces,int boundary,bool optimized){int grid=((optimized?boundary:faces)+127)/128;if(!grid)return;
 if(optimized){updateLegacyGasBoundaryMirrorKernel<<<grid,128>>>(p,.3);updateRiemannBoundaryMirrorKernel<<<grid,128>>>(p);updateWaveTransmissivePressureBoundaryKernel<<<grid,128>>>(p,.01);}
 else{reference_updateLegacyGasBoundaryMirrorKernel<<<grid,128>>>(p,.3);reference_updateRiemannBoundaryMirrorKernel<<<grid,128>>>(p);reference_updateWaveTransmissivePressureBoundaryKernel<<<grid,128>>>(p,.01);}
}
int main(){State *a,*b;int *m;check(cudaMalloc(&a,sizeof(State)));check(cudaMalloc(&b,sizeof(State)));check(cudaMalloc(&m,sizeof(int)));
 cudaEvent_t begin,end;check(cudaEventCreate(&begin));check(cudaEventCreate(&end));
 puts("faces,boundary,old_threads,new_threads,old_ms,new_ms,equal");
 for(int n:{4096,65536,1048576})for(int boundary:{0,1,336,4096}){
  initialize<<<(n+127)/128,128>>>(a,n,n-boundary);initialize<<<(n+127)/128,128>>>(b,n,n-boundary);
  float elapsed[2];for(int variant=0;variant<2;++variant){for(int i=0;i<4;++i)launch(variant?b:a,n,boundary,variant);
   check(cudaEventRecord(begin));for(int i=0;i<100;++i)launch(variant?b:a,n,boundary,variant);check(cudaEventRecord(end));check(cudaEventSynchronize(end));check(cudaEventElapsedTime(&elapsed[variant],begin,end));}
  check(cudaMemset(m,0,sizeof(int)));compare<<<(n+127)/128,128>>>(a,b,n,m);int mismatch=0;check(cudaMemcpy(&mismatch,m,sizeof(int),cudaMemcpyDeviceToHost));assert(mismatch==0);
  printf("%d,%d,%d,%d,%.9g,%.9g,1\n",n,boundary,3*((n+127)/128)*128,3*((boundary+127)/128)*128,elapsed[0]/100,elapsed[1]/100);
 }
 check(cudaFree(a));check(cudaFree(b));check(cudaFree(m));
}
