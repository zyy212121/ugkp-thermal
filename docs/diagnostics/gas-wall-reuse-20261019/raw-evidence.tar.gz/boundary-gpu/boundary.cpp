#include <initializer_list>

#include <cmath>
#include <cstring>
#include <cassert>
#define __global__
#define GPU_OPERATOR_REAL double
#define GPU_OPERATOR_TIME double
#define GPU_OPERATOR_R(x) (x)
#define GPU_OPERATOR_TINY(x) (x)
struct Index{int x=0;}blockIdx,blockDim,threadIdx;
constexpr double OfSmall=1e-15,OfVSmall=1e-300;
double clampMin(double a,double b){return a<b?b:a;}
double finiteOr(double a,double b){return std::isfinite(a)?a:b;}
struct State{int nInternalFaces=0,nFaces=0,nCells=7;double scheduledInletTemperature=300,TgasMin=1,rhoMin=1e-9,Rgas=287;
double Sfx[101]{};
double Sfy[101]{};
double Sfz[101]{};
double Tgas[101]{};
double Ux[101]{};
double Uy[101]{};
double Uz[101]{};
double deltaCoeffs[101]{};
int faceOwner[101]{};
int gasBoundaryKind[101]{};
double gasBoundaryP[101]{};
int gasBoundaryPFix[101]{};
int gasBoundaryPWave[101]{};
double gasBoundaryPWaveFieldInf[101]{};
double gasBoundaryPWaveGamma[101]{};
double gasBoundaryPWaveLInf[101]{};
double gasBoundaryRho[101]{};
int gasBoundaryRhoFix[101]{};
double gasBoundaryT[101]{};
int gasBoundaryTFix[101]{};
int gasBoundaryUFix[101]{};
double gasBoundaryUx[101]{};
double gasBoundaryUy[101]{};
double gasBoundaryUz[101]{};
double magSf[101]{};
double p[101]{};
double rho[101]{};
int riemannBoundaryKind[101]{};
double riemannBoundaryP[101]{};
int riemannBoundaryPFix[101]{};
int riemannBoundaryPWave[101]{};
double riemannBoundaryRho[101]{};
int riemannBoundaryRhoFix[101]{};
double riemannBoundaryT[101]{};
int riemannBoundaryTFix[101]{};
int riemannBoundaryUFix[101]{};
double riemannBoundaryUx[101]{};
double riemannBoundaryUy[101]{};
double riemannBoundaryUz[101]{};};
bool scheduledInletFaceDevice(const State&,int f){return f%11==0;}
double scheduledPressureDevice(const State&,double t){return 100000+t;}
int coupledFaceNeighbour(const State&,int f){return (f+1)%7;}
#pragma once
// One operator implementation; scalar/time adapters are compile-time only.
template<class GasState>
__global__ void reference_updateLegacyGasBoundaryMirrorKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME simulationTime
)
{
    GasState& s = *sp;
    const int f = blockIdx.x*blockDim.x + threadIdx.x;
    if (f < s.nInternalFaces || f >= s.nFaces)
    {
        return;
    }

    if (scheduledInletFaceDevice(s, f))
    {
        const GPU_OPERATOR_REAL temperature = clampMin
        (
            finiteOr(s.scheduledInletTemperature, s.TgasMin),
            s.TgasMin
        );
        const GPU_OPERATOR_REAL pressure = clampMin
        (
            finiteOr(scheduledPressureDevice(s, simulationTime), OfSmall),
            s.rhoMin*s.Rgas*temperature
        );
        const GPU_OPERATOR_REAL density = pressure/clampMin(s.Rgas*temperature, OfSmall);
        s.gasBoundaryP[f] = pressure;
        s.gasBoundaryRho[f] = density;
        s.gasBoundaryT[f] = temperature;
        s.riemannBoundaryP[f] = pressure;
        s.riemannBoundaryRho[f] = density;
        s.riemannBoundaryT[f] = temperature;
        return;
    }

    const int kind = s.gasBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.gasBoundaryRhoFix[f] == 0)
    {
        s.gasBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.gasBoundaryUFix[f] == 0)
    {
        s.gasBoundaryUx[f] = s.Ux[mirrorCell];
        s.gasBoundaryUy[f] = s.Uy[mirrorCell];
        s.gasBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.gasBoundaryTFix[f] == 0)
    {
        s.gasBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if (s.gasBoundaryPFix[f] == 0 && s.gasBoundaryPWave[f] == 0)
    {
        s.gasBoundaryP[f] = s.p[mirrorCell];
    }
}

template<class GasState>
__global__ void reference_updateRiemannBoundaryMirrorKernel(GasState* sp)
{
    GasState& s = *sp;
    const int f = blockIdx.x*blockDim.x + threadIdx.x;
    if (f < s.nInternalFaces || f >= s.nFaces)
    {
        return;
    }

    const int kind = s.riemannBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.riemannBoundaryRhoFix[f] == 0)
    {
        s.riemannBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.riemannBoundaryUFix[f] == 0)
    {
        s.riemannBoundaryUx[f] = s.Ux[mirrorCell];
        s.riemannBoundaryUy[f] = s.Uy[mirrorCell];
        s.riemannBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.riemannBoundaryTFix[f] == 0)
    {
        s.riemannBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if
    (
        s.riemannBoundaryPFix[f] == 0
     && s.riemannBoundaryPWave[f] == 0
    )
    {
        s.riemannBoundaryP[f] = s.p[mirrorCell];
    }
}

#pragma once
template<class GasState>
__global__ void reference_updateWaveTransmissivePressureBoundaryKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME dt
)
{
    GasState& s = *sp;
    const int f = blockIdx.x*blockDim.x + threadIdx.x;
    if (f < s.nInternalFaces || f >= s.nFaces || s.gasBoundaryPWave[f] == 0)
    {
        return;
    }

    const int own = s.faceOwner[f];
    if (own < 0 || own >= s.nCells)
    {
        return;
    }

    const GPU_OPERATOR_REAL area = clampMin(s.magSf[f], GPU_OPERATOR_TINY(1.0e-300));
    GPU_OPERATOR_REAL boundaryUx = s.gasBoundaryUx[f];
    GPU_OPERATOR_REAL boundaryUy = s.gasBoundaryUy[f];
    GPU_OPERATOR_REAL boundaryUz = s.gasBoundaryUz[f];
    if (s.gasBoundaryUFix[f] == 2)
    {
        const GPU_OPERATOR_REAL ownerOutwardVelocity =
            s.Ux[own]*s.Sfx[f]
          + s.Uy[own]*s.Sfy[f]
          + s.Uz[own]*s.Sfz[f];
        if (ownerOutwardVelocity >= GPU_OPERATOR_R(0.0))
        {
            boundaryUx = s.Ux[own];
            boundaryUy = s.Uy[own];
            boundaryUz = s.Uz[own];
        }
    }
    const GPU_OPERATOR_REAL phip =
        boundaryUx*s.Sfx[f]
      + boundaryUy*s.Sfy[f]
      + boundaryUz*s.Sfz[f];
    const GPU_OPERATOR_REAL psi =
        s.gasBoundaryRho[f]
       /clampMin(s.gasBoundaryP[f], OfSmall);
    GPU_OPERATOR_REAL w =
        phip/area
      + sqrt(clampMin(s.gasBoundaryPWaveGamma[f]/clampMin(psi, OfSmall), GPU_OPERATOR_R(0.0)));
    w = w > GPU_OPERATOR_R(0.0) ? w : GPU_OPERATOR_R(0.0);

    const GPU_OPERATOR_REAL alpha = w*dt*s.deltaCoeffs[f];
    const GPU_OPERATOR_REAL lInf = s.gasBoundaryPWaveLInf[f];
    const bool hasRelaxation = lInf > GPU_OPERATOR_TINY(1.0e-300);
    const GPU_OPERATOR_REAL k = hasRelaxation ? w*dt/lInf : GPU_OPERATOR_R(0.0);
    const GPU_OPERATOR_REAL oldBoundaryP = s.gasBoundaryP[f];
    const GPU_OPERATOR_REAL refValue = hasRelaxation
      ? (oldBoundaryP + k*s.gasBoundaryPWaveFieldInf[f])/(GPU_OPERATOR_R(1.0) + k)
      : oldBoundaryP;
    const GPU_OPERATOR_REAL valueFraction = hasRelaxation
      ? (GPU_OPERATOR_R(1.0) + k)/(GPU_OPERATOR_R(1.0) + alpha + k)
      : GPU_OPERATOR_R(1.0)/(GPU_OPERATOR_R(1.0) + alpha);
    const GPU_OPERATOR_REAL boundaryP =
        valueFraction*refValue
      + (GPU_OPERATOR_R(1.0) - valueFraction)*s.p[own];

    const GPU_OPERATOR_REAL updatedPressure =
        clampMin(finiteOr(boundaryP, s.p[own]), OfVSmall);
    s.gasBoundaryP[f] = updatedPressure;
    s.riemannBoundaryP[f] = updatedPressure;
}
#pragma once
// One operator implementation; scalar/time adapters are compile-time only.
template<class GasState>
__global__ void updateLegacyGasBoundaryMirrorKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME simulationTime
)
{
    GasState& s = *sp;
    const int f = s.nInternalFaces + blockIdx.x*blockDim.x + threadIdx.x;
    if (f >= s.nFaces)
    {
        return;
    }

    if (scheduledInletFaceDevice(s, f))
    {
        const GPU_OPERATOR_REAL temperature = clampMin
        (
            finiteOr(s.scheduledInletTemperature, s.TgasMin),
            s.TgasMin
        );
        const GPU_OPERATOR_REAL pressure = clampMin
        (
            finiteOr(scheduledPressureDevice(s, simulationTime), OfSmall),
            s.rhoMin*s.Rgas*temperature
        );
        const GPU_OPERATOR_REAL density = pressure/clampMin(s.Rgas*temperature, OfSmall);
        s.gasBoundaryP[f] = pressure;
        s.gasBoundaryRho[f] = density;
        s.gasBoundaryT[f] = temperature;
        s.riemannBoundaryP[f] = pressure;
        s.riemannBoundaryRho[f] = density;
        s.riemannBoundaryT[f] = temperature;
        return;
    }

    const int kind = s.gasBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.gasBoundaryRhoFix[f] == 0)
    {
        s.gasBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.gasBoundaryUFix[f] == 0)
    {
        s.gasBoundaryUx[f] = s.Ux[mirrorCell];
        s.gasBoundaryUy[f] = s.Uy[mirrorCell];
        s.gasBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.gasBoundaryTFix[f] == 0)
    {
        s.gasBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if (s.gasBoundaryPFix[f] == 0 && s.gasBoundaryPWave[f] == 0)
    {
        s.gasBoundaryP[f] = s.p[mirrorCell];
    }
}

template<class GasState>
__global__ void updateRiemannBoundaryMirrorKernel(GasState* sp)
{
    GasState& s = *sp;
    const int f = s.nInternalFaces + blockIdx.x*blockDim.x + threadIdx.x;
    if (f >= s.nFaces)
    {
        return;
    }

    const int kind = s.riemannBoundaryKind[f];
    if (kind == 3 || kind == 4)
    {
        return;
    }

    const int own = s.faceOwner[f];
    const int mirrorCell = kind == 5 ? coupledFaceNeighbour(s, f) : own;
    if (mirrorCell < 0 || mirrorCell >= s.nCells)
    {
        return;
    }

    if (s.riemannBoundaryRhoFix[f] == 0)
    {
        s.riemannBoundaryRho[f] = s.rho[mirrorCell];
    }
    if (s.riemannBoundaryUFix[f] == 0)
    {
        s.riemannBoundaryUx[f] = s.Ux[mirrorCell];
        s.riemannBoundaryUy[f] = s.Uy[mirrorCell];
        s.riemannBoundaryUz[f] = s.Uz[mirrorCell];
    }
    if (s.riemannBoundaryTFix[f] == 0)
    {
        s.riemannBoundaryT[f] = s.Tgas[mirrorCell];
    }
    if
    (
        s.riemannBoundaryPFix[f] == 0
     && s.riemannBoundaryPWave[f] == 0
    )
    {
        s.riemannBoundaryP[f] = s.p[mirrorCell];
    }
}

#pragma once
template<class GasState>
__global__ void updateWaveTransmissivePressureBoundaryKernel
(
    GasState* sp,
    const GPU_OPERATOR_TIME dt
)
{
    GasState& s = *sp;
    const int f = s.nInternalFaces + blockIdx.x*blockDim.x + threadIdx.x;
    if (f >= s.nFaces || s.gasBoundaryPWave[f] == 0)
    {
        return;
    }

    const int own = s.faceOwner[f];
    if (own < 0 || own >= s.nCells)
    {
        return;
    }

    const GPU_OPERATOR_REAL area = clampMin(s.magSf[f], GPU_OPERATOR_TINY(1.0e-300));
    GPU_OPERATOR_REAL boundaryUx = s.gasBoundaryUx[f];
    GPU_OPERATOR_REAL boundaryUy = s.gasBoundaryUy[f];
    GPU_OPERATOR_REAL boundaryUz = s.gasBoundaryUz[f];
    if (s.gasBoundaryUFix[f] == 2)
    {
        const GPU_OPERATOR_REAL ownerOutwardVelocity =
            s.Ux[own]*s.Sfx[f]
          + s.Uy[own]*s.Sfy[f]
          + s.Uz[own]*s.Sfz[f];
        if (ownerOutwardVelocity >= GPU_OPERATOR_R(0.0))
        {
            boundaryUx = s.Ux[own];
            boundaryUy = s.Uy[own];
            boundaryUz = s.Uz[own];
        }
    }
    const GPU_OPERATOR_REAL phip =
        boundaryUx*s.Sfx[f]
      + boundaryUy*s.Sfy[f]
      + boundaryUz*s.Sfz[f];
    const GPU_OPERATOR_REAL psi =
        s.gasBoundaryRho[f]
       /clampMin(s.gasBoundaryP[f], OfSmall);
    GPU_OPERATOR_REAL w =
        phip/area
      + sqrt(clampMin(s.gasBoundaryPWaveGamma[f]/clampMin(psi, OfSmall), GPU_OPERATOR_R(0.0)));
    w = w > GPU_OPERATOR_R(0.0) ? w : GPU_OPERATOR_R(0.0);

    const GPU_OPERATOR_REAL alpha = w*dt*s.deltaCoeffs[f];
    const GPU_OPERATOR_REAL lInf = s.gasBoundaryPWaveLInf[f];
    const bool hasRelaxation = lInf > GPU_OPERATOR_TINY(1.0e-300);
    const GPU_OPERATOR_REAL k = hasRelaxation ? w*dt/lInf : GPU_OPERATOR_R(0.0);
    const GPU_OPERATOR_REAL oldBoundaryP = s.gasBoundaryP[f];
    const GPU_OPERATOR_REAL refValue = hasRelaxation
      ? (oldBoundaryP + k*s.gasBoundaryPWaveFieldInf[f])/(GPU_OPERATOR_R(1.0) + k)
      : oldBoundaryP;
    const GPU_OPERATOR_REAL valueFraction = hasRelaxation
      ? (GPU_OPERATOR_R(1.0) + k)/(GPU_OPERATOR_R(1.0) + alpha + k)
      : GPU_OPERATOR_R(1.0)/(GPU_OPERATOR_R(1.0) + alpha);
    const GPU_OPERATOR_REAL boundaryP =
        valueFraction*refValue
      + (GPU_OPERATOR_R(1.0) - valueFraction)*s.p[own];

    const GPU_OPERATOR_REAL updatedPressure =
        clampMin(finiteOr(boundaryP, s.p[own]), OfVSmall);
    s.gasBoundaryP[f] = updatedPressure;
    s.riemannBoundaryP[f] = updatedPressure;
}

int main(){blockDim.x=1;
 for(int n:{0,1,17,101})for(int internal:{0,n/2,n})for(int trial=0;trial<6;++trial){
  State a;a.nFaces=n;a.nInternalFaces=internal;for(int i=0;i<101;++i){
a.Sfx[i]=1.+.01*i;
a.Sfy[i]=1.+.01*i;
a.Sfz[i]=1.+.01*i;
a.Tgas[i]=1.+.01*i;
a.Ux[i]=1.+.01*i;
a.Uy[i]=1.+.01*i;
a.Uz[i]=1.+.01*i;
a.deltaCoeffs[i]=1.+.01*i;
a.faceOwner[i]=i%7;
a.gasBoundaryKind[i]=(i+trial)%6;
a.gasBoundaryP[i]=1.+.01*i;
a.gasBoundaryPFix[i]=(i+trial)%3;
a.gasBoundaryPWave[i]=i%2;
a.gasBoundaryPWaveFieldInf[i]=1.+.01*i;
a.gasBoundaryPWaveGamma[i]=1.+.01*i;
a.gasBoundaryPWaveLInf[i]=1.+.01*i;
a.gasBoundaryRho[i]=1.+.01*i;
a.gasBoundaryRhoFix[i]=(i+trial)%3;
a.gasBoundaryT[i]=1.+.01*i;
a.gasBoundaryTFix[i]=(i+trial)%3;
a.gasBoundaryUFix[i]=(i+trial)%3;
a.gasBoundaryUx[i]=1.+.01*i;
a.gasBoundaryUy[i]=1.+.01*i;
a.gasBoundaryUz[i]=1.+.01*i;
a.magSf[i]=1.+.01*i;
a.p[i]=1.+.01*i;
a.rho[i]=1.+.01*i;
a.riemannBoundaryKind[i]=(i+trial)%6;
a.riemannBoundaryP[i]=1.+.01*i;
a.riemannBoundaryPFix[i]=(i+trial)%3;
a.riemannBoundaryPWave[i]=i%2;
a.riemannBoundaryRho[i]=1.+.01*i;
a.riemannBoundaryRhoFix[i]=(i+trial)%3;
a.riemannBoundaryT[i]=1.+.01*i;
a.riemannBoundaryTFix[i]=(i+trial)%3;
a.riemannBoundaryUFix[i]=(i+trial)%3;
a.riemannBoundaryUx[i]=1.+.01*i;
a.riemannBoundaryUy[i]=1.+.01*i;
a.riemannBoundaryUz[i]=1.+.01*i;}
  State b=a;
  for(int f=0;f<n;++f){threadIdx.x=f;reference_updateLegacyGasBoundaryMirrorKernel(&a,.3);}
  for(int f=0;f<n-internal;++f){threadIdx.x=f;updateLegacyGasBoundaryMirrorKernel(&b,.3);}
  assert(std::memcmp(&a,&b,sizeof(a))==0);
  for(int f=0;f<n;++f){threadIdx.x=f;reference_updateRiemannBoundaryMirrorKernel(&a);}
  for(int f=0;f<n-internal;++f){threadIdx.x=f;updateRiemannBoundaryMirrorKernel(&b);}
  assert(std::memcmp(&a,&b,sizeof(a))==0);
  for(int f=0;f<n;++f){threadIdx.x=f;reference_updateWaveTransmissivePressureBoundaryKernel(&a,.01);}
  for(int f=0;f<n-internal;++f){threadIdx.x=f;updateWaveTransmissivePressureBoundaryKernel(&b,.01);}
  assert(std::memcmp(&a,&b,sizeof(a))==0);
 }
}
