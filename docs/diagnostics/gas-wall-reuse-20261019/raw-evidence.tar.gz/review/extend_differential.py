from pathlib import Path
p=Path(__file__).parent/'wall_differential.cpp'
s=p.read_text().replace('#include <cstdio>','#include "validation/tests/gas_wall/fixtures/wall_composition_cases.H"\n#include <cstdio>')
s=s.replace('double coefficients[3*N]{};','double coefficients[14*N]{};')
s=s.replace('bool ok=evaluateReactingWallLayer(in,c,w,out,status);','''if(variant>=12){
 for(int j=0;j<14*N;++j)coefficients[j]=0;
 for(int j=0;j<N;++j){species[j].model=SpeciesThermoModel::NASA7;species[j].coefficientOffset=14*j;species[j].midTemperature=305;coefficients[14*j]=coefficients[14*j+7]=3.5;}
 in.model.thermo.coefficientCount=14*N-(variant==13?2:variant==14?1:0);
}
 bool ok=evaluateReactingWallLayer(in,c,w,out,status);''')
s=s.replace('int main(){for(int i=0;i<12;++i)','''void chemistry(int variant,bool sst,bool reversible){
 CompositionWallCase m;m.in.integrateOwnerKSource=false;m.in.matching.k=.5;m.in.matching.omega=200;m.in.model.mode=GasMode::MixtureChemistry;m.rx[0].reversible=reversible;
 WallModelConfig<double>c;c.nodes=12;c.maxIterations=3;c.enableSst=sst;WallWorkspace<double,2,48>w{};WallOutput<double,2>o;WallStatus s;ugkp::diagnostics::DeviceContext d{};m.in.diagnostics=&d;m.in.model.thermo.diagnostics=&d;
 if(variant==1){m.in.massFlux[0]=.0007;m.in.massFlux[1]=.0003;}
 if(variant==2)m.in.matching.massFraction[1]=1.2;
 if(variant==3)m.in.matching.massFraction[1]=-.1;
 if(variant==4)m.rx[0].highRate.preExponential=1e308;
 if(variant==5)m.sp[0].hasEntropyReference=false;
 if(variant==6)m.in.model.mechanism.reactants=nullptr;
 if(variant==7)m.in.integrateOwnerKSource=true;
 bool ok=evaluateReactingWallLayer(m.in,c,w,o,s);summarize<2,48>(100+variant+20*sst+40*reversible,c.nodes,ok,s,o,w,d);
}
int main(){for(int i=0;i<8;++i)for(bool sst:{false,true})for(bool reversible:{false,true})chemistry(i,sst,reversible);
for(int i=0;i<15;++i)''')
p.write_text(s)