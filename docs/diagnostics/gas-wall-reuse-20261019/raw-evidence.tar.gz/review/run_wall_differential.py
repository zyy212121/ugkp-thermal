from pathlib import Path
import shutil, subprocess
root=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018')
work=Path(__file__).parent
for version in ('baseline','current'):
    dest=work/version
    shutil.copytree(root/'common',dest/'common',dirs_exist_ok=True)
    if version=='baseline':
        for name in ('gasWall/ReactingWallLayer.H','gasTransport/MixtureThermo.H'):
            (dest/'common'/name).write_bytes(subprocess.check_output(['git','show','HEAD:common/'+name],cwd=root))
    subprocess.run(['g++','-std=c++17','-O2','-ffp-contract=off','-I'+str(dest),'-I'+str(root),str(work/'wall_differential.cpp'),'-o',str(work/('wall_'+version))],check=True)
    result=subprocess.run([str(work/('wall_'+version))],check=True,capture_output=True,text=True,timeout=90)
    (work/(version+'.out')).write_text(result.stdout)
a=(work/'baseline.out').read_text().splitlines();b=(work/'current.out').read_text().splitlines()
print('cases',len(a),'identical',a==b)
for x,y in zip(a,b):
    if x!=y: print('BASE',x,'NEW ',y,sep='\n')