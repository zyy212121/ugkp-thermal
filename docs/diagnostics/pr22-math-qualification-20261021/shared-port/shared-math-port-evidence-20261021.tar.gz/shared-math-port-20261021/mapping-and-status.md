# Qualified math → shared/CUDA mapping and status

Base: pr22-coherent-integration HEAD 2ef33658070b1f1adf950ad55dac22afa2796919.
Parent approved implementation after completed directional 200 us qualification.
The existing nine untracked files and original pr22-independent dirty files are excluded.

## Minimal implementation
1. ConservativeProfile.H: Sample + four doubles; lane-local affine state; logistic/coordinate/value/gradient; preserve old fitTeam body as fitLegacyTeam; selected fitTeam dispatch also requires coherentDiscretization; point/derivative/common-J+enthalpy publication. Existing 128*8 samples cover two adjacent segments at capacities 24/48/128 (at most one split microinterval); do not copy prototype 1024*8 extent or add capacity rejection.
2. WallCoherentNumerics.H: HD numeric-probe direction helpers, signed a allowed, new-alternative-only T/Y/z checks.
3. WallCoherentSolver.H: both scalar and team engines receive mirror, unresolved/full-zero colored fallback, ordinary scalar directional recovery. Saved original steps are worker scratch; existing wall LU, history, and publication ownership unchanged.
4. Scalar tests/fixtures and actual CUDA driver/oracle corrections; no CPU cooperative test execution. CUDA is user-run, nvcc/GPU UNRUN here.

## Return/status preservation (inspected candidate source)
HermiteProfile.H 619–629 resets affine state and delegates unselected inputs to fitLegacyTeam.
648/651 only record affineHelpersOk/affineRawFinite; neither controls return or publication.
652 has no determinant-positivity guard. Internal stagnation/line-search/budget exits retain last coefficients.
654–656 still fit energy, record maxResidual and return true. Do not replace this bool with convergence.
Legacy incompatible-species false at 540–541 remains unchanged.
GasConservativeWall.H 116–124 increments fallback and skips publication only on existing fit false, otherwise publishes and records moment residual.
Qualified observed moment residual is 8.91623e-15, with finite/helper observations in the covered run; not a universal solver guarantee.

## Verification schedule
CPU timing lead owns exclusivity; no builds/tests until release.
Write scalar regressions first; establish old free-wall and failed723 counterexamples before porting.
Then serial fixture/pinned-source parity, unsupported-route continuation and profile publication checks.
Existing audit reviewer reviews collective-uniform source flow, no independent test campaign.
Parent handles PR publication; no merge/README changes.

## Progress
- Tracked base clean, nine excluded untracked paths observed.
- Scalar free-wall regression source and unittest driver written; execution awaiting timing release.

## Final
Port implemented after qualification, independent source-reviewed, scalar tests passed.
See PORT-REPORT.json and docs/diagnostics/affine-directional-shared-port-20261021.md.
No CPU cooperative campaign; nvcc/GPU/sanitizers UNRUN.
