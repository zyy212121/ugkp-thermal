#define main captured_replay_main
#include "../integration-cpu-shared-20261021/core-refresh-green/shared-replay.cpp"
#undef main
int main(int argc,char**argv){
 std::string root=argv[1];CapturedSstWall m;auto in=m.input;auto cfg=m.config;read(root+"/input.bin",in);readConfig(root+"/config.bin",cfg);auto descriptor=descriptorForPrism(cfg,in.matchingDistance,0.00025477711111950772,in.ownerDistance,in.quadrature.volume);in.quadrature=descriptor.quadrature();AcceptedCapture history;read(root+"/history.bin",history);coherent_probe::W failed;read(root+"/failed-workspace.bin",failed);
 std::cout<<std::setprecision(17)<<"#pragma once\n#include \"sst_restart004_capture.H\"\n// Recorded owner23058, mixed no-blowing step723/stage2; compact numeric fixture.\n// Metadata and nodal states exported from preserved input/history/failure capture.\n// Thermochemical tables inherit the identical existing Air/CO2 fixture; no raw pointers/ABI bytes.\nstruct CoherentDirectional723 : CapturedSstWall {\n double quadratureY["<<in.quadrature.count<<"],quadratureWeight["<<in.quadrature.count<<"];\n CoherentDirectional723(){\n";
#define V(x) std::cout<<" input." #x "="<<in.x<<";\n"
 V(pressure);V(temperature);V(matchingDistance);V(ownerDistance);V(matching.temperature);V(matching.k);V(matching.omega);V(model.viscosity);V(model.conductivity);V(model.molecularPrandtl);
 for(int j=0;j<3;++j){std::cout<<" input.velocity["<<j<<"]="<<in.velocity[j]<<";input.normal["<<j<<"]="<<in.normal[j]<<";input.matching.velocity["<<j<<"]="<<in.matching.velocity[j]<<";\n";for(int k=0;k<2;++k)std::cout<<" input.sstTangentialGradient["<<j<<"]["<<k<<"]="<<in.sstTangentialGradient[j][k]<<";\n";}
 for(int j=0;j<2;++j)std::cout<<" input.massFlux["<<j<<"]="<<in.massFlux[j]<<";input.matching.massFraction["<<j<<"]="<<in.matching.massFraction[j]<<";input.model.diffusivity["<<j<<"]="<<in.model.diffusivity[j]<<";\n";
 std::cout<<" input.integrateOwnerKSource="<<in.integrateOwnerKSource<<";input.volumeSstClosure="<<in.volumeSstClosure<<";\n";
 for(int j=0;j<in.quadrature.count;++j)std::cout<<" quadratureY["<<j<<"]="<<in.quadrature.distance[j]<<";quadratureWeight["<<j<<"]="<<in.quadrature.volumeWeight[j]<<";\n";
 std::cout<<" input.quadrature={quadratureY,quadratureWeight,"<<in.quadrature.count<<","<<in.quadrature.volume<<","<<in.quadrature.firstMoment<<"};\n }\n";
 for(int kind=0;kind<2;++kind){std::cout<<" static void "<<(kind?"failedSeed":"acceptedSeed")<<"(ugkwp::gaswall::WallWorkspace<double,2,24>& w){\n";for(int i=0;i<24;++i){std::cout<<" w.y["<<i<<"]="<<failed.y[i]<<";\n";for(int j=0;j<6;++j)std::cout<<" w.state["<<i<<"]["<<j<<"]="<<(kind?failed.state[i][j]:history.state[i][j])<<";\n";}std::cout<<" }\n";}
 std::cout<<"};\n";
}
