// Standalone parity probe for the shared coherent profile, including captured
// root refits and capacity-only resampling. No nonlinear solve is performed.
#include <fstream>
#include <iostream>
#include <vector>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstring>
#include "validation/tests/gas_wall/fixtures/sst_restart004_capture.H"
#ifndef PROFILE_HEADER
#define PROFILE_HEADER "common/gasWall/reconstruction/ConservativeProfile.H"
#endif
#include PROFILE_HEADER
#ifdef ENERGY_HEADER
#include ENERGY_HEADER
#endif
using namespace ugkwp::gaswall;
using namespace ugkwp::gaswall::reconstruction;
struct SequenceRecord {
 int step=0,stage=0,owner=0;double time=0; WallInput<double,2> input;
 double lo[2]{},hi[2]{},target[2][9]{},normalLo[2]{},normalHi[2]{};
 bool algebraic[2]{};double U[2][3][3]{},T[2][3]{},k[2][3]{},omega[2][3]{},Y[2][2][3]{};
};
void append(std::vector<double>&o,const Primitive&p){o.push_back(p.rho);for(auto v:p.U)o.push_back(v);o.push_back(p.T);o.push_back(p.k);o.push_back(p.omega);for(auto v:p.Y)o.push_back(v);}
void segments(Profile&p,const SequenceRecord&r){for(int z=0;z<2;++z){Segment a{};a.lo=r.lo[z];a.hi=r.hi[z];a.normalLo=r.normalLo[z];a.normalHi=r.normalHi[z];a.algebraicOmega=r.algebraic[z];a.hasMacroGradients=true;for(int q=0;q<9;++q)a.target[q]=r.target[z][q];for(int j=0;j<3;++j){a.macroGradients.T[j]=r.T[z][j];a.macroGradients.k[j]=r.k[z][j];a.macroGradients.omega[j]=r.omega[z][j];for(int k=0;k<3;++k)a.macroGradients.U[k][j]=r.U[z][k][j];for(int k=0;k<2;++k)a.macroGradients.Y[k][j]=r.Y[z][k][j];}p.segments.push_back(a);}}
template<int Capacity> int run(const SequenceRecord&r,const std::array<double,324>&raw){
 CapturedSstWall m;auto in=r.input;in.model.thermo=m.input.model.thermo;in.model.mechanism=m.input.model.mechanism;in.diagnostics=nullptr;in.model.thermo.diagnostics=nullptr;in.quadrature={};auto cfg=m.config;cfg.nodes=Capacity;
#ifdef SHARED_COHERENT_PROFILE
 cfg.coherentDiscretization=true;
#endif
 WallWorkspace<double,2,24> captured{};int at=12;for(int i=0;i<24;++i){captured.y[i]=raw[at++];for(auto&v:captured.state[i])v=raw[at++];for(auto&v:captured.residual[i])v=raw[at++];}
 WallWorkspace<double,2,Capacity> w{};
 for(int i=0;i<Capacity;++i){w.y[i]=Capacity==24?captured.y[i]:in.matchingDistance*std::pow(double(i)/(Capacity-1),cfg.stretch);int l=0;while(l+1<23&&captured.y[l+1]<w.y[i])++l;double t=(w.y[i]-captured.y[l])/(captured.y[l+1]-captured.y[l]);for(int j=0;j<6;++j)w.state[i][j]=Capacity==24?captured.state[i][j]:captured.state[l][j]+t*(captured.state[l+1][j]-captured.state[l][j]);}
 WallOutput<double,2> wall{};for(int a=0;a<3;++a)wall.traction[a]=raw[8+a];wall.conductiveHeatFlux=raw[11];
 static ProfileScratch scratch;
#ifdef BORROW_PROFILE_SLOPES
 Profile p(in,cfg,w,scratch.transformSlope);
#else
 Profile p(in,cfg,w);
#endif
 p.setWallFlux(wall);segments(p,r);p.reconstructInternalTraces();bool fit=p.fitTeam(scratch,detail::SerialWallTeam{});
 std::vector<double> o{double(Capacity),double(fit),p.maxResidual};
 for(auto &s:p.segments){auto a=p.average(s);for(auto v:a)o.push_back(v);o.push_back(s.aRho);for(auto v:s.aU)o.push_back(v);o.push_back(s.aT);o.push_back(s.aK);o.push_back(s.aOmega);o.push_back(s.aY);}
 for(int z=0;z<2;++z){auto a=p.sourceTeam(z,detail::SerialWallTeam{},1);for(auto v:a)o.push_back(v);}
 std::vector<double> y{0.,in.ownerDistance,r.hi[0],r.hi[1]};for(int i=1;i<257;++i)y.push_back(r.hi[1]*i/257.);for(int i=0;i<cfg.nodes;++i)y.push_back(w.y[i]);
 for(double yy:y){o.push_back(yy);append(o,p.base(yy));append(o,p.point(yy));append(o,p.derivative(yy));auto v=p.physicalPrimitive(yy);o.push_back(v.rho);o.push_back(v.T);for(auto a:v.U)o.push_back(a);o.push_back(v.k);o.push_back(v.omega);for(auto a:v.Y)o.push_back(a);for(auto a:v.gradT)o.push_back(a);for(auto a:v.gradK)o.push_back(a);for(auto a:v.gradOmega)o.push_back(a);for(auto &a:v.gradU)for(auto b:a)o.push_back(b);for(auto &a:v.gradY)for(auto b:a)o.push_back(b);for(auto a:p.flux(yy))o.push_back(a);
#ifdef ENERGY_HEADER
 double momentum[2]={.125,-.25},species[2]={.01,-.01};auto t=ENERGY_NAMESPACE::terms(in,cfg,p.ctx,v,1e-4,momentum,species);o.push_back(t.conductivity);o.push_back(t.advective);o.push_back(t.stress);ENERGY_NAMESPACE::Integral<double> integral;integral.add(.25,t);integral.add(.75,t);o.push_back(integral.energy(2.));double f[2];o.push_back(ENERGY_NAMESPACE::physicalSpecies(in,cfg,p.ctx,v,1e-4,f));for(auto x:f)o.push_back(x);o.push_back(ENERGY_NAMESPACE::wallTransport(in,p.ctx,v.U[1]));
#endif
 }
 std::cout.write(reinterpret_cast<char*>(o.data()),o.size()*sizeof(double));return 0;
}
int main(int argc,char**argv){if(argc!=4)return 2;SequenceRecord r{},x{};std::ifstream seq(argv[1],std::ios::binary);while(seq.read(reinterpret_cast<char*>(&x),sizeof(x)))if(x.step==1000&&x.stage==2)r=x;std::array<double,324> raw{},row{};std::ifstream f(argv[2],std::ios::binary);bool found=false;while(f.read(reinterpret_cast<char*>(row.data()),sizeof(row)))if(row[0]==r.step&&row[1]==r.stage&&row[2]==r.owner){raw=row;found=true;}if(!found)return 3;int n=std::atoi(argv[3]);if(n==24)return run<24>(r,raw);if(n==48)return run<48>(r,raw);if(n==128)return run<128>(r,raw);return 4;}
