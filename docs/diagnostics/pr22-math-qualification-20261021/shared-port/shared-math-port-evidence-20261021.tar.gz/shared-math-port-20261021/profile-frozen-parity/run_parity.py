"""Standalone frozen-reference parity; no pytest dependency or solver evolution.

Run from any directory. --evidence-root names the preserved qualification tree.
The 48/128 cases resample a captured transformed state, not converged fine roots.
"""
import argparse,hashlib,json,math,pathlib,struct,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--evidence-root',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--expect-difference',action='store_true');p.add_argument('--borrowed',action='store_true');p.add_argument('--energy',action='store_true');p.add_argument('--sanitize',action='store_true');p.add_argument('--legacy',action='store_true');a=p.parse_args()
root=pathlib.Path('/workspace/scratch/1c3b2f34cf91/pr22-coherent-integration');e=a.evidence_root.resolve();o=a.output.resolve();o.mkdir(parents=True,exist_ok=True)
src=pathlib.Path(__file__).with_name('coherent_profile_probe.cpp')
flags=['-std=c++17','-O2','-DPROBE_U=1','-DPROBE_K=1','-DPROBE_Z=1','-DPROBE_T=0','-DENDPOINT_PCHIP=1','-DFIRST_T_QUADRATIC=1']
if a.sanitize:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
programs={}
refroot=e/'source-sign-baseline-parity/head-source' if a.legacy else e/'source-sign-coherent/coupled-source'
refheader=refroot/'common/gasWall/reconstruction/ConservativeProfile.H' if a.legacy else e/'source-sign-theory/general-coherent/HermiteProfile.H'
for mode,inc,header in [('reference',refroot,refheader),('shared',root,root/'common/gasWall/reconstruction/ConservativeProfile.H')]:
 exe=o/mode;cmd=['g++',*flags,'-I'+str(inc),'-I'+str(inc/'common'),'-DPROFILE_HEADER="'+str(header)+'"']
 if mode=='shared' and not a.legacy:cmd+=['-DSHARED_COHERENT_PROFILE=1']
 if a.borrowed and mode=='shared':cmd+=['-DBORROW_PROFILE_SLOPES=1']
 if a.energy:
  eh=e/'source-sign-theory/cheap-quadrature/GeneralEnergyIdentity.H' if mode=='reference' else root/'common/gasWall/reconstruction/GeneralEnergyIdentity.H'
  en='general_energy_probe' if mode=='reference' else 'ugkwp::gaswall::coherent_energy'
  cmd+=['-DENERGY_HEADER="'+str(eh)+'"','-DENERGY_NAMESPACE='+en]
 cmd +=['-MMD','-MF',str(o/(mode+'.d')),str(src),'-o',str(exe)]
 build=subprocess.run(cmd,text=True,capture_output=True);(o/(mode+'-build.log')).write_text(build.stdout+build.stderr);(o/(mode+'-command.json')).write_text(json.dumps(cmd,indent=2));assert build.returncode==0,build.stderr
 programs[mode]=exe
cases=[]
for owner in [90,7782]:
 d=e.parent/'TY-directional-200us';seq=d/f'sequence-owner{owner}.bin';roots=d/'selected-checkpoint-roots.bin'
 for n in [24,48,128]:
  values={};rows={}
  for mode,exe in programs.items():
   run=subprocess.run([str(exe),str(seq),str(roots),str(n)],capture_output=True);(o/f'{mode}-{owner}-{n}.log').write_bytes(run.stderr);assert run.returncode==0,run.stderr.decode();values[mode]=run.stdout;(o/f'{mode}-{owner}-{n}.bin').write_bytes(run.stdout);rows[mode]=struct.unpack('d'*(len(run.stdout)//8),run.stdout)
  x,y=rows['reference'],rows['shared'];assert len(x)==len(y)
  count=sum(i!=j for i,j in zip(x,y));r={'owner':owner,'nodes':n,'doubles':len(x),'referenceFit':x[1],'sharedFit':y[1],'allFinite':all(map(math.isfinite,x+y)),'byteEqual':values['reference']==values['shared'],'differingValues':count,'maxAbsDifference':max(abs(i-j) for i,j in zip(x,y)),'referenceSHA':hashlib.sha256(values['reference']).hexdigest(),'sharedSHA':hashlib.sha256(values['shared']).hexdigest()};cases.append(r)
report={'scope':'Exact shared-versus-frozen profile values/gradients/flux/source/fit on captured roots; higher capacity uses transformed-state resampling, not a converged fine solve. No CUDA execution.','legacy':a.legacy,'borrowed':a.borrowed,'energy':a.energy,'sanitize':a.sanitize,'cases':cases}
(o/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if a.expect_difference:assert any(not r['byteEqual'] for r in cases),'Expected old production to differ from selected Hermite reference'
else:assert all(r['byteEqual'] and r['allFinite'] and r['sharedFit']==1 for r in cases),'Shared profile differs from frozen selected reference'
