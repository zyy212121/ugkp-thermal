
#include <common/gasWall/WallModel.H>
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<long double> sp[2]; long double coef[6]={1000,0,0,1000,0,0};
 long double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<long double> rx[1]; GasStoichTerm<long double> re[1],pr[1];
 WallInput<long double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(long double a,long double b,long double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

int main(){Model m;m.in.integrateOwnerKSource=false;m.in.matchingDistance=0.00024061672332457453L;m.in.ownerDistance=9.624668932982982e-05L;m.in.temperature=796.4943727478385L;m.in.matching.temperature=552.4733890313655L;m.in.matching.velocity[0]=98.16237283755918L;m.in.matching.k=6.686476065240251e-10L;m.in.matching.omega=751.9701152019189L;m.in.massFlux[0]=.7L*8.206787523738369e-05L;m.in.massFlux[1]=.3L*8.206787523738369e-05L;
 WallModelConfig<long double>c;c.nodes=16;c.enableSst=true;struct{long double state[16][6]{},y[16]{};}w;detail::LayerContext<long double,2>ctx;
 assert(detail::makeContext(m.in,c,ctx));const long double data[16][7]={{0.0L,0.0L,0.0L,0.0L,0.3L,0.0L,1.8608978169278792e-06L},{1.0694076592203313e-06L,0.5003600092458976L,0.0L,-1.1772798500025332L,0.3L,0.47854903515513647L,1.93598551475121e-05L},{4.277630636881325e-06L,2.0013532353846992L,0.0L,-4.70961835385337L,0.3L,1.2529021299726288L,7.245575996970979e-05L},{9.624668932982983e-06L,4.501393550389696L,0.0L,-10.596837226799094L,0.3L,1.8103829287224367L,0.00015839179591127173L},{1.71105225475253e-05L,7.990669167431519L,0.0L,-18.82958613332416L,0.3L,2.289958121129794L,0.000279110903184691L},{2.673519148050828e-05L,12.431852199080044L,0.0L,-29.36442076424022L,0.3L,2.7903269401067066L,0.0004317763846763999L},{3.849867573193193e-05L,17.719699408017938L,0.0L,-42.066360574961706L,0.3L,3.377282189834469L,0.0006026089903950894L},{5.240097530179623e-05L,23.646076159607556L,0.0L,-56.6373733671591L,0.3L,4.042331274266341L,0.0007637590475901146L},{6.84420901901012e-05L,29.95859002859669L,0.0L,-72.65704916571067L,0.3L,4.6851235177449L,0.000889677751605115L},{8.662202039684682e-05L,36.57320009175243L,0.0L,-89.92862981863327L,0.3L,5.185924520851712L,0.0009755162489387744L},{0.00010694076592203312L,43.41141705190887L,0.0L,-108.28274172589958L,0.3L,5.500705627246965L,0.0010285133855611405L},{0.00012939832676566005L,50.69940850537426L,0.0L,-128.0872225797508L,0.3L,5.591267936882642L,0.001059232873905498L},{0.00015399470292772773L,58.30928539421135L,0.0L,-149.10805480756173L,0.3L,5.520034632363871L,0.001077699721113816L},{0.000180729894408236L,66.79969848279107L,0.0L,-172.4322637440106L,0.3L,4.886574259980977L,0.0010465694058858287L},{0.00020960390120718493L,80.12093990082484L,0.0L,-204.57209349728362L,0.3L,2.0246183510665833e-05L,0.0009927784137262379L},{0.00024061672332457453L,98.16237283755918L,0.0L,-244.02098371647298L,0.3L,2.5858221255995647e-05L,0.036466972488128566L}};
 for(int i=0;i<16;++i){w.y[i]=data[i][0];for(int j=0;j<6;++j)w.state[i][j]=data[i][j+1];}
 const int node=14;const auto old=w.state[node][4];std::cout.precision(20);
 for(long double h:{1e-4L,1e-5L,6.055454452393343e-6L,1e-6L,1e-7L,1e-8L,1e-9L,1e-10L}){
  long double plus[6],minus[6];w.state[node][4]=old+h;assert(detail::layerRow(m.in,c,ctx,w.state,w.y,node,plus));w.state[node][4]=old-h;assert(detail::layerRow(m.in,c,ctx,w.state,w.y,node,minus));w.state[node][4]=old;
  std::cout<<"h="<<h<<" derivative="<<(plus[4]-minus[4])/(2*h)<<" plus="<<plus[4]<<" minus="<<minus[4]<<'\n';
 }
 }