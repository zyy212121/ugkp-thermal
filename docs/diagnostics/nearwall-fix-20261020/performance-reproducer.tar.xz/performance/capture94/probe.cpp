
#include "common/gasWall/WallModel.H"
#include <cassert>
#include <cmath>
#include <limits>
#include <iostream>
using namespace ugkwp;
using namespace ugkwp::gaswall;
struct Model {
 SpeciesThermoData<double> sp[2]; double coef[6]={1000,0,0,1000,0,0};
 double elements[2]={1,1}, basis[2]={-1,1};
 GasReactionData<double> rx[1]; GasStoichTerm<double> re[1],pr[1];
 WallInput<double,2> in;
 Model(){for(int s=0;s<2;++s){sp[s].coefficientOffset=3*s;sp[s].molarMass=.028;sp[s].minTemperature=200;sp[s].maxTemperature=4000;sp[s].referencePressure=101325;sp[s].referenceTemperature=300;sp[s].referenceEntropy=1500;sp[s].hasEntropyReference=true;}
 auto& t=in.model.thermo;t.species=sp;t.coefficients=coef;t.coefficientCount=6;t.elementCount=1;t.elementComposition=elements;t.speciesOrderHash=1;
 rx[0].reactantCount=1;rx[0].productCount=1;rx[0].highRate.preExponential=2;re[0].species=0;re[0].coefficient=1;pr[0].species=1;pr[0].coefficient=1;
 auto& m=in.model.mechanism;m.reactions=rx;m.reactionCount=1;m.reactants=re;m.reactantTermCount=1;m.products=pr;m.productTermCount=1;m.referencePressure=101325;m.speciesOrderHash=1;m.stoichiometricBasis=basis;m.independentRank=1;
 in.integrateOwnerKSource=true; // This fixture explicitly tests auxiliary source integrals.
 in.pressure=101325;in.temperature=300;in.normal[1]=1;in.matchingDistance=.01;in.ownerDistance=.004;
 in.matching.temperature=500;in.matching.velocity[0]=10;in.matching.massFraction[0]=.7;in.matching.massFraction[1]=.3;
 in.model.viscosity=2e-5;in.model.conductivity=.04;in.model.diffusivity[0]=in.model.diffusivity[1]=1e-5;
 }
};
bool near(double a,double b,double r=1e-10){return std::abs(a-b)<1e-10+r*std::abs(b);}

int main(){Model m;m.in.integrateOwnerKSource=false;m.in.matchingDistance=0.00024061672332457453;m.in.ownerDistance=9.624668932982982e-05;m.in.temperature=796.4943727478385;m.in.matching.temperature=552.4733890313655;m.in.matching.velocity[0]=98.16237283755918;m.in.matching.k=6.686476065240251e-10;m.in.matching.omega=751.9701152019189;m.in.massFlux[0]=.7*8.206787523738369e-05;m.in.massFlux[1]=.3*8.206787523738369e-05;
    WallModelConfig<double> c;c.nodes=16;c.enableSst=true;WallWorkspace<double,2,16>w;detail::LayerContext<double,2>ctx;
    assert(detail::makeContext(m.in,c,ctx));const double data[16][7]={{0.0,0.0,0.0,0.0,0.3,0.0,1.8608978169278792e-06},{1.0694076592203313e-06,0.5003600092458976,0.0,-1.1772798500025332,0.3,0.47854903515513647,1.93598551475121e-05},{4.277630636881325e-06,2.0013532353846992,0.0,-4.70961835385337,0.3,1.2529021299726288,7.245575996970979e-05},{9.624668932982983e-06,4.501393550389696,0.0,-10.596837226799094,0.3,1.8103829287224367,0.00015839179591127173},{1.71105225475253e-05,7.990669167431519,0.0,-18.82958613332416,0.3,2.289958121129794,0.000279110903184691},{2.673519148050828e-05,12.431852199080044,0.0,-29.36442076424022,0.3,2.7903269401067066,0.0004317763846763999},{3.849867573193193e-05,17.719699408017938,0.0,-42.066360574961706,0.3,3.377282189834469,0.0006026089903950894},{5.240097530179623e-05,23.646076159607556,0.0,-56.6373733671591,0.3,4.042331274266341,0.0007637590475901146},{6.84420901901012e-05,29.95859002859669,0.0,-72.65704916571067,0.3,4.6851235177449,0.000889677751605115},{8.662202039684682e-05,36.57320009175243,0.0,-89.92862981863327,0.3,5.185924520851712,0.0009755162489387744},{0.00010694076592203312,43.41141705190887,0.0,-108.28274172589958,0.3,5.500705627246965,0.0010285133855611405},{0.00012939832676566005,50.69940850537426,0.0,-128.0872225797508,0.3,5.591267936882642,0.001059232873905498},{0.00015399470292772773,58.30928539421135,0.0,-149.10805480756173,0.3,5.520034632363871,0.001077699721113816},{0.000180729894408236,66.79969848279107,0.0,-172.4322637440106,0.3,4.886574259980977,0.0010465694058858287},{0.00020960390120718493,80.12093990082484,0.0,-204.57209349728362,0.3,2.0246183510665833e-05,0.0009927784137262379},{0.00024061672332457453,98.16237283755918,0.0,-244.02098371647298,0.3,2.5858221255995647e-05,0.036466972488128566}};
    for(int i=0;i<16;++i){w.y[i]=data[i][0];for(int j=0;j<6;++j)w.state[i][j]=data[i][j+1];}
    double norm=0;assert(detail::allResidual(m.in,c,ctx,w.state,w.y,w.residual,norm));
    assert(detail::assembleJacobianNode(m.in,c,ctx,w,14));
    const double derivative=w.diagonal[14][4][4],reference=-0.0008033936816825621;
    std::cout.precision(17);std::cout<<derivative<<" reference="<<reference<<"\n";
    }