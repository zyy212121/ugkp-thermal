"""Rebuild host production-kernel audits with the saved before/after coefficient headers.

Run with WSL python3. Inputs are read only. Output is written to reproduced/.
The rest of the production source comes from --repo, ideally the delivered commit.
No GPU run or advancement of an OpenFOAM case is performed.
"""
from pathlib import Path
import argparse
import json
import subprocess
import csv

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, default=Path("/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018"))
parser.add_argument("--include-160", action="store_true", help="Requires exported 160-layer input; export160.py produces it read-only from the original reference.")
args = parser.parse_args()
out = ROOT / "reproduced"
out.mkdir(exist_ok=True)
inputs = {
    "wallfunction-of10-matched-80": args.repo.parent / "flux-continuation-20261020/budget-input/wallfunction-of10-matched-80",
    "wallfunction-wallFunction-chunk20": args.repo.parent / "flux-continuation-20261020/budget-input/wallfunction-wallFunction-chunk20",
}
if args.include_160:
    inputs["wallfunction-of10-matched-160"] = ROOT / "wallfunction-of10-matched-160-input"
stations = []
for variant in ("before", "after"):
    binary = out / ("thermal-budget-" + variant)
    command = [
        "g++", "-std=c++17", "-O2", "-I" + str(ROOT / (variant + "-include")),
        "-I.", "-Icommon", "-Icommon/gasNumerics", "-Ivalidation/tests/gas_transport",
        str(ROOT / "thermal-budget.cpp"), "-o", str(binary),
    ]
    subprocess.run(command, cwd=args.repo, check=True)
    for name, source in inputs.items():
        target = out / (variant + "-" + name)
        target.mkdir(exist_ok=True)
        result = subprocess.run(
            [str(binary), str(source), str(target), ".003", "normal", "4", "1", "1"],
            cwd=args.repo, capture_output=True, text=True, check=True,
        )
        (target / "run.log").write_text(result.stdout + result.stderr)
        cells = list(csv.DictReader((target / "thermal-cells.csv").open()))
        faces = list(csv.DictReader((target / "thermal-faces.csv").open()))
        for station in (.35, .38, .58, .75, .85):
            cell = min(cells, key=lambda c: abs(float(c["x"]) - station) + 100 * float(c["y"]))
            face = next(f for f in faces if f["owner"] == cell["cell"] and int(f["neighbour"]) >= 0 and float(f["y"]) > float(cell["y"]) + 1e-8)
            stations.append({"variant": variant, "dataset": name, "station": station, "cell": cell, "upper_face": face})
        print(variant, name, "completed")
(out / "stations.json").write_text(json.dumps(stations, indent=2))
print(out / "stations.json")
