from pathlib import Path
import csv,json
out=Path(__file__).resolve().parent;records=[]
for ny,prefix in [(80,''),(160,'before-')]:
 for variant,stem in [('before',prefix),('after','after-')]:
  folder=out/(stem+f'wallfunction-of10-matched-{ny}')
  cells=list(csv.DictReader((folder/'thermal-cells.csv').open()));faces=list(csv.DictReader((folder/'thermal-faces.csv').open()))
  for station in [.35,.38,.58,.75,.85]:
   c=min(cells,key=lambda c:abs(float(c['x'])-station)+100*float(c['y']))
   f=next(f for f in faces if f['owner']==c['cell'] and int(f['neighbour'])>=0 and float(f['y'])>float(c['y'])+1e-8)
   records.append({'ny':ny,'variant':variant,'station':station,'cell':c,'upper_face':f})
(out/'matched-grid-frozen-comparison.json').write_text(json.dumps(records,indent=2))
for r in records:
 if r['station']==.58: print(r['ny'],r['variant'],'y',r['cell']['y'],'Tdot',r['cell']['Tdot'],'TdotCellStressWork',r['cell']['TdotCellStressWork'],'compactWork',r['upper_face']['workReconstructed'],'cellWork',r['upper_face']['workCellStress'],'heat',r['upper_face']['heat'])