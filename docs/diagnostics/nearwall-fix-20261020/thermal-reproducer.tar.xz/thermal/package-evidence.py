"""Save reproducible coefficient snapshots and exact wall-law verification."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET

REPO = Path("/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-merged-20261018")
OUT = Path(__file__).resolve().parent
INITIAL = "cc392dd40e5736494975163cad5b3139dcf1065b"
header = "common/operators/gasFaceSubgridTransportProperties.cuh"
for variant in ("before", "after"):
    target = OUT / (variant + "-include") / "operators/gasFaceSubgridTransportProperties.cuh"
    target.parent.mkdir(parents=True, exist_ok=True)
    content = subprocess.check_output(["git", "show", INITIAL + ":" + header], cwd=REPO) if variant == "before" else (REPO / header).read_bytes()
    target.write_bytes(content)
shutil.copy2(REPO.parent / "flux-continuation-20261020/matched-heat-verify.cpp", OUT / "matched-heat-verify.cpp")
for name in ("decompose.py", "compare-coefficients.py", "read160.py"):
    p = OUT / name
    p.write_text(p.read_text().replace(
        "out=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-20/ugkp-thermal-wallfunction-reactingsst-pr-https/work/wall-heat-audit')",
        "out=Path(__file__).resolve().parent"))

command = ["g++", "-std=c++17", "-O2", "-I.", "-Icommon", "-Icommon/gasNumerics",
           str(OUT / "matched-heat-verify.cpp"), "-o", str(OUT / "matched-heat-verify")]
subprocess.run(command, cwd=REPO, check=True)
verifications = []
for ny in (80, 160):
    source = REPO.parent / f"flux-continuation-20261020/of10-matched-heat-{ny}/matched-wall-last.csv"
    run = subprocess.run([str(OUT / "matched-heat-verify"), str(source)], capture_output=True, text=True, check=True)
    verifications.append({"ny": ny, "input": str(source), "stdout": run.stdout.strip()})
    print(run.stdout.strip())
(OUT / "exact-wall-law-verification.json").write_text(json.dumps(verifications, indent=2))

paths = [
    "common/operators/computeRiemannGasFaceFluxDevice.cuh",
    header,
    "common/gasNumerics/OpenFoamWallFunctions.cuh",
    "common/gasNumerics/OpenFoamViscousFlux.cuh",
    "validation/tests/gas_transport/test_internal_transport_interpolation.py",
    "validation/tests/gas_transport/test_mixture_contact_flux.py",
]
baseline = ET.parse(OUT / "baseline-extra-tests.xml")
failures = [t.attrib["name"] for t in baseline.iter("testcase") if t.find("failure") is not None]
manifest = {
    "repository": str(REPO),
    "initial_head": INITIAL,
    "current_head_at_packaging": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
    "files_sha256": {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in paths},
    "final_test_command": "NVCC=/usr/local/cuda-13.1/bin/nvcc python3 -m pytest -q validation/tests/gas_transport/test_internal_transport_interpolation.py --tb=short",
    "final_test_result": "7 passed in 4.53s; final-transport-tests.xml",
    "species_test_command": "python3 -m pytest -q validation/tests/gas_transport/test_mixture_contact_flux.py validation/tests/gas_transport/test_mixture_slau2_flux.py validation/tests/gas_transport/test_mixture_transport.py --tb=short",
    "species_test_result_before_coefficient_patch": "75 passed in 54.56s",
    "wall_affected_result": "27 passed in 19.81s, internal transport (then 6 tests) plus test_mixture_wall_function.py and test_wall_transport_diagnostics.py",
    "unrelated_suite_baseline": {
        "head": INITIAL,
        "result": "35 failed, 31 passed, 4 deselected in 140.55s",
        "failure_names": failures,
        "four_deselected": "Historical b236292f fixture compile checks reference diagnostics absent from the archived State; these also fail on the modified tree as fixture compilation errors.",
    },
    "interpretation": [
        "All thermal-budget before/after changes here are frozen-field operator evaluations, not newly converged solutions.",
        "The signed wall law agrees with the matched OF reference. The stock OF constrained alphat boundary is a different closure and was not substituted.",
        "Internal coefficient interpolation has manufactured linear-field counterexamples and is repaired. The current plate stretched mesh changes first-face turbulent transport by about 1 percent.",
        "Changing viscous work to OF cell-stress-times-cell-velocity is diagnostic only. It is not asserted uniquely correct and production work remains traction times reconstructed face velocity.",
        "Ny80/Ny160 frozen wallfunction grids do not establish convergence of the remaining thermal discrepancy; volumetric residual increases when the wall cell thins.",
    ],
}
(OUT / "audit-manifest.json").write_text(json.dumps(manifest, indent=2))
