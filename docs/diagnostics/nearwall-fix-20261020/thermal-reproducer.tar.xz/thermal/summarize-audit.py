"""Collect small, source-attributed station and frozen-operator evidence."""
from pathlib import Path
import csv
import json

OUT = Path(__file__).resolve().parent
ROOT = Path("/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test")
reference = Path("/mnt/d/tempt/ugkp-flux-continuation-20261020/matched-reference-stations.csv")
refs = [row for row in csv.DictReader(reference.open()) if float(row["station"]) == .58]
decomp = json.loads((OUT / "frozen-wall-decomposition.json").read_text())["comparisons"][2]
coefficient = json.loads((OUT / "coefficient-frozen-comparison.json").read_text())
grid = json.loads((OUT / "matched-grid-frozen-comparison.json").read_text())
station = {"reference_station_csv": str(reference), "matched_reference": refs,
           "wall_law_inputs_and_single_variable_diagnostics": decomp,
           "frozen_coefficient_changes": coefficient,
           "frozen_grid_comparison_at_station": [row for row in grid if row["station"] == .58],
           "exact_wall_law_verification": json.loads((OUT / "exact-wall-law-verification.json").read_text()),
           "scope": "Frozen input operator comparison; no updated solution or convergence claim.",
           "remaining_question": "Internal transport interpolation is fixed by manufactured linear tests, but the remaining wallFunction heat-flux discrepancy requires actual coupled advancement and a physically consistent grid study. OF cell-stress work is a diagnostic comparison, not a unique correctness standard.",
           "provenance": {
               "matched80_fields": str(ROOT / "flux-continuation-20261020/of10-matched-heat-80/1282"),
               "matched160_fields": str(ROOT / "flux-continuation-20261020/of10-matched-heat-160/2887"),
               "matched_wall_law_source": str(ROOT / "flux-continuation-20261020/rhoSimpleMatchedWallFoam/EEqn.H"),
               "reference_face_csv_80": str(ROOT / "flux-continuation-20261020/of10-matched-heat-80/matched-wall-last.csv"),
               "reference_face_csv_160": str(ROOT / "flux-continuation-20261020/of10-matched-heat-160/matched-wall-last.csv"),
               "frozen_ugkp_input": str(ROOT / "flux-continuation-20261020/budget-input/wallfunction-wallFunction-chunk20"),
           }}
(OUT / "thermal-audit-summary.json").write_text(json.dumps(station, indent=2))
with (OUT / "matched-reference-station.csv").open("w") as f:
    writer = csv.DictWriter(f, fieldnames=refs[0])
    writer.writeheader()
    writer.writerows(refs)
print(json.dumps(refs, indent=2))
