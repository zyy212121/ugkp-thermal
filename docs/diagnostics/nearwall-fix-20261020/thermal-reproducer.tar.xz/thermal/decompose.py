from pathlib import Path
import numpy as np, csv, json
root=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test')
out=Path(__file__).resolve().parent
base=root/'flux-continuation-20261020/budget-input'
def field(folder,name,integer=False):return np.fromfile(folder/(name+'.bin'),dtype='<i4' if integer else '<f8')
props={'mu':1.7244421537657099e-5,'cp':1004.675,'R':287.0500676,'Pr':.72,'Prt':.9,'Cmu':.09,'kappa':.41,'E':9.8}
ratio=props['Pr']/props['Prt'];P=9.24*(ratio**.75-1)*(1+.28*np.exp(-.007*ratio))
lo=1/(props['kappa']*ratio);hi=4*lo
while props['kappa']*ratio*hi-np.log(props['E']*hi)-props['kappa']*P<0:hi*=2
for _ in range(100):
 m=(lo+hi)/2
 if props['kappa']*ratio*m-np.log(props['E']*m)-props['kappa']*P>0:hi=m
 else:lo=m
yt=(lo+hi)/2

def law(r):
 rho=r['p']/(props['R']*r['Tw']);u=props['Cmu']**.25*np.sqrt(r['k']);yp=u*r['y']*rho/props['mu'];visc=yp<yt
 tp=props['Pr']*yp if visc else props['Prt']*(np.log(props['E']*yp)/props['kappa']+P)
 uc=0 if visc else u/props['kappa']*np.log(props['E']*yt)-r['wallSpeed']
 C=.5*rho*u*(props['Pr']*r['Urel']**2 if visc else props['Prt']*r['Urel']**2+(props['Pr']-props['Prt'])*uc**2)
 K=max(props['mu']*props['cp']/props['Pr'],props['cp']*rho*u*r['y']/tp)
 grad=(r['Tw']-r['T'])*r['delta']
 return {'rhoWall':rho,'yPlus':yp,'conductivity':K,'gradT':grad,'conductionIntoGas':K*grad,'viscousIntoGas':-C/tp,'qIntoGas':K*grad-C/tp}

data={};rows=[]
for label,folder in [('ugkp-02305','wallfunction-wallFunction-chunk20'),('of10-matched-80','wallfunction-of10-matched-80')]:
 path=base/folder
 d={n:field(path,n) for n in ['Cx','Cy','Ux','Uy','Uz','p','k','Tgas','riemannBoundaryT','riemannBoundaryUx','riemannBoundaryUy','riemannBoundaryUz','sstWallDistance','deltaCoeffs']}
 owner=field(path,'faceOwner',True);kind=field(path,'riemannBoundaryKind',True)
 nCells,nFaces,nInt=map(int,(path/'counts.txt').read_text().split());data[label]={}
 for f in range(nInt,nFaces):
  if kind[f]!=2:continue
  c=int(owner[f]);wall=np.array([d['riemannBoundaryU'+v][f]for v in 'xyz']);vel=np.array([d['U'+v][c]for v in 'xyz'])
  r={'dataset':label,'face':f,'owner':c,'x':d['Cx'][c],'y':d['sstWallDistance'][c],'T':d['Tgas'][c],'Tw':d['riemannBoundaryT'][f],'p':d['p'][c],'k':d['k'][c],'Urel':float(np.linalg.norm(vel-wall)),'wallSpeed':float(np.linalg.norm(wall)),'delta':d['deltaCoeffs'][f]}
  data[label][c]=r;rows.append(r|law(r))
with(out/'frozen-wall-decomposition.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
ref=list(csv.DictReader((root/'flux-continuation-20261020/of10-matched-heat-80/matched-wall-last.csv').open()));qref={int(r['owner']):float(r['qIntoGas'])for r in ref}
print('matched_all_faces_max_abs_q_error',max(abs(law(r)['qIntoGas']-qref[c])for c,r in data['of10-matched-80'].items()))
comparisons=[]
for station in [.35,.38,.58,.75,.85]:
 c=min(data['ugkp-02305'],key=lambda c:abs(data['ugkp-02305'][c]['x']-station));a=data['ugkp-02305'][c];b=data['of10-matched-80'][c]
 row={'station':station,'owner':c,'ugkp':a|law(a),'of10':b|law(b),'replace_only':{}}
 for key in ['T','Urel','k','p']:
  trial=a|{key:b[key]};row['replace_only'][key]=law(trial)
 comparisons.append(row)
(out/'frozen-wall-decomposition.json').write_text(json.dumps({'properties':props,'thermalYPlus':yt,'comparisons':comparisons},indent=2))
print(json.dumps(comparisons[2],indent=2))