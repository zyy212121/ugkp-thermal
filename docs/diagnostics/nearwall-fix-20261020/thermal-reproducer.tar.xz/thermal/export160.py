from pathlib import Path
import sys,re,json
import numpy as np
root=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test')
sys.path.insert(0,str(root/'pr21-wallmodel-audit-20261019/docs/diagnostics/arc3696-wallmodel-audit-20261019/tools'))
import foam_io as m
case=root/'flux-continuation-20261020/of10-matched-heat-160';pm=case/'constant/polyMesh'
out=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-20/ugkp-thermal-wallfunction-reactingsst-pr-https/work/wall-heat-audit/wallfunction-of10-matched-160-input');out.mkdir(exist_ok=True)
points=np.array([list(map(float,x.split()))for x in re.findall(r'\(([^()]*)\)',m.list_body((pm/'points').read_text()))])
faces=np.array([list(map(int,x.split()))for x in re.findall(r'\d+\(([^()]*)\)',m.list_body((pm/'faces').read_text()))]);assert faces.shape[1]==4
P=points[faces];Cf=P.mean(axis=1);Sf=np.cross(P,np.roll(P,-1,axis=1)).sum(axis=1)/2;area=np.linalg.norm(Sf,axis=1);normal=Sf/area[:,None]
own=np.fromstring(m.list_body((pm/'owner').read_text()),sep=' ',dtype=np.int32);nei0=np.fromstring(m.list_body((pm/'neighbour').read_text()),sep=' ',dtype=np.int32);nf=len(own);ni=len(nei0);nc=int(own.max()+1);nei=np.r_[nei0,np.full(nf-ni,-1,dtype=np.int32)]
cellids=np.r_[own,nei0];fids=np.r_[np.arange(nf),np.arange(ni)];order=np.argsort(cellids,kind='stable');counts=np.bincount(cellids,minlength=nc).astype(np.int32);starts=np.r_[0,np.cumsum(counts[:-1])].astype(np.int32);cellfaces=fids[order].astype(np.int32)
assert np.all(counts==6)
C=np.column_stack([(np.bincount(own,weights=Cf[:,d],minlength=nc)+np.bincount(nei0,weights=Cf[:ni,d],minlength=nc))/counts for d in range(3)])
V=np.bincount(own,weights=np.sum(Sf*(Cf-C[own]),axis=1)/3,minlength=nc)+np.bincount(nei0,weights=-np.sum(Sf[:ni]*(Cf[:ni]-C[nei0]),axis=1)/3,minlength=nc)
assert np.all(V>0)
delta=Cf-C[own];delta[:ni]=C[nei[:ni]]-C[own[:ni]];distance=np.sum(normal*delta,axis=1);assert distance.min()>0
coeff=1/distance;weight=np.ones(nf);weight[:ni]=np.sum(normal[:ni]*(C[nei[:ni]]-Cf[:ni]),axis=1)/distance[:ni]
data={'faceOwner':own,'faceNeighbour':nei,'cellPlaneCount':counts,'cellPlaneStart':starts,'cellFaceId':cellfaces,'facePeriodicPair':np.full(nf,-1,dtype=np.int32),'V':V,'cellLength':V**(1/3),'deltaCoeffs':coeff,'faceWeight':weight,'magSf':area,'sstWallDistance':C[:,1]}
for j,d in enumerate('xyz'):data['C'+d]=C[:,j];data['faceC'+d]=Cf[:,j];data['Sf'+d]=Sf[:,j]
patches={}
for match in re.finditer(r'(\w+)\s*\{([^{}]*)\}',m.strip_comments((pm/'boundary').read_text())):
 name,body=match.groups();a=re.search(r'startFace\s+(\d+)',body);b=re.search(r'nFaces\s+(\d+)',body)
 if a and b:patches[name]=(int(a[1]),int(b[1]))
tp=case/'2887';d={name:m.read_field(tp/name,nc,name=='U')for name in ['U','T','p','k','omega','nut']}
rho=d['p']/(287.0500676*d['T']);data.update({'rho':rho,'Tgas':d['T'],'p':d['p'],'k':d['k'],'omega':d['omega'],'nut':d['nut'],'rhoE':rho*((1004.675-287.0500676)*d['T']+.5*np.sum(d['U']**2,axis=1)),'speciesRhoAir':rho,'speciesRhoCO2':np.zeros(nc)})
for j,axis in enumerate('xyz'):data['U'+axis]=d['U'][:,j];data['rhoU'+axis]=rho*d['U'][:,j]
kinds=np.zeros(nf,dtype=np.int32)
for name in ['upstreamWall','porousWall','downstreamWall']:
 start,num=patches[name];kinds[start:start+num]=2
start,num=patches['sides'];kinds[start:start+num]=3
for field in ['gasBoundaryKind','riemannBoundaryKind']:data[field]=kinds
for prefix in ['riemannBoundary','gasBoundary']:
 for suffix in ['PFix','TFix','UFix','RhoFix']:data[prefix+suffix]=np.zeros(nf,dtype=np.int32)
 for suffix in ['P','T','Ux','Uy','Uz','Rho']:data[prefix+suffix]=np.zeros(nf)
for name,(start,num)in patches.items():
 if name=='sides':continue
 for prefix in ['riemannBoundary','gasBoundary']:
  if 'Wall'in name:
   data[prefix+'T'][start:start+num]=290.53216418474562;data[prefix+'TFix'][start:start+num]=1;data[prefix+'UFix'][start:start+num]=1
  else:
   data[prefix+'P'][start:start+num]=124094.11053558919;data[prefix+'PFix'][start:start+num]=1
   if name!='outlet':
    data[prefix+'T'][start:start+num]=275.90898782976797;data[prefix+'TFix'][start:start+num]=1;data[prefix+'UFix'][start:start+num]=1;data[prefix+'Ux'][start:start+num]=179.81233357102013
data['sstBoundaryKMode']=np.zeros(nf,dtype=np.int32);data['sstBoundaryOmegaMode']=np.zeros(nf,dtype=np.int32);data['sstBoundaryK']=np.zeros(nf);data['sstBoundaryOmega']=np.zeros(nf)
for name in ['inlet','top']:
 start,num=patches[name];data['sstBoundaryKMode'][start:start+num]=1;data['sstBoundaryOmegaMode'][start:start+num]=1;data['sstBoundaryK'][start:start+num]=1.212467823909593;data['sstBoundaryOmega'][start:start+num]=2010.3630052883425
for name,array in data.items():array.astype('<i4'if np.issubdtype(array.dtype,np.integer)else'<f8').tofile(out/(name+'.bin'))
(out/'counts.txt').write_text(f'{nc} {nf} {ni}\n')
(out/'provenance.json').write_text(json.dumps({'case':str(case),'iteration':2887,'counts':[nc,nf,ni],'source':'Read-only orthogonal hexahedra reconstruction; cell centre is mean of 6 face centres. Independent snapshot, no GPU advance.'},indent=2))
print(nc,nf,ni,float(V.sum()))