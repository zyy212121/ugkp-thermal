from pathlib import Path
import csv,json
out=Path('/mnt/c/Users/25094/Documents/Codex/2026-10-20/ugkp-thermal-wallfunction-reactingsst-pr-https/work/wall-heat-audit')
for name in ['wallfunction-of10-matched-80','wallfunction-wallFunction-chunk20']:
 cells=list(csv.DictReader((out/name/'thermal-cells.csv').open()))
 c=min(cells,key=lambda c:abs(float(c['x'])-.58)+100*float(c['y']))
 print(name,json.dumps(c,indent=2))
 faces=list(csv.DictReader((out/name/'thermal-faces.csv').open()))
 print(json.dumps([f for f in faces if f['owner']==c['cell']or f['neighbour']==c['cell']],indent=2))