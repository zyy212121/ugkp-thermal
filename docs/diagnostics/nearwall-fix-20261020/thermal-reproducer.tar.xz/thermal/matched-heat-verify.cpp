
#include "common/gasNumerics/OpenFoamWallFunctions.cuh"
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
int main(int argc,char**argv){std::ifstream in(argv[1]);std::string line;std::getline(in,line);double worstQ=0,worstK=0;int n=0;
while(std::getline(in,line)){std::replace(line.begin(),line.end(),',',' ');std::istringstream s(line);int face,owner;double y,rho,mu,cp,k,u,uw,grad,conductivity,C,q;
 if(!(s>>face>>owner>>y>>rho>>mu>>cp>>k>>u>>uw>>grad>>conductivity>>C>>q))return 2;
 auto a=ugkpwall::sstJayatillekeThermalTransport(rho,cp,mu,.72,.9,.09,.41,9.8,ugkpwall::jayatillekeSmoothP(.8),ugkpwall::jayatillekeThermalYPlus(.8),k,y,u,uw,grad,false);
 if(!a.valid)return 3;worstQ=std::max(worstQ,std::abs(a.heatFlux+q)/std::max(1.,std::abs(q)));worstK=std::max(worstK,std::abs(a.conductivity-conductivity)/conductivity);++n;}
 std::cout.precision(17);std::cout<<"faces="<<n<<" maximum_scaled_heat_difference="<<worstQ<<" maximum_relative_conductivity_difference="<<worstK<<'\n';return worstQ<1e-10&&worstK<1e-13?0:4;}
