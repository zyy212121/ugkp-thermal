from pathlib import Path
import csv,json
out=Path(__file__).resolve().parent
rows=[]
for name in ['wallfunction-of10-matched-80','wallfunction-wallFunction-chunk20']:
 data={}
 for variant,prefix in [('before',''),('after','after-')]:
  cs=list(csv.DictReader((out/(prefix+name)/'thermal-cells.csv').open()));fs=list(csv.DictReader((out/(prefix+name)/'thermal-faces.csv').open()))
  c=min(cs,key=lambda c:abs(float(c['x'])-.58)+100*float(c['y']))
  f=next(f for f in fs if f['owner']==c['cell']and int(f['neighbour'])>=0 and float(f['y'])>float(c['y'])+1e-8)
  data[variant]={'cell':c,'face':f}
 rows.append({'dataset':name,'variants':data})
(out/'coefficient-frozen-comparison.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 print(r['dataset'])
 for v,d in r['variants'].items(): print(v,'traction',d['face']['tractionX'],'work',d['face']['workReconstructed'],'heat',d['face']['heat'],'Tdot',d['cell']['Tdot'])