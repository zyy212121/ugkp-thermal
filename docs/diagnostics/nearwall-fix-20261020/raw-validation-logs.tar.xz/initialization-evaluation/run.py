from pathlib import Path
import subprocess,shutil,json,csv,time,re
out=Path(__file__).resolve().parent;repo=out.parents[2]
snapshot=out/'snapshot';shutil.copytree(repo/'common',snapshot/'common',dirs_exist_ok=True)
header=snapshot/'common/gasWall/ReactingWallLayer.H';text=header.read_text()
text=text.replace('#pragma once','#pragma once\nnamespace initprobe { struct Stats {long point=0,interval=0,row=0,residual=0,newton=0,seed=0; double picard=-1,candidate=-1,initial=-1; int selected=0;} ; inline Stats stats; }',1)
for pattern,statement in [
 (r'(bool pointState\([\s\S]*?\)\{)','++::initprobe::stats.point;'),
 (r'(bool intervalFlux\([\s\S]*?\)\{)','++::initprobe::stats.interval;'),
 (r'(bool layerRow\([\s\S]*?\)\{)','++::initprobe::stats.row;'),
 (r'(bool allResidual\([\s\S]*?\)\{)','++::initprobe::stats.residual;'),
 (r'(bool newtonStep\([\s\S]*?\)\{)','++::initprobe::stats.newton;')]:
 text,n=re.subn(pattern,lambda m:m[1]+statement,text,count=1);assert n==1,(pattern,n)
text=text.replace('for(int iteration=0;iteration<200;++iteration){','for(int iteration=0;iteration<200;++iteration){++::initprobe::stats.seed;',1)
boost="""
        LayerPoint<R,N> edge;
        seeded=pointState(in,c,ctx,w.state[c.nodes-1],edge);
        const R speed=::sqrt(ctx.edgeU[0]*ctx.edgeU[0]+ctx.edgeU[1]*ctx.edgeU[1]);
        const R kScale=seeded?in.model.viscosity*speed/(in.matchingDistance*edge.rho*::sqrt(in.model.sstCoefficients.betaStar)):R(0);
        for(int i=1;seeded&&i<c.nodes-1;++i){const R eta=w.y[i]/in.matchingDistance;
            w.state[i][N+2]=::sqrt(w.state[i][N+2]*w.state[i][N+2]+R(4)*eta*(R(1)-eta)*kScale);
            seeded=seeded&&gasFinite(w.state[i][N+2]);}
"""
marker='    seeded=team.broadcast(seeded);'
text=text.replace(marker,'#if INIT_POLICY==1\n    if(c.enableSst&&seeded){'+boost+'}\n#endif\n'+marker,1)
select="""
    ::initprobe::stats.picard=norm;
#if INIT_POLICY==2
    for(int i=0;i<c.nodes;++i)for(int j=0;j<N+4;++j)w.trial[i][j]=w.state[i][j];
    if(c.enableSst&&seeded){BOOST}
    R candidateNorm=0;
    const bool candidateMeasured=seeded&&allResidual(in,c,ctx,w.state,w.y,w.delta,candidateNorm,team);
    ::initprobe::stats.candidate=candidateMeasured?candidateNorm:-1;
    if(candidateMeasured&&candidateNorm<norm){
        norm=candidateNorm;::initprobe::stats.selected=1;
        for(int i=0;i<c.nodes;++i)for(int j=0;j<N+4;++j)w.residual[i][j]=w.delta[i][j];
    }else{
        for(int i=0;i<c.nodes;++i)for(int j=0;j<N+4;++j)w.state[i][j]=w.trial[i][j];
    }
#endif
    ::initprobe::stats.initial=norm;
""".replace('BOOST',boost)
marker='    const R tolerance=c.absoluteTolerance+c.relativeTolerance;'
assert text.count(marker)==1;text=text.replace(marker,select+marker,1);header.write_text(text)
source=r"""
#include "validation/tests/gas_wall/fixtures/sst_small_k_column_capture.H"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <chrono>
using namespace ugkwp::gaswall;
void solve(const std::string& label,CapturedSstWall& m,int nodes){
 m.config.nodes=nodes;m.input.integrateOwnerKSource=false;m.input.volumeSstClosure=false;
 ugkp::diagnostics::DeviceContext diag{};m.input.diagnostics=&diag;m.input.model.thermo.diagnostics=&diag;
 WallWorkspace<double,2,128>w;WallOutput<double,2>o;WallStatus s;initprobe::stats={};
 auto t=std::chrono::steady_clock::now();bool ok=evaluateWallModel(m.input,m.config,w,o,s);double us=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-t).count();
 auto&a=initprobe::stats;
 printf("%s,%d,%d,%d,%u,%d,%.17g,%.17g,%.17g,%.17g,%d,%ld,%ld,%ld,%ld,%ld,%ld,%.17g,%.17g,%.17g\n",label.c_str(),nodes,INIT_POLICY,int(ok),diag.fatalClaim,o.iterations,o.residual,a.picard,a.candidate,a.initial,a.selected,a.point,a.interval,a.row,a.residual,a.newton,a.seed,us,o.traction[0],o.conductiveHeatFlux);
}
int main(int argc,char**argv){
 puts("case,nodes,policy,ok,fatal,iterations,final_residual,picard_initial,candidate_initial,chosen_initial,selected,point_calls,interval_calls,row_calls,residual_calls,newton_calls,picard_sweeps,microseconds,tauX,heat");
 for(int nodes:{24,48,128}){CapturedSingularWall tiny;solve("actual-small-k",tiny,nodes);CapturedSstWall restart;solve("original-restart",restart,nodes);
 for(int arg=1;arg<argc;++arg){std::ifstream f(argv[arg]);std::string line;std::getline(f,line);int index=0;while(std::getline(f,line)){
 std::replace(line.begin(),line.end(),',',' ');std::istringstream row(line);int face,owner;double L,y,p,T,u,v,w,k,omega;
 if(!(row>>face>>owner>>L>>y>>p>>T>>u>>v>>w>>k>>omega))return 2;
 CapturedSstWall m;auto&i=m.input;i.matchingDistance=L;i.ownerDistance=y;i.pressure=p;i.matching.temperature=T;i.matching.velocity[0]=u;i.matching.velocity[1]=v;i.matching.velocity[2]=w;i.matching.k=k;i.matching.omega=omega;
 solve("file"+std::to_string(arg)+"-face"+std::to_string(face),m,nodes);++index;
 }} }
}
"""
(out/'probe.cpp').write_text(source)
inputdir=repo/'docs/diagnostics/bvp-coupling-20261020/fixed-input';inputs=[inputdir/x for x in ['continuation-input.csv','of10-input.csv','of10-matched-input.csv']]
metadata={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'commands':[],'notes':'CPU isolation only; actual-small-k includes captured full tangential gradients; historical CSV inputs use their original zero tangential-gradient convention. Owner projection/publication disabled equally because initializer/Newton objective only. Timings are one-shot instrumented and are not performance claims.'}
for policy in range(3):
 exe=out/f'policy-{policy}'
 cmd=['g++','-O3','-std=c++17','-ffp-contract=off',f'-DINIT_POLICY={policy}','-I'+str(snapshot),'-I'+str(repo),str(out/'probe.cpp'),'-o',str(exe)];metadata['commands'].append(cmd)
 t=time.monotonic();run=subprocess.run(cmd,text=True,capture_output=True);(out/f'build-{policy}.log').write_text(run.stdout+run.stderr);print('build',policy,run.returncode,time.monotonic()-t,flush=True)
 if run.returncode:raise RuntimeError(run.stderr[-3000:])
 cmd=[str(exe),*[str(x) for x in inputs]];metadata['commands'].append(cmd);run=subprocess.run(cmd,text=True,capture_output=True);(out/f'policy-{policy}.csv').write_text(run.stdout);(out/f'policy-{policy}.stderr').write_text(run.stderr);print('run',policy,run.returncode,flush=True)
 if run.returncode:raise RuntimeError(run.stderr)
(out/'commands.json').write_text(json.dumps(metadata,indent=2)+'\n')
