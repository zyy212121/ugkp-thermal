from pathlib import Path
import subprocess,csv,json
repo=Path(__file__).resolve().parents[3]
work=Path(__file__).resolve().parent
before=work.parent/'WallGeometryBuilder.before-rank.H'
after=repo/'common/gasWall/WallGeometryBuilder.H'
export=(work/'export.cpp').read_text()
head=export[:export.index('std::cout<<std::setprecision(17)')]
body=r'''
wallGeometryDetail::Context<double> context;
if(!wallGeometryDetail::prepare(m,context,status,options))return 3;
std::cout<<std::setprecision(17)<<"face,order,rank,constant_error,linear_error,quadratic_error\n";
for(const auto&d:cache.descriptors){
 long double moments[10]{},scale[3]{};
 for(int i=0;i<int(d.matchingCells.size());++i){
  auto a=wallGeometryDetail::matchingMoments(m,context,d.matchingCells[i],d);
  const int diagonal[3]={4,7,9};
  for(int j=0;j<3;++j)scale[j]=std::max(scale[j],std::sqrt(std::abs(a[diagonal[j]])));
  for(int j=0;j<10;++j)moments[j]+=d.matchingWeights[i]*a[j];
 }
 long double linear=0,quadratic=0;
 for(int j=0;j<3;++j)linear=std::max(linear,std::abs(moments[j+1])/scale[j]);
 // Every wall in this real planar mesh has tangent1 along its single-cell
 // extrusion and tangent2 along the resolved streamwise coordinate. Pure
 // extrusion curvature is not observable from these cell averages.
 if(std::abs(d.tangent1[2])<.999999)return 4;
 quadratic=std::max(std::abs(moments[4])/(scale[0]*scale[0]),
    std::max(std::abs(moments[6])/(scale[0]*scale[2]),std::abs(moments[9])/(scale[2]*scale[2])));
 std::cout<<d.wallFace<<","<<d.samplingOrder<<","<<d.auditRank<<","<<std::abs(moments[0]-1)<<","<<linear<<","<<quadratic<<"\n";
}
}
'''
results={}
for name,path in [('before',before),('after',after)]:
 source=path.read_text().replace('int samplingOrder=0;', 'int samplingOrder=0;int auditRank=0;')
 source=source.replace('d.samplingOrder=normalQuadratic?', 'd.auditRank=int(basis.size());d.samplingOrder=normalQuadratic?')
 (work/(name+'-audit.H')).write_text(source)
 cpp=work/(name+'-audit.cpp')
 cpp.write_text(head.replace('"common/gasWall/WallGeometryBuilder.H"','"'+name+'-audit.H"')+body)
 exe=work/(name+'-audit')
 subprocess.run(['g++','-std=c++17','-O2','-I'+str(repo/'common'),'-I'+str(repo/'common/gasWall'),str(cpp),'-o',str(exe)],check=True)
 output=work/(name+'-moments.csv')
 with output.open('w') as f:subprocess.run([str(exe),str(work/'mesh.bin')],stdout=f,check=True)
 rows=list(csv.DictReader(output.open()))
 results[name]={'retained_ranks':sorted(set(int(r['rank']) for r in rows)),
  'rank_counts':{str(k):sum(int(r['rank'])==k for r in rows) for k in set(int(r['rank']) for r in rows)},
  'max_constant_error':max(float(r['constant_error']) for r in rows),
  'max_dimensionless_linear_moment_error':max(float(r['linear_error']) for r in rows),
  'max_dimensionless_resolved_quadratic_error':max(float(r['quadratic_error']) for r in rows)}
summary=json.loads((work/'rank-comparison.json').read_text())
for key,value in results.items():summary[key]['moment_audit']=value
summary['validation']={'regression_red':'2 failed (1e-17 and 1e-16 extrusion noise)', 'affected_green':'30 passed in 54.39s', 'full_3d_quadratic':'passed in test_wall_matching_averages.py'}
summary['notes']=['Moment errors use the actual signed-polyhedron volume moments in the production geometry builder. Errors are dimensionless, normalized by the per-coordinate RMS donor scale.', 'The real mesh is a one-cell extrusion: six independent modes (constant, two linear, three quadratic) are physically resolved. The unchanged baseline spuriously promoted extrusion roundoff to extra modes.', 'Field reconstructions compare raw conservative extrapolation on exactly the same saved field; they are not a replay of a different RK stage from a saved BVP profile.']
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(results,indent=2))