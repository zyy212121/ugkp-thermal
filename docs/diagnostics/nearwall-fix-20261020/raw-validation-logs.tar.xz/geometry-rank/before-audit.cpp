
#include "before-audit.H"
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace ugkwp::gaswall;
template<class T>void read(std::ifstream&f,std::vector<T>&v,int n){v.resize(n);f.read(reinterpret_cast<char*>(v.data()),n*sizeof(T));}
int main(int argc,char**argv){std::ifstream f(argv[1],std::ios::binary);int n[4];f.read(reinterpret_cast<char*>(n),sizeof(n));WallGeometryMesh<double> m;
read(f,m.points,n[0]);read(f,m.cellCentres,n[1]);read(f,m.volumes,n[1]);read(f,m.faceOffsets,n[2]+1);read(f,m.facePoints,n[3]);read(f,m.owner,n[2]);read(f,m.neighbour,n[2]);read(f,m.physicalWall,n[2]);if(!f)return 1;
WallGeometryOptions<double> options;options.reconstructMatching=true;options.constructQuadrature=false;
std::vector<int> faces;for(int i=0;i<n[2];++i)if(m.physicalWall[i])faces.push_back(i);
WallGeometryCache<double> cache;WallStatus status;if(!cache.rebuild(m,faces,status,options)){std::cerr<<int(status.code)<<" "<<status.node;return 2;}

wallGeometryDetail::Context<double> context;
if(!wallGeometryDetail::prepare(m,context,status,options))return 3;
std::cout<<std::setprecision(17)<<"face,order,rank,constant_error,linear_error,quadratic_error\n";
for(const auto&d:cache.descriptors){
 long double moments[10]{},scale[3]{};
 for(int i=0;i<int(d.matchingCells.size());++i){
  auto a=wallGeometryDetail::matchingMoments(m,context,d.matchingCells[i],d);
  const int diagonal[3]={4,7,9};
  for(int j=0;j<3;++j)scale[j]=std::max(scale[j],std::sqrt(std::abs(a[diagonal[j]])));
  for(int j=0;j<10;++j)moments[j]+=d.matchingWeights[i]*a[j];
 }
 long double linear=0,quadratic=0;
 for(int j=0;j<3;++j)linear=std::max(linear,std::abs(moments[j+1])/scale[j]);
 // Every wall in this real planar mesh has tangent1 along its single-cell
 // extrusion and tangent2 along the resolved streamwise coordinate. Pure
 // extrusion curvature is not observable from these cell averages.
 if(std::abs(d.tangent1[2])<.999999)return 4;
 quadratic=std::max(std::abs(moments[4])/(scale[0]*scale[0]),
    std::max(std::abs(moments[6])/(scale[0]*scale[2]),std::abs(moments[9])/(scale[2]*scale[2])));
 std::cout<<d.wallFace<<","<<d.samplingOrder<<","<<d.auditRank<<","<<std::abs(moments[0]-1)<<","<<linear<<","<<quadratic<<"\n";
}
}
