
#include "common/gasWall/WallGeometryBuilder.H"
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace ugkwp::gaswall;
template<class T>void read(std::ifstream&f,std::vector<T>&v,int n){v.resize(n);f.read(reinterpret_cast<char*>(v.data()),n*sizeof(T));}
int main(int argc,char**argv){std::ifstream f(argv[1],std::ios::binary);int n[4];f.read(reinterpret_cast<char*>(n),sizeof(n));WallGeometryMesh<double> m;
read(f,m.points,n[0]);read(f,m.cellCentres,n[1]);read(f,m.volumes,n[1]);read(f,m.faceOffsets,n[2]+1);read(f,m.facePoints,n[3]);read(f,m.owner,n[2]);read(f,m.neighbour,n[2]);read(f,m.physicalWall,n[2]);if(!f)return 1;
WallGeometryOptions<double> options;options.reconstructMatching=true;options.constructQuadrature=false;
std::vector<int> faces;for(int i=0;i<n[2];++i)if(m.physicalWall[i])faces.push_back(i);
WallGeometryCache<double> cache;WallStatus status;if(!cache.rebuild(m,faces,status,options)){std::cerr<<int(status.code)<<" "<<status.node;return 2;}
std::cout<<std::setprecision(17)<<"face,owner,matching_y,donor,weight,x,y,z,order\n";
for(const auto&d:cache.descriptors)for(int i=0;i<int(d.matchingCells.size());++i){int c=d.matchingCells[i];std::cout<<d.wallFace<<","<<d.ownerCell<<","<<d.matchingDistance<<","<<c<<","<<d.matchingWeights[i]<<","<<m.cellCentres[c][0]<<","<<m.cellCentres[c][1]<<","<<m.cellCentres[c][2]<<","<<d.samplingOrder<<"\n";}
}
