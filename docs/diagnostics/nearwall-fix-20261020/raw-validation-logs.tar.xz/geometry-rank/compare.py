from pathlib import Path
import csv,json,re
from collections import defaultdict
import numpy as np
work=Path(__file__).resolve().parent
case=work.parent/'collapse-capture-case'
def field(path):
 raw=path.read_bytes();m=re.search(rb'internalField\s+nonuniform\s+List<[^>]+>\s+(\d+)\s*\(',raw)
 assert m,path
 return np.frombuffer(raw,dtype='<f8',count=int(m[1]),offset=m.end())
def groups(name):
 out=defaultdict(list)
 for row in csv.DictReader((work/name).open()):out[int(row['face'])].append(row)
 return out
allweights={'before':groups('actual-weights-current.csv'),'after':groups('actual-weights-after.csv')}
summary={}
for name,data in allweights.items():
 worst=max(data,key=lambda f:sum(abs(float(r['weight'])) for r in data[f]))
 summary[name]={'wall_faces':len(data),'max_abs_weight':max(abs(float(r['weight'])) for rows in data.values() for r in rows),'max_l1':sum(abs(float(r['weight'])) for r in data[worst]),'max_l1_face':worst,'orders':sorted(set(int(r['order']) for rows in data.values() for r in rows)),'selected':{}}
 for face in [53768,53769,53770,53771]:
  rows=data[face];summary[name]['selected'][face]={'l1':sum(abs(float(r['weight'])) for r in rows),'max_abs_weight':max(abs(float(r['weight'])) for r in rows),'donors':[int(r['donor']) for r in rows],'weights':[float(r['weight']) for r in rows]}
summary['field_reconstruction']={}
for t in ['0.023050000000000001','0.02305115000835669']:
 rho=field(case/t/'rho');k=field(case/t/'k');omega=field(case/t/'omega')
 out={}
 for face in [53769,53770,53771]:
  out[face]={}
  for name,data in allweights.items():
   rows=data[face];cells=np.array([int(r['donor']) for r in rows]);w=np.array([float(r['weight']) for r in rows]);r=float(w@rho[cells]);out[face][name]={'rho':r,'raw_k':float(w@(rho[cells]*k[cells])/r),'raw_omega':float(w@(rho[cells]*omega[cells])/r)}
 summary['field_reconstruction'][t]=out
(work/'rank-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['before','after']:
 s=summary[name];print(name,'faces',s['wall_faces'],'maxabs',s['max_abs_weight'],'maxl1',s['max_l1'],'face',s['max_l1_face'],'orders',s['orders'])
 for f,v in s['selected'].items():print(f,'l1',v['l1'],'maxabs',v['max_abs_weight'])
for t,faces in summary['field_reconstruction'].items():
 print('time',t)
 for f,v in faces.items():print(f,v)