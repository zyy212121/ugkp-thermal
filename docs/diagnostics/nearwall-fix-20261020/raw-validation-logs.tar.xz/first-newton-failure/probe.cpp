
#include "singular_capture.H"
#include <iostream>
#include <cassert>
int main(){using namespace ugkwp::gaswall;using namespace ugkwp::gaswall::detail;CapturedSingularWall m;auto&in=m.input;auto&c=m.config;LayerContext<double,2>ctx;assert(makeContext(in,c,ctx));WallWorkspace<double,2,24>w;loadCapturedSingularIterate(w);
 double norm=0;assert(allResidual(in,c,ctx,w.state,w.y,w.residual,norm));std::cout.precision(17);std::cout<<"norm="<<norm<<'\n';
 assert(assembleJacobianNode(in,c,ctx,w,20));for(int i=19;i<=21;++i){std::cout<<"Jrow "<<i;for(int a=0;a<6;++a)std::cout<<' '<<(i==19?w.upper[i][a][4]:(i==20?w.diagonal[i][a][4]:w.lower[i][a][4]));std::cout<<'\n';}
 double old=w.state[20][4];for(double h:{std::sqrt(std::numeric_limits<double>::epsilon())*old,6.055454452393343e-6,1e-5}){
  double plus[6]{},minus[6]{};w.state[20][4]=old+h;assert(layerRow(in,c,ctx,w.state,w.y,20,plus));w.state[20][4]=old-h;assert(layerRow(in,c,ctx,w.state,w.y,20,minus));w.state[20][4]=old;std::cout<<"central h "<<h;for(int a=0;a<6;++a)std::cout<<' '<<(plus[a]-minus[a])/(2*h);std::cout<<'\n';}
 bool result=newtonStep(in,c,ctx,w);std::cout<<"newton="<<result<<'\n';
}
