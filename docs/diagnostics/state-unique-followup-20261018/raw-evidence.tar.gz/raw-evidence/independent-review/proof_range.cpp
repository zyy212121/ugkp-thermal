#include "ablation/InterfaceMath.H"
#include <cstdio>
using namespace chmt;
int main(){ const Real m=1.7976931348623157e308,g=3*2.22044604925031308085e-16/(1-3*2.22044604925031308085e-16);
Real u[Ns]={m/2,0,0},v[Ns]={m*.75,1,1},r[Ns]={1,1e-100,.8},bulk[Ns]={1./3,1./3,1./3};
bool old=true; for(int i=0;i<Ns;++i){old=old&&bulk[i]>0;for(int j=0;j<Ns;++j)if(i!=j){Real p=0,x=0,a=0;if(!composition_detail::productFinite(u[i],r[j],p)||!composition_detail::sumFinite(p,v[i],x)||!composition_detail::sumFinite(absValue(p),absValue(v[i]),a)||x<=g*a)old=false;}}
printf("old=%d extrema=%d\n",old,composition_detail::uniquePositiveMatrix(u,v,r,bulk,g));}
