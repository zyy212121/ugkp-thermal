#include "ablation/InterfaceMath.H"
#include <cassert>
#include <cstdio>
using namespace chmt;
int main(){PhysicsConfig p;p.species[0].R=1;p.gasDiffusivity[0]=1;
Real bulk[Ns]={.5},js[Ns]={1},out[Ns]={};composition_detail::Info info;
bool ok=composition_detail::scalarSolve(js,bulk,1,1,1,p,1e-12,out,&info);
assert(ok&&out[0]==1&&info.unique&&info.structuredIterations>0);
printf("Ns1 out=%.17g iterations=%d polynomial=%d\n",out[0],info.structuredIterations,info.polynomialCount);}
