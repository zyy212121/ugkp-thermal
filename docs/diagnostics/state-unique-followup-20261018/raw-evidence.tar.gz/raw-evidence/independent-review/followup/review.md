# Follow-up independent review: direct Ns2 Perron vector

Scope: e4df168d459f0794863a75a7f1dbdc71d642c121..1d10e4d16411857c139d0fdde91e2a1839c38ca7. Read-only TEST checkout. Only the follow-up delta was assessed; the earlier review remains applicable. No GPU work or large builds.

## Declined to judge

- GPU timing and end-to-end CUDA behavior: no GPU work was authorized for this reviewer; parent owns reruns. I checked the host/device arithmetic and dispatch statically.
- Full CHMT compilation/linking and production-case performance: parent owns the pending build and final checks.
- Previous changes outside this delta, physical calibration, and historical solver failures: these were not reopened.
- Direct invocation of internal uniqueTwoSpecies with Ns!=2 or arbitrary unnormalized matrix coefficients: its sole caller is compile-time-dispatched and supplies the existing normalized, proved-positive domain.

## Assessment

Ready: Yes for this follow-up delta. No Critical, Important, or Minor issue found.

For M=[[a,b],[c,e]], h=(a-e)/2 and s=hypot(h,sqrt(b)*sqrt(c)), the Perron eigenvalue is (a+e)/2+s. When h>=0, [s+h,c] is its positive right eigenvector; when h<0, [b,s-h] is its positive right eigenvector. The selected expressions add same-sign magnitudes and avoid subtractive cancellation. This matches the normalized rank-two matrix, including variable Rmix; neither a constant-density approximation nor a flux-sign assumption is introduced.

The existing strict off-diagonal proof makes computed b and c positive. Its arithmetic error margin also protects positivity against contraction/rounding differences in the repeated expressions. The normalized-domain coefficient bound reviewed earlier keeps all new unguarded products, differences, additions, and hypot arguments far below overflow. Taking sqrt(b)*sqrt(c) avoids premature underflow of b*c. Very small components may eventually round to zero when the final normalized fraction itself is unrepresentable; the unchanged simplex and original-F certificates still decide acceptance.

The analytic candidate passes the unchanged certify(...,allowApproximation=false), followed by publishSelection's real final residual. A failed certificate continues the same scalar root isolation; it cannot introduce a finite uncertified approximation. Ns>2 continues structured Newton; nonunique cases never enter this branch.

Ns1 safety: the definition contains index-1 operations but is not executed for Ns1. The conditional expression evaluates only its selected operand, so Ns1 takes uniqueNewton. Merely defining the unused inline function does not execute an out-of-bounds operation. I additionally forced Ns1 through the positive dispatch (rather than its usual initial exact return) under ASan/UBSan: one structured iteration, out=1, no sanitizer report.

## Independent verification

Small isolated g++ builds only; outputs are under this followup directory.

- unique Ns2: polynomial=0, structuredIterations=0 assertion passes, original residual=0.
- unique Ns10: unchanged structured route passes, polynomial=0, original residual=8.6736173798840355e-19.
- manufactured Ns2: 1,000 cases, bad=0; existing OF-style FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW mask enabled.
- edges Ns1 and Ns2: 240 cases each, bad=0, including negative/zero/tiny total flux and degenerate diffusion.
- multiple Ns2: pass.
- contracts Ns2: all nine diagnostic/FPE cases pass.
- Isolated physical subnormal test, D=denorm_min with unit p/T/distance/R and positive signed-species flux vector: target fractions denorm_min, DBL_MIN, 1e-200, and 1e-20 return exact original-F zero, unique=true, polynomial=0, structuredIterations=0, fatal=0 with the OF-style FPE mask enabled.
- Same physical probe at target .2 and tolerance=0: the rounded analytic candidate correctly falls through to one polynomial; final original F is exactly zero. This independently exercises certification failure and continuation.
- Ns1 forced positive dispatch under -fsanitize=address,undefined: pass, out=1, structuredIterations=1, polynomial=0.

The TEST checkout's tracked and staged diffs remained empty after these checks.
