#include "ablation/InterfaceMath.H"
#include <cassert>
#include <cfenv>
#include <cstdio>
#include <limits>
using namespace chmt;
int main(){feenableexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW);
const double tiny=std::numeric_limits<double>::denorm_min();
for(double y: {tiny,std::numeric_limits<double>::min(),1e-200,1e-20,.2}){
ugkp::diagnostics::DeviceContext diag{};PhysicsConfig p;p.diagnostics=&diag;
for(int i=0;i<2;++i){p.species[i].R=1;p.gasDiffusivity[i]=tiny;}
Real bulk[2]={.5,.5},js[2]={y,1-y},out[2]={},f[2]={};
composition_detail::Info info;bool ok=composition_detail::scalarSolve(js,bulk,1,1,1,p,0,out,&info);
fprintf(stderr,"y=%.17g ok=%d unique=%d poly=%d n=%d fatal=%d out0=%.17g out1=%.17g state=%d res=%.17g\n",y,ok,info.unique,info.polynomialCount,info.structuredIterations,diag.fatalClaim,out[0],out[1],int(info.state),info.actualResidual);
assert(ok&&info.unique&&info.structuredIterations==0&&!diag.fatalClaim);if(y<1e-19)assert(info.polynomialCount==0);
assert(compositionResidual(out,bulk,js,1,1,1,p,f,nullptr));
assert(f[0]==0&&f[1]==0&&out[0]==y&&out[1]==1-y);
printf("y=%.17g out=%.17g residual=%.17g\n",y,out[0],info.actualResidual);
}
}
