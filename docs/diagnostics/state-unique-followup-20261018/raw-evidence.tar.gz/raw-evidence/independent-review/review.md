# Independent review: wall accepted state and interface unique solve

Reviewed immutable diff f9125e47cb90e8b605ab611a9757606488156e75..74f8f75500e29b1f853e3b7146231b313c3b4402 in the independent TEST clone. HEAD was verified at the latter commit; tracked/index diffs were empty. No checkout/index/HEAD mutation, GPU work, or large build was performed.

## Declined to judge

- Physical calibration, continuum-model adequacy, and whether every valid reacting-wall BVP should converge: these commits change mathematical candidate handling and algebraic solve order; those broader model questions need separate evidence.
- Historical baseline wall failures and the developer's large scan/performance/sanitizer claims: treated as leads, not independently established results.
- Full OpenFOAM compilation/linking and end-to-end CUDA execution: the parent owns the ongoing build, and this review was explicitly barred from GPU/large builds. I inspected collective ordering and shared-memory ownership statically.
- Unrestricted raw-array calls to internal uniquePositiveMatrix as a production interface: scalarSolve supplies normalized, bounded coefficients. I did test the broader raw-array wording and report its limitation below.
- Unchanged time advancement, unrelated thermo/chemistry implementations, and diagnostics catalogue entries outside adjusted wall line provenance: not part of the two-commit behavioral scope.

## Assessment

Ready: Yes for the two-commit mathematical scope. No Critical or Important issues found. One Minor contract-wording/test-domain issue is recorded below; it does not require a physical rejection gate.

The wall candidate is mapped before allResidual, the accepted state is copied directly from that mapped trial, and the following Jacobian reads that stored state. Ns2 clamps its single independent fraction. Ns>2 projects the full vector including 1-sum(independent), with a rounding correction ensuring that the actual dependent arithmetic is nonnegative. Finite feasible inputs stay unchanged. The per-node owner writes before the existing sync, and rank-local initialValid participates in the existing all reduction. Every lane follows the same collective branch; failed mathematical candidates retain quiet diagnostics. The normal accepted/base residual still uses the real input and static storage checks retain their owner channel.

The structured Newton equations match the normalized rank-two eigenproblem for variable Rmix: (z+d_i)Y_i-u_i(r.Y)-v_i=0, sum(Y)=1, z=J(r.Y)+Db-d.Y. Its two scalar equations correctly eliminate delta(r.Y), delta(z); the pivoted 2x2 solve uses guarded operations. Each accepted early result passes simplex and original compositionResidualPolicy certification, followed by publishSelection's real residual. A failed structured solve continues scalar root isolation. Nonunique cases bypass it and retain old pole/endpoint insertion and nearest-bulk ordering.

For supported scaled coefficients, excluding-self extrema are sufficient: ties are handled by second extrema, and the worst off-diagonal is selected by the sign of u. The old margin test is monotone in that off-diagonal product in this domain. No empirical physics threshold or physical-time retry was introduced.

## Minor issue

InterfaceComposition.H:719-721 says the extrema proof preserves exactly the previous strict proof, including its arithmetic error margin, without stating the normalized-domain condition.

Trigger/evidence: the isolated finite-array test proof_range.cpp uses Ns3, u={MAX/2,0,0}, v={.75*MAX,1,1}, r={1,1e-100,.8}, bulk={1/3,1/3,1/3}. It prints old=0 extrema=1. The row minimum passes, but a larger off-diagonal sum is unrepresentable; the old all-pairs loop rejects through sumFinite whereas the new loop never evaluates it.

Impact: this disproves unrestricted raw-array equivalence and means the current random equivalence test does not establish an all-finite-input contract. It is not a reachable scalarSolve regression. Before interval scaling, |u_i| and d_i are <=1. rmax is 1. The ordered endpoints are expanded outward by boundError=gamma*(absU*rmax+absV+dmax), so intervalScale=max(|a|,|b|,dmax)>=boundError. Hence each final |u_i| and |v_i| is bounded by approximately 1/gamma, and r_i<=1. Overflow in these off-diagonal products/sums cannot occur there.

Fix: qualify the comment and test contract as equality for scalarSolve's normalized coefficient domain; optionally add an adversarial scaled-domain test documenting the bound. Do not add a physical rejection solely to emulate an unreachable raw-array arithmetic refusal.

## Independent verification

All compilation used small g++ probes with -O2 -ffp-contract=off and outputs under this independent-review directory.

- New projection fixture: Ns2/3/10/32, 10,000 KKT/simplex/idempotence cases each, range/nonfinite probes, FE_DIVBYZERO|FE_INVALID|FE_OVERFLOW enabled: pass.
- New accepted-update fixture: Ns3/10: pass, alpha=1, final norm=0, stored independent fractions feasible.
- Real wall cases 11/25, separately compiled with the same FPE mask enabled: pass, fatal=0, four iterations; measured residuals 1.7481418553475813e-11 and 4.0990128883380622e-11; maximum stored independent Y 0.99992584886109348 and 0.99334454961468521.
- New unique fixture Ns2/10: pass, polynomialCount=0; original residuals 1.3357370765021415e-16 and 8.6736173798840355e-19.
- New proof fixture Ns10: pass, 30,000 signed/tied/boundary matrices matching the all-pairs oracle.
- Existing multiple-root fixture Ns3: pass; existing degenerate edges fixture Ns10: 240 cases, zero bad.
- Raw-array range counterexample: old=0 extrema=1, as explained above.
