source /opt/openfoam10/etc/bashrc
set -eo pipefail
ulimit -s 65536
export FOAM_USER_APPBIN="$REVIEW_RUNTIME/install/bin" FOAM_USER_LIBBIN="$REVIEW_RUNTIME/install/lib"
export CUDA_HOME=/usr/local/cuda-13.1 NVCC=/usr/local/cuda-13.1/bin/nvcc
export PATH="$FOAM_USER_APPBIN:$FOAM_APPBIN:$CUDA_HOME/bin:/usr/bin:/bin:$WM_PROJECT_DIR/wmake"
export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:$FOAM_LIBBIN:$FOAM_LIBBIN/$FOAM_MPI:$FOAM_LIBBIN/dummy:$CUDA_HOME/lib64"
export CUDA_CACHE_PATH="$REVIEW_RUNTIME/cache/cuda" XDG_CACHE_HOME="$REVIEW_RUNTIME/cache" TMPDIR="$REVIEW_RUNTIME/tmp"
export UGKWP_GAS_SPECIES=2 CHMT_CUDA_ARCH=sm_89 UGKWP_CUDA_ARCH=sm_89
export PYTHONPATH="$REVIEW_SOURCE/validation/tests/gas_transport:$REVIEW_SOURCE/validation/tests/gas_wall:$REVIEW_SOURCE"
mkdir -p "$FOAM_USER_APPBIN" "$FOAM_USER_LIBBIN" "$CUDA_CACHE_PATH" "$TMPDIR"
cd "$REVIEW_SOURCE"

python3 -m pytest -q validation/tests/test_interface_composition.py --basetemp /home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018/.review-tmp/state-reproduce-4303f3f22b52/pytest --junitxml /mnt/d/tempt/ugkp-pr19-state-unique-fixes-20261018/reproduction-interface-native/results.xml
