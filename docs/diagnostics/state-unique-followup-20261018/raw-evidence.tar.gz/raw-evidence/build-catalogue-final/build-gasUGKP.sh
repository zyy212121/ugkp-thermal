source /mnt/d/tempt/ugkp-pr19-state-unique-fixes-20261018/build-catalogue-final/env-final.sh
bash -x tool/gasUGKP/build_private_backend.sh
