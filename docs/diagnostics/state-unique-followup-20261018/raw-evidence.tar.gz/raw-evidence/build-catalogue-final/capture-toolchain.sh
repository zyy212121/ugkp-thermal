source /mnt/d/tempt/ugkp-pr19-state-unique-fixes-20261018/build-catalogue-final/env-final.sh
for v in WM_PROJECT_VERSION WM_OPTIONS WM_PROJECT_DIR FOAM_USER_APPBIN FOAM_USER_LIBBIN FOAM_APPBIN FOAM_LIBBIN CUDA_HOME NVCC CUDA_CACHE_PATH XDG_CACHE_HOME TMPDIR UGKWP_GAS_SPECIES UGKWP_CUDA_ARCH CHMT_CUDA_ARCH LD_LIBRARY_PATH; do printf "%s=%s\n" "$v" "${!v}"; done
nvcc --version
g++ --version
ldd --version
