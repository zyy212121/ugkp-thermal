from pathlib import Path
import subprocess, json, hashlib, os, time, concurrent.futures, datetime
E=Path(__file__).resolve().parent;R=Path('/home/lss/OpenFOAM/lss-10/applications/solvers/ugkp-thermal-test/pr19-math-fixes-20261018')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
sha=git('rev-parse','HEAD');assert not git('status','--porcelain=v1','--untracked-files=no')
files={}
for name in git('ls-files','-z').split('\0'):
 if name and name.split('/')[0] in ('common','applications','tool','validation'):
  f=R/name
  if f.is_file():files[name]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'symlink':os.readlink(f) if f.is_symlink() else None}
manifest={'source_commit':sha,'source_tree':git('rev-parse','HEAD^{tree}'),'tracked_source_files':files,'git_status':git('status','--porcelain=v1'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targets':[]}
(E/'source-before.json').write_text(json.dumps(manifest,indent=2))
env=E/'env-final.sh'
probes='source '+str(env)+'\nfor v in WM_PROJECT_VERSION WM_OPTIONS WM_PROJECT_DIR FOAM_USER_APPBIN FOAM_USER_LIBBIN FOAM_APPBIN FOAM_LIBBIN CUDA_HOME NVCC CUDA_CACHE_PATH XDG_CACHE_HOME TMPDIR UGKWP_GAS_SPECIES UGKWP_CUDA_ARCH CHMT_CUDA_ARCH LD_LIBRARY_PATH; do printf "%s=%s\\n" "$v" "${!v}"; done\nnvcc --version\ng++ --version\nldd --version\n'
(E/'capture-toolchain.sh').write_text(probes)
p=subprocess.run(['bash',str(E/'capture-toolchain.sh')],text=True,capture_output=True);(E/'toolchain.log').write_text(p.stdout+p.stderr);p.check_returncode()
scripts=[('gasUGKP','tool/gasUGKP/build_private_backend.sh'),('FSH','tool/FSH/build_private_backend.sh'),('CHT','tool/CHT/build_cuda_solver.sh'),('CHMT','applications/CHMT/Allwmake')]
def build(item):
 name,script=item;assert git('rev-parse','HEAD')==sha
 shell=E/('build-'+name+'.sh');shell.write_text('source '+str(env)+'\nbash -x '+script+'\n')
 cmd=['bash',str(shell)];begin=time.time();print('START',name,sha,flush=True)
 with (E/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 result={'target':name,'command':cmd,'body':shell.read_text(),'source_commit':sha,'exit':p.returncode,'elapsed_s':time.time()-begin}
 (E/(name+'-result.json')).write_text(json.dumps(result,indent=2));print('END',name,p.returncode,'seconds',round(time.time()-begin,2),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:manifest['targets']=list(pool.map(build,scripts))
manifest['artifacts']=[]
for name in ['gasUGKP','gasUGKPCudaBackend','FSH','FSHCudaBackend','CHT','CHMT']:
 f=R/'.review-install/bin'/name
 if f.exists():
  assert f.resolve().is_relative_to(R)
  result={'name':name,'path':str(f),'realpath':str(f.resolve()),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
  p=subprocess.run(['ldd',str(f)],text=True,capture_output=True,env={**os.environ,'LD_LIBRARY_PATH':'/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib:/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib/openmpi-system:/opt/openfoam10/platforms/linux64GccDPInt32Opt/lib/dummy:/usr/local/cuda-13.1/lib64'});(E/(name+'-ldd.log')).write_text(p.stdout+p.stderr);result['ldd_exit']=p.returncode;manifest['artifacts'].append(result)
assert git('rev-parse','HEAD')==sha
changed=[n for n,v in files.items() if not (R/n).is_file() or hashlib.sha256((R/n).read_bytes()).hexdigest()!=v['sha256']]
manifest['source_changes_during_build']=changed;manifest['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();manifest['git_status_after']=git('status','--porcelain=v1')
(E/'build-manifest.json').write_text(json.dumps(manifest,indent=2));print('FINAL artifacts',len(manifest['artifacts']),'source_changes',changed,flush=True)
assert not changed and all(x['exit']==0 for x in manifest['targets']) and len(manifest['artifacts'])==6
